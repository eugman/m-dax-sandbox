"""Registry of M functions with implementation status.

This module tracks Power Query M functions and their implementation status
across different components:
- Python runtime (evaluator)
- Pandas emitter (transpiler)
- TypeScript runtime

It provides:
- Clear error messages for unsupported functions
- Implementation progress tracking
- Documentation generation support

The registry is kept in sync with the actual implementations.
Use scripts/generate_function_registry.py --verify to check accuracy.

Reference: https://learn.microsoft.com/en-us/powerquery-m/power-query-m-function-reference
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional


class FunctionStatus(Enum):
    """Implementation status of an M function."""
    IMPLEMENTED = "implemented"      # Fully working
    PARTIAL = "partial"              # Works for common cases
    PLANNED = "planned"              # On the roadmap
    NOT_PLANNED = "not_planned"      # Won't implement (connectors, etc.)
    UNKNOWN = "unknown"              # Not in registry


@dataclass
class FunctionInfo:
    """Information about an M function."""
    name: str
    category: str
    description: str = ""
    # Status for each component
    emitter_status: FunctionStatus = FunctionStatus.UNKNOWN
    runtime_status: FunctionStatus = FunctionStatus.UNKNOWN
    ts_runtime_status: FunctionStatus = FunctionStatus.UNKNOWN
    notes: str = ""
    docs_url: str = ""

    @property
    def status(self) -> FunctionStatus:
        """Legacy property for backward compatibility - returns emitter status."""
        return self.emitter_status


# Registry of M functions
_FUNCTION_REGISTRY: Dict[str, FunctionInfo] = {}


def _register(
    name: str,
    category: str,
    description: str = "",
    *,
    emitter: FunctionStatus = FunctionStatus.UNKNOWN,
    runtime: FunctionStatus = FunctionStatus.UNKNOWN,
    ts_runtime: FunctionStatus = FunctionStatus.UNKNOWN,
    notes: str = "",
) -> None:
    """Register a function in the registry."""
    _FUNCTION_REGISTRY[name] = FunctionInfo(
        name=name,
        category=category,
        description=description,
        emitter_status=emitter,
        runtime_status=runtime,
        ts_runtime_status=ts_runtime,
        notes=notes,
        docs_url=f"https://learn.microsoft.com/en-us/powerquery-m/{name.lower().replace('.', '-')}",
    )


# Shortcuts for common status combinations
I = FunctionStatus.IMPLEMENTED
P = FunctionStatus.PLANNED
N = FunctionStatus.NOT_PLANNED
U = FunctionStatus.UNKNOWN


# =============================================================================
# FUNCTION REGISTRY
# Format: _register(name, category, description, emitter=, runtime=, ts_runtime=, notes=)
# Status: I=IMPLEMENTED, P=PLANNED, N=NOT_PLANNED, U=UNKNOWN
# =============================================================================

# -----------------------------------------------------------------------------
# File/CSV Functions
# -----------------------------------------------------------------------------
_register("Csv.Document", "File", "Creates a table from CSV content",
          emitter=I, runtime=I, ts_runtime=I)
_register("File.Contents", "File", "Returns the binary contents of a file",
          emitter=I, runtime=I, ts_runtime=I)
_register("Lines.FromText", "File", "Converts text to list of lines",
          emitter=P, runtime=P, ts_runtime=P)
_register("Lines.FromBinary", "File", "Converts binary to list of text lines",
          emitter=P, runtime=P, ts_runtime=P)

# -----------------------------------------------------------------------------
# Web Functions
# -----------------------------------------------------------------------------
_register("Json.Document", "Web", "Parses JSON content into M values",
          emitter=I, runtime=I, ts_runtime=I)
_register("Web.Contents", "Web", "Downloads content from a URL",
          emitter=I, runtime=I, ts_runtime=I)
_register("Web.Page", "Web", "Parses HTML page content",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use BeautifulSoup/DOMParser")
_register("Web.BrowserContents", "Web", "Gets page content via browser",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use Selenium/Playwright/fetch")
_register("Xml.Tables", "Web", "Parses XML into tables",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use pandas read_xml()/DOMParser")
_register("Xml.Document", "Web", "Parses XML content",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use lxml/DOMParser")

# -----------------------------------------------------------------------------
# Fabric Functions
# -----------------------------------------------------------------------------
_register("Lakehouse.Contents", "Fabric", "Returns navigation table for Fabric lakehouses",
          emitter=I, runtime=I, ts_runtime=I)
_register("Dataflows.Contents", "Fabric", "Returns content from Fabric dataflows",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use direct lakehouse access instead")

# -----------------------------------------------------------------------------
# Date Functions
# -----------------------------------------------------------------------------
_register("Date.Day", "Date", "Returns day from date",
          emitter=I, runtime=I, ts_runtime=I)
_register("Date.Month", "Date", "Returns month from date",
          emitter=I, runtime=I, ts_runtime=I)
_register("Date.Year", "Date", "Returns year from date",
          emitter=I, runtime=I, ts_runtime=I)
_register("Date.AddDays", "Date", "Adds days to date",
          emitter=P, runtime=P, ts_runtime=I)
_register("Date.AddMonths", "Date", "Adds months to date",
          emitter=P, runtime=P, ts_runtime=I)
_register("Date.AddYears", "Date", "Adds years to date",
          emitter=P, runtime=P, ts_runtime=I)
_register("Date.DayOfWeek", "Date", "Returns day of week",
          emitter=P, runtime=P, ts_runtime=I)
_register("Date.From", "Date", "Converts value to date",
          emitter=P, runtime=P, ts_runtime=P)
_register("Date.StartOfMonth", "Date", "Returns first day of month",
          emitter=P, runtime=P, ts_runtime=P)
_register("Date.EndOfMonth", "Date", "Returns last day of month",
          emitter=P, runtime=P, ts_runtime=P)

# -----------------------------------------------------------------------------
# List Functions
# -----------------------------------------------------------------------------
_register("List.Average", "List", "Returns average of list items",
          emitter=I, runtime=I, ts_runtime=I)
_register("List.Count", "List", "Returns number of items in list",
          emitter=I, runtime=I, ts_runtime=I)
_register("List.Distinct", "List", "Returns unique items",
          emitter=I, runtime=I, ts_runtime=I)
_register("List.Generate", "List", "Generates list from initial value and conditions",
          emitter=I, runtime=I, ts_runtime=P)
_register("List.Max", "List", "Returns maximum value in list",
          emitter=I, runtime=I, ts_runtime=I)
_register("List.Min", "List", "Returns minimum value in list",
          emitter=I, runtime=I, ts_runtime=I)
_register("List.Select", "List", "Filters list by condition",
          emitter=I, runtime=I, ts_runtime=I)
_register("List.Sum", "List", "Returns sum of list items",
          emitter=I, runtime=I, ts_runtime=I)
_register("List.Transform", "List", "Transforms list items",
          emitter=I, runtime=I, ts_runtime=I)
_register("List.First", "List", "Returns first item in list",
          emitter=P, runtime=P, ts_runtime=I)
_register("List.Last", "List", "Returns last item in list",
          emitter=P, runtime=P, ts_runtime=I)
_register("List.Sort", "List", "Sorts list items",
          emitter=P, runtime=P, ts_runtime=I)
_register("List.Reverse", "List", "Reverses list order",
          emitter=P, runtime=P, ts_runtime=I)
_register("List.RemoveNulls", "List", "Removes null values from list",
          emitter=P, runtime=P, ts_runtime=I)
_register("List.Accumulate", "List", "Accumulates values over list (reduce)",
          emitter=P, runtime=P, ts_runtime=P)
_register("List.Contains", "List", "Checks if list contains value",
          emitter=P, runtime=P, ts_runtime=P)

# -----------------------------------------------------------------------------
# Number Functions
# -----------------------------------------------------------------------------
_register("Number.Round", "Number", "Rounds a number to specified precision",
          emitter=P, runtime=P, ts_runtime=I)
_register("Number.Abs", "Number", "Returns absolute value",
          emitter=P, runtime=P, ts_runtime=I)
_register("Number.Sign", "Number", "Returns sign of number (-1, 0, or 1)",
          emitter=P, runtime=P, ts_runtime=I)
_register("Number.Mod", "Number", "Returns remainder after division",
          emitter=P, runtime=P, ts_runtime=I)
_register("Number.Power", "Number", "Returns number raised to power",
          emitter=P, runtime=P, ts_runtime=I)
_register("Number.Sqrt", "Number", "Returns square root",
          emitter=P, runtime=P, ts_runtime=I)
_register("Number.From", "Number", "Converts a value to number",
          emitter=P, runtime=P, ts_runtime=P)

# -----------------------------------------------------------------------------
# Record Functions
# -----------------------------------------------------------------------------
_register("Record.Field", "Record", "Returns field value from record",
          emitter=I, runtime=I, ts_runtime=I)
_register("Record.FieldNames", "Record", "Returns list of field names",
          emitter=P, runtime=P, ts_runtime=I)
_register("Record.FieldValues", "Record", "Returns list of field values",
          emitter=P, runtime=P, ts_runtime=P)
_register("Record.HasFields", "Record", "Checks if record has specified fields",
          emitter=P, runtime=P, ts_runtime=I)
_register("Record.Combine", "Record", "Combines records",
          emitter=P, runtime=P, ts_runtime=P)
_register("Record.FieldOrDefault", "Record", "Returns field value or default",
          emitter=P, runtime=P, ts_runtime=I)
_register("Record.ToTable", "Record", "Converts record to table",
          emitter=P, runtime=P, ts_runtime=I)

# -----------------------------------------------------------------------------
# Table Functions
# -----------------------------------------------------------------------------
_register("Table.AddColumn", "Table", "Adds a computed column to a table",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.AddIndexColumn", "Table", "Adds an index column",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.Combine", "Table", "Combines multiple tables vertically",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.ExpandTableColumn", "Table", "Expands a nested table column",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.FillDown", "Table", "Fills null values with previous non-null value",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.FromRecords", "Table", "Creates a table from a list of records",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.FromRows", "Table", "Creates a table from a list of rows",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.Group", "Table", "Groups rows and performs aggregations",
          emitter=I, runtime=I, ts_runtime=P)
_register("Table.HasColumns", "Table", "Checks if table has specified columns",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.Join", "Table", "Joins two tables",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.NestedJoin", "Table", "Joins tables with nested result",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.Pivot", "Table", "Pivots a table on a column",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.PromoteHeaders", "Table", "Promotes the first row to column headers",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.RemoveColumns", "Table", "Removes columns from a table",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.RenameColumns", "Table", "Renames columns in a table",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.SelectColumns", "Table", "Selects specific columns from a table",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.SelectRows", "Table", "Filters rows based on a condition",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.Skip", "Table", "Skips the first N rows",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.TransformColumns", "Table", "Transforms values in columns",
          emitter=I, runtime=I, ts_runtime=P)
_register("Table.TransformColumnTypes", "Table", "Transforms column types",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.UnpivotOtherColumns", "Table", "Unpivots columns except specified ones",
          emitter=I, runtime=I, ts_runtime=I)
_register("Table.ColumnNames", "Table", "Returns a list of column names",
          emitter=P, runtime=P, ts_runtime=I)
_register("Table.RowCount", "Table", "Returns the number of rows",
          emitter=P, runtime=P, ts_runtime=I)
_register("Table.FirstN", "Table", "Returns the first N rows",
          emitter=P, runtime=P, ts_runtime=I)
_register("Table.LastN", "Table", "Returns the last N rows",
          emitter=P, runtime=P, ts_runtime=I)
_register("Table.First", "Table", "Returns first row",
          emitter=P, runtime=P, ts_runtime=P)
_register("Table.Last", "Table", "Returns last row",
          emitter=P, runtime=P, ts_runtime=P)
_register("Table.Distinct", "Table", "Removes duplicate rows",
          emitter=P, runtime=P, ts_runtime=I)
_register("Table.Sort", "Table", "Sorts a table by one or more columns",
          emitter=P, runtime=P, ts_runtime=I)
_register("Table.Buffer", "Table", "Buffers a table in memory",
          emitter=P, runtime=P, ts_runtime=P)
_register("Table.ReplaceValue", "Table", "Replaces values in columns",
          emitter=P, runtime=P, ts_runtime=P)
_register("Table.SplitColumn", "Table", "Splits a column into multiple columns",
          emitter=P, runtime=P, ts_runtime=P)
_register("Table.Unpivot", "Table", "Unpivots specified columns",
          emitter=P, runtime=P, ts_runtime=P)
_register("Table.Transpose", "Table", "Transposes rows and columns",
          emitter=P, runtime=P, ts_runtime=P)
_register("Table.ExpandListColumn", "Table", "Expands a list column into rows",
          emitter=P, runtime=P, ts_runtime=I)
_register("Table.ExpandRecordColumn", "Table", "Expands a record column into columns",
          emitter=P, runtime=P, ts_runtime=I)

# -----------------------------------------------------------------------------
# Text Functions
# -----------------------------------------------------------------------------
_register("Text.Contains", "Text", "Checks if text contains substring",
          emitter=I, runtime=I, ts_runtime=I)
_register("Text.End", "Text", "Returns last N characters",
          emitter=I, runtime=I, ts_runtime=I)
_register("Text.From", "Text", "Converts a value to text",
          emitter=I, runtime=I, ts_runtime=I)
_register("Text.Length", "Text", "Returns the length of text",
          emitter=I, runtime=I, ts_runtime=I)
_register("Text.Lower", "Text", "Converts text to lowercase",
          emitter=I, runtime=I, ts_runtime=I)
_register("Text.Replace", "Text", "Replaces occurrences in text",
          emitter=I, runtime=I, ts_runtime=I)
_register("Text.Start", "Text", "Returns first N characters",
          emitter=I, runtime=I, ts_runtime=I)
_register("Text.Trim", "Text", "Removes leading and trailing whitespace",
          emitter=I, runtime=I, ts_runtime=I)
_register("Text.Upper", "Text", "Converts text to uppercase",
          emitter=I, runtime=I, ts_runtime=I)
_register("Text.Split", "Text", "Splits text by delimiter",
          emitter=P, runtime=P, ts_runtime=I)
_register("Text.StartsWith", "Text", "Checks if text starts with substring",
          emitter=P, runtime=P, ts_runtime=I)
_register("Text.EndsWith", "Text", "Checks if text ends with substring",
          emitter=P, runtime=P, ts_runtime=I)
_register("Text.BeforeDelimiter", "Text", "Returns text before delimiter",
          emitter=P, runtime=P, ts_runtime=I)
_register("Text.AfterDelimiter", "Text", "Returns text after delimiter",
          emitter=P, runtime=P, ts_runtime=I)
_register("Text.Combine", "Text", "Combines list of text with separator",
          emitter=P, runtime=P, ts_runtime=P)
_register("Text.Middle", "Text", "Returns middle portion of text",
          emitter=P, runtime=P, ts_runtime=P)
_register("Text.TrimStart", "Text", "Removes leading whitespace",
          emitter=P, runtime=P, ts_runtime=P)
_register("Text.TrimEnd", "Text", "Removes trailing whitespace",
          emitter=P, runtime=P, ts_runtime=P)

# -----------------------------------------------------------------------------
# Database Connectors - NOT PLANNED (use native tools)
# -----------------------------------------------------------------------------
_register("Sql.Database", "Connector", "Connects to SQL Server database",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use pandas read_sql() / not available in browser")
_register("Sql.Databases", "Connector", "Lists databases on SQL Server",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use native database tools")
_register("Oracle.Database", "Connector", "Connects to Oracle database",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use pandas read_sql() with cx_Oracle")
_register("PostgreSQL.Database", "Connector", "Connects to PostgreSQL database",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use pandas read_sql() with psycopg2")
_register("MySQL.Database", "Connector", "Connects to MySQL database",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use pandas read_sql() with mysql-connector")
_register("Odbc.DataSource", "Connector", "Connects via ODBC",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use pandas read_sql() with pyodbc")
_register("OleDb.DataSource", "Connector", "Connects via OLE DB",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use pandas read_sql() with appropriate driver")

# -----------------------------------------------------------------------------
# Cloud Connectors - NOT PLANNED (use native SDKs)
# -----------------------------------------------------------------------------
_register("AzureStorage.Blobs", "Connector", "Connects to Azure Blob Storage",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use azure-storage-blob SDK")
_register("AzureStorage.Tables", "Connector", "Connects to Azure Table Storage",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use azure-data-tables SDK")
_register("SharePoint.Contents", "Connector", "Connects to SharePoint",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use Microsoft Graph API")
_register("SharePoint.Files", "Connector", "Lists SharePoint files",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use Microsoft Graph API")
_register("Exchange.Contents", "Connector", "Connects to Exchange",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use Microsoft Graph API")

# -----------------------------------------------------------------------------
# File Format Connectors - NOT PLANNED (use native libraries)
# -----------------------------------------------------------------------------
_register("Excel.Workbook", "Connector", "Reads Excel workbook",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use pd.read_excel() / xlsx library")
_register("Excel.CurrentWorkbook", "Connector", "Gets current Excel workbook tables",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Excel-specific, not applicable")

# -----------------------------------------------------------------------------
# API Connectors - NOT PLANNED (use native libraries)
# -----------------------------------------------------------------------------
_register("OData.Feed", "Connector", "Connects to OData feed",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use requests/fetch with OData parsing")
_register("Salesforce.Data", "Connector", "Connects to Salesforce",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use simple-salesforce / Salesforce API")
_register("GoogleAnalytics.Accounts", "Connector", "Connects to Google Analytics",
          emitter=N, runtime=N, ts_runtime=N,
          notes="Use google-analytics-data library")


# =============================================================================
# Public API
# =============================================================================

def get_function_info(name: str) -> FunctionInfo:
    """Get information about an M function.

    Args:
        name: The function name (e.g., "Table.AddColumn")

    Returns:
        FunctionInfo with status and details
    """
    if name in _FUNCTION_REGISTRY:
        return _FUNCTION_REGISTRY[name]

    return FunctionInfo(
        name=name,
        category="Unknown",
        description="This function is not in the registry",
        emitter_status=FunctionStatus.UNKNOWN,
        runtime_status=FunctionStatus.UNKNOWN,
        ts_runtime_status=FunctionStatus.UNKNOWN,
        docs_url=f"https://learn.microsoft.com/en-us/powerquery-m/{name.lower().replace('.', '-')}",
    )


def get_all_functions() -> List[FunctionInfo]:
    """Get all registered functions."""
    return list(_FUNCTION_REGISTRY.values())


def get_functions_by_status(status: FunctionStatus) -> List[FunctionInfo]:
    """Get all functions with a specific status."""
    return [f for f in _FUNCTION_REGISTRY.values() if f.status == status]


def get_functions_by_category(category: str) -> List[FunctionInfo]:
    """Get all functions in a specific category."""
    return [f for f in _FUNCTION_REGISTRY.values() if f.category == category]


def get_similar_functions(name: str, max_suggestions: int = 3) -> List[str]:
    """Find similar implemented function names for suggestions (emitter status)."""
    suggestions = []

    if '.' in name:
        namespace = name.split('.')[0]
        same_namespace = [
            f.name for f in _FUNCTION_REGISTRY.values()
            if f.name.startswith(namespace + '.') and f.emitter_status == FunctionStatus.IMPLEMENTED
        ]
        suggestions.extend(same_namespace[:max_suggestions])

    return suggestions[:max_suggestions]


def format_unsupported_message(name: str) -> str:
    """Format a helpful error message for an unsupported function."""
    info = get_function_info(name)

    lines = [f"Function '{name}' is not supported"]

    if info.status == FunctionStatus.PLANNED:
        lines.append("Status: PLANNED - This function is on the roadmap")
    elif info.status == FunctionStatus.NOT_PLANNED:
        lines.append(f"Status: NOT PLANNED - {info.notes or 'Use alternative approach'}")
    elif info.status == FunctionStatus.PARTIAL:
        lines.append(f"Status: PARTIAL - {info.notes or 'Limited support'}")
    elif info.status == FunctionStatus.UNKNOWN:
        lines.append("Status: UNKNOWN - This function is not in the registry")

    suggestions = get_similar_functions(name)
    if suggestions:
        lines.append(f"Similar implemented functions: {', '.join(suggestions)}")

    lines.append(f"Docs: {info.docs_url}")

    return '\n'.join(lines)


def get_implementation_stats() -> Dict[str, int]:
    """Get statistics about implementation coverage."""
    stats = {status.value: 0 for status in FunctionStatus}
    for func in _FUNCTION_REGISTRY.values():
        stats[func.status.value] += 1
    return stats
