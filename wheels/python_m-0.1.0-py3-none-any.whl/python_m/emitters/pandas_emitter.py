"""Pandas code emitter.

This module generates Pandas Python code from an M code AST.
"""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set, Tuple, Union


@dataclass
class AddColumnResult:
    """Result from Table.AddColumn emission.

    Used to pass structured data to visit_variable_assignment
    for proper multi-statement code generation.
    """
    table_code: str
    column_name: str
    expression_code: str


@dataclass
class UnsupportedFunctionResult:
    """Result from an unsupported function call.

    Enables graceful degradation by passing through the input value
    while adding a comment about the skipped operation.
    """
    passthrough_code: str  # The input to pass through (e.g., the first argument)
    comment: str  # Comment explaining what was skipped
    func_name: str  # The unsupported function name

from python_m.ast.nodes import (
    ASTNode,
    ASTVisitor,
    LetExpression,
    VariableAssignment,
    FunctionCall,
    MemberAccess,
    Identifier,
    StringLiteral,
    ListLiteral,
    NumberLiteral,
    EachExpression,
    FieldAccess,
    BinaryExpression,
    UnaryExpression,
    TypeCheckExpression,
    IfExpression,
    NullLiteral,
    BooleanLiteral,
    TypeExpression,
    TryExpression,
    RecordLiteral,
    FunctionExpression,
    FunctionParameter,
    ItemAccess,
    InclusiveIdentifier,
    ErrorExpression,
    NotImplementedExpression,
    MetaExpression,
    SectionDocument,
    SectionMember,
)
from python_m.emitters.base import BaseEmitter, EmitResult, LakehouseReference, python_only
from python_m.emitters.function_registry import (
    get_function_info,
    format_unsupported_message,
    FunctionStatus,
)


class PandasEmitter(BaseEmitter, ASTVisitor):
    """Emitter that generates Pandas Python code from M code AST.

    Transforms M language constructs into equivalent Pandas operations.
    Currently supports:
    - Csv.Document(File.Contents(...)) -> pd.read_csv(...)
    - Variable assignments
    - let ... in ... expressions

    Example:
        emitter = PandasEmitter()
        result = emitter.emit(ast)
        if result.success:
            print(result.code)
    """

    def __init__(
        self,
        fold_queries: bool = True,
        explicit_steps: bool = False,
        lakehouse_mode: str = "fabric"
    ):
        """Initialize the Pandas emitter.

        Args:
            fold_queries: If True, optimize away NOP assignments where the value
                is just an identifier reference (e.g., Step1 = Source is folded out).
                If False, emit all intermediate variable assignments.
            explicit_steps: If True, disable ALL optimizations. Each M step maps
                to one pandas DataFrame operation. Overrides fold_queries to False.
                Useful for debugging and understanding M transformations.
            lakehouse_mode: How to handle Lakehouse.Contents patterns:
                - "fabric": Generate Fabric notebook paths (/lakehouse/default/Files/...)
                - "spark": Generate Spark DataFrame reads with .toPandas()
                - "fixture": Generate fixture paths for testing (fixtures/...)
        """
        self.explicit_steps = explicit_steps
        self.fold_queries = fold_queries and not explicit_steps  # explicit_steps overrides
        self.lakehouse_mode = lakehouse_mode
        self.imports: List[str] = []
        self.helpers: List[str] = []  # Helper functions to include
        self.statements: List[str] = []
        self.warnings: List[str] = []
        self.result_variable: Optional[str] = None
        self._current_table: Optional[str] = None  # For Table.SelectRows condition
        self._needs_try_otherwise_helper = False  # Track if we need the helper
        self._record_variables: Set[str] = set()  # Track variables that hold records
        self._table_variables: Set[str] = set()  # Track variables that hold tables
        self.lakehouse_references: List[LakehouseReference] = []  # Extracted lakehouse metadata
        self.section_var_map: Dict[str, ASTNode] = {}
        self.let_var_map: Dict[str, ASTNode] = {}

    def emit(self, ast: Union[LetExpression, SectionDocument]) -> EmitResult:
        """Generate Pandas Python code from an AST.

        Args:
            ast: The root node of the AST (LetExpression or SectionDocument).

        Returns:
            EmitResult containing success status, generated code, and warnings.
        """
        self.imports = ["import pandas as pd"]
        self.helpers = []
        self.statements = []
        self.warnings = []
        self.result_variable = None
        self._needs_try_otherwise_helper = False
        self._record_variables = set()
        self._table_variables = set()
        self.lakehouse_references = []
        self.lakehouse_roots = set()
        self.section_var_map = {}
        self.let_var_map = {}

        try:
            # Extract lakehouse references before code generation if it's a section document
            if isinstance(ast, SectionDocument):
                self._extract_lakehouse_references(ast)

            ast.accept(self)
            # Add helper functions if needed
            if self._needs_try_otherwise_helper:
                self.helpers.append(
                    "def _try_otherwise(try_fn, otherwise_fn):\n"
                    "    try:\n"
                    "        return try_fn()\n"
                    "    except Exception:\n"
                    "        return otherwise_fn()"
                )
            code = self._generate_code()
            return EmitResult(
                success=True,
                code=code,
                warnings=self.warnings,
                lakehouses=self.lakehouse_references if self.lakehouse_references else []
            )
        except Exception as e:
            self.warnings.append(f"Emission error: {e}")
            return EmitResult(success=False, warnings=self.warnings)

    def _generate_code(self) -> str:
        """Generate the final Python code string."""
        lines = []
        lines.extend(self.imports)
        lines.append("")  # Blank line after imports
        if self.helpers:
            for helper in self.helpers:
                lines.append(helper)
            lines.append("")  # Blank line after helpers
        lines.extend(self.statements)
        return "\n".join(lines)

    def _is_record_variable(self, name: str) -> bool:
        """Check if a variable name refers to a record."""
        return name in self._record_variables

    def _is_record_expression(self, node: ASTNode) -> bool:
        """Check if an expression is a record (literal or identifier)."""
        if isinstance(node, RecordLiteral):
            return True
        if isinstance(node, Identifier):
            return self._is_record_variable(node.name)
        return False

    def _is_table_variable(self, name: str) -> bool:
        """Check if a variable name refers to a table."""
        return name in self._table_variables

    def _is_table_expression(self, node: ASTNode) -> bool:
        """Check if an expression is a table (function call or identifier)."""
        if isinstance(node, Identifier):
            return self._is_table_variable(node.name)
        if isinstance(node, FunctionCall):
            func_name = self._get_function_name(node.function)
            # Common table-producing functions
            return func_name in ("#table", "Table.FromRecords", "Table.FromRows",
                                  "Table.SelectColumns", "Table.RemoveColumns",
                                  "Table.RenameColumns", "Table.SelectRows",
                                  "Table.AddColumn", "Table.Skip", "Table.FillDown",
                                  "Table.PromoteHeaders", "Table.TransformColumnTypes",
                                  "Table.UnpivotOtherColumns", "Table.Pivot",
                                  "Table.Combine", "Table.Join", "Table.NestedJoin",
                                  "Table.ExpandTableColumn", "Table.Group",
                                  "Csv.Document")
        return False

    def visit_let_expression(self, node: LetExpression) -> Any:
        """Visit a let expression.

        Performs topological sort to emit statements in dependency order,
        supporting M's forward reference semantics.
        """
        # Build variable name -> assignment mapping
        var_map: Dict[str, VariableAssignment] = {}
        for var in node.variables:
            var_map[var.name] = var

        previous_let_var_map = self.let_var_map
        self.let_var_map = {name: assignment.value for name, assignment in var_map.items()}

        # Build dependency graph
        deps: Dict[str, Set[str]] = {}
        for var in node.variables:
            var_deps = self._extract_dependencies(var.value, var_map.keys())
            # Remove self-reference (e.g., try X otherwise Y where X is the var being defined)
            var_deps.discard(var.name)
            deps[var.name] = var_deps

        # Topological sort
        sorted_vars = self._topological_sort(deps)

        # Process variables in dependency order
        try:
            for var_name in sorted_vars:
                if var_name in var_map:
                    var_map[var_name].accept(self)
        finally:
            self.let_var_map = previous_let_var_map

        # Process the result expression to determine the result variable
        if node.result:
            if isinstance(node.result, Identifier):
                self.result_variable = node.result.name
            return node.result.accept(self)

        return None

    def _extract_dependencies(self, node: Optional[ASTNode], var_names: set) -> Set[str]:
        """Extract variable dependencies from an expression.

        Args:
            node: The AST node to analyze.
            var_names: Set of variable names defined in the let expression.

        Returns:
            Set of variable names that this expression depends on.
        """
        deps: Set[str] = set()

        if node is None:
            return deps

        if isinstance(node, Identifier):
            if node.name in var_names:
                deps.add(node.name)

        elif isinstance(node, FunctionCall):
            # Check function reference - but skip if it's a qualified function name (like Table.SelectRows)
            # Function names should not be treated as variable dependencies
            if node.function:
                # Only extract dependencies from function reference if it's a plain identifier
                # that could be a variable holding a function
                if isinstance(node.function, Identifier):
                    deps.update(self._extract_dependencies(node.function, var_names))
                # For MemberAccess function names (like Table.SelectRows), skip dependency extraction
                # as these are standard library function references, not variable references
            # Check all arguments
            for arg in node.arguments:
                deps.update(self._extract_dependencies(arg, var_names))

        elif isinstance(node, MemberAccess):
            if node.object:
                deps.update(self._extract_dependencies(node.object, var_names))

        elif isinstance(node, BinaryExpression):
            if node.left:
                deps.update(self._extract_dependencies(node.left, var_names))
            if node.right:
                deps.update(self._extract_dependencies(node.right, var_names))

        elif isinstance(node, EachExpression):
            if node.body:
                deps.update(self._extract_dependencies(node.body, var_names))

        elif isinstance(node, ListLiteral):
            for item in node.items:
                deps.update(self._extract_dependencies(item, var_names))

        elif isinstance(node, TryExpression):
            if node.expression:
                deps.update(self._extract_dependencies(node.expression, var_names))
            if node.otherwise_expr:
                deps.update(self._extract_dependencies(node.otherwise_expr, var_names))

        elif isinstance(node, IfExpression):
            if node.condition:
                deps.update(self._extract_dependencies(node.condition, var_names))
            if node.then_expr:
                deps.update(self._extract_dependencies(node.then_expr, var_names))
            if node.else_expr:
                deps.update(self._extract_dependencies(node.else_expr, var_names))

        elif isinstance(node, UnaryExpression):
            if node.operand:
                deps.update(self._extract_dependencies(node.operand, var_names))

        elif isinstance(node, LetExpression):
            # For nested let, extract deps from variable values and result
            for var in node.variables:
                if var.value:
                    deps.update(self._extract_dependencies(var.value, var_names))
            if node.result:
                deps.update(self._extract_dependencies(node.result, var_names))

        elif isinstance(node, ItemAccess):
            # Item access: target{index} - both target and index may reference variables
            if node.target:
                deps.update(self._extract_dependencies(node.target, var_names))
            if node.index:
                deps.update(self._extract_dependencies(node.index, var_names))

        elif isinstance(node, FieldAccess):
            # Field access [FieldName] doesn't create variable dependencies
            # But if there's a target, extract deps from it
            if hasattr(node, 'target') and node.target:
                deps.update(self._extract_dependencies(node.target, var_names))

        return deps

    def _topological_sort(self, deps: Dict[str, Set[str]]) -> List[str]:
        """Perform topological sort on dependency graph.

        Uses Kahn's algorithm to produce a valid execution order.

        Args:
            deps: Mapping from variable name to set of dependencies.

        Returns:
            List of variable names in dependency order (dependencies first).

        Raises:
            ValueError: If there is a circular dependency.
        """
        # Compute in-degree for each node
        in_degree: Dict[str, int] = {name: 0 for name in deps}
        for name, dependencies in deps.items():
            for dep in dependencies:
                if dep in in_degree:
                    in_degree[name] += 1

        # Create a map for original order priority
        order_map = {name: i for i, name in enumerate(deps.keys())}

        # Start with nodes that have no dependencies
        queue = [name for name in deps if in_degree[name] == 0]
        queue.sort(key=lambda x: order_map[x])
        
        result: List[str] = []

        while queue:
            # Choose the first available node from the queue
            current = queue.pop(0)
            result.append(current)

            # Reduce in-degree for nodes that depend on current
            for name, dependencies in deps.items():
                if current in dependencies:
                    in_degree[name] -= 1
                    if in_degree[name] == 0:
                        queue.append(name)
            
            # Re-sort queue to maintain source order stability for ties
            queue.sort(key=lambda x: order_map[x])

        if len(result) != len(deps):
            # Circular dependency detected
            remaining = set(deps.keys()) - set(result)
            self.warnings.append(f"Circular dependency detected involving: {remaining}")
            # Add remaining nodes anyway to avoid losing code
            result.extend(remaining)

        return result

    def visit_variable_assignment(self, node: VariableAssignment) -> Any:
        """Visit a variable assignment."""
        if node.value:
            # Check if this is a NOP assignment (value is just an identifier)
            # If fold_queries is True, skip NOP assignments
            if self.fold_queries and isinstance(node.value, Identifier):
                # This is a NOP (e.g., Step1 = Source), skip it when folding
                return None

            # Check for lakehouse file pattern first
            filename = self._detect_lakehouse_file_pattern(node.value)
            if filename:
                # Emit optimized file read
                file_read_code = self._emit_lakehouse_file_read(filename)
                self.statements.append(f"{node.name} = {file_read_code}")
                self._table_variables.add(node.name)
                return None

            # Track if this variable holds a record
            if isinstance(node.value, RecordLiteral):
                self._record_variables.add(node.name)
            elif isinstance(node.value, BinaryExpression) and node.value.operator == "&":
                # If merging records, the result is also a record
                if self._is_record_expression(node.value.left) or self._is_record_expression(node.value.right):
                    self._record_variables.add(node.name)
                # If concatenating tables, the result is also a table
                elif self._is_table_expression(node.value.left) or self._is_table_expression(node.value.right):
                    self._table_variables.add(node.name)

            # Track if this variable holds a table
            if self._is_table_expression(node.value):
                self._table_variables.add(node.name)

            value_code = node.value.accept(self)
            if value_code:
                # Add comment if present
                if node.comment:
                    self.statements.append(f"# {node.comment}")

                # Handle Table.AddColumn result
                if isinstance(value_code, AddColumnResult):
                    self.statements.append(f"{node.name} = {value_code.table_code}.copy()")
                    self.statements.append(f"{node.name}['{value_code.column_name}'] = {value_code.expression_code}")
                # Handle unsupported function with graceful degradation
                elif isinstance(value_code, UnsupportedFunctionResult):
                    self.statements.append(f"{node.name} = {value_code.passthrough_code}  # {value_code.comment}")
                else:
                    self.statements.append(f"{node.name} = {value_code}")
        return None

    def visit_function_call(self, node: FunctionCall) -> Any:
        """Visit a function call."""
        # Get the function being called
        func_name = self._get_function_name(node.function)

        # Handle known M functions
        if func_name == "Csv.Document":
            return self._emit_csv_document(node)
        elif func_name == "File.Contents":
            return self._emit_file_contents(node)
        elif func_name == "Table.SelectColumns":
            return self._emit_table_select_columns(node)
        elif func_name == "Table.RemoveColumns":
            return self._emit_table_remove_columns(node)
        elif func_name == "Table.RenameColumns":
            return self._emit_table_rename_columns(node)
        elif func_name == "Table.SelectRows":
            return self._emit_table_select_rows(node)
        elif func_name == "Table.AddColumn":
            return self._emit_table_add_column(node)
        elif func_name == "Table.Skip":
            return self._emit_table_skip(node)
        elif func_name == "Table.Sort":
            return self._emit_table_sort(node)
        elif func_name == "Table.FirstN":
            return self._emit_table_first_n(node)
        elif func_name == "List.Distinct":
            return self._emit_list_distinct(node)
        elif func_name == "Table.FillDown":
            return self._emit_table_fill_down(node)
        elif func_name == "Table.PromoteHeaders":
            return self._emit_table_promote_headers(node)
        elif func_name == "#date":
            return self._emit_date_constructor(node)
        elif func_name == "Date.Month":
            return self._emit_date_month(node)
        elif func_name == "Date.Day":
            return self._emit_date_day(node)
        elif func_name == "Date.Year":
            return self._emit_date_year(node)
        elif func_name == "Table.TransformColumnTypes":
            return self._emit_table_transform_column_types(node)
        elif func_name == "Table.UnpivotOtherColumns":
            return self._emit_table_unpivot_other_columns(node)
        elif func_name == "Table.Pivot":
            return self._emit_table_pivot(node)
        elif func_name == "#table":
            return self._emit_table_constructor(node)
        elif func_name == "Table.FromRows":
            return self._emit_table_from_rows(node)
        elif func_name == "List.Select":
            return self._emit_list_select(node)
        elif func_name == "List.Transform":
            return self._emit_list_transform(node)
        elif func_name == "Table.Combine":
            return self._emit_table_combine(node)
        elif func_name == "Table.NestedJoin":
            return self._emit_table_nested_join(node)
        elif func_name == "Table.Join":
            return self._emit_table_join(node)
        elif func_name == "Table.ExpandTableColumn":
            return self._emit_table_expand_table_column(node)
        elif func_name == "Table.Group":
            return self._emit_table_group(node)
        elif func_name == "Table.AddIndexColumn":
            return self._emit_table_add_index_column(node)
        elif func_name == "Table.TransformColumns":
            return self._emit_table_transform_columns(node)
        elif func_name == "Table.RowCount":
            return self._emit_table_row_count(node)
        elif func_name == "List.Generate":
            return self._emit_list_generate(node)
        elif func_name == "List.Sum":
            return self._emit_list_sum(node)
        elif func_name == "List.Average":
            return self._emit_list_average(node)
        elif func_name == "List.Max":
            return self._emit_list_max(node)
        elif func_name == "List.Min":
            return self._emit_list_min(node)
        elif func_name == "List.Count":
            return self._emit_list_count(node)
        elif func_name == "Text.Trim":
            return self._emit_text_trim(node)
        elif func_name == "Text.From":
            return self._emit_text_from(node)
        elif func_name == "Text.Upper":
            return self._emit_text_upper(node)
        elif func_name == "Text.Lower":
            return self._emit_text_lower(node)
        elif func_name == "Text.Length":
            return self._emit_text_length(node)
        elif func_name == "Text.Contains":
            return self._emit_text_contains(node)
        elif func_name == "Text.Start":
            return self._emit_text_start(node)
        elif func_name == "Text.End":
            return self._emit_text_end(node)
        elif func_name == "Text.Replace":
            return self._emit_text_replace(node)
        elif func_name == "Table.HasColumns":
            return self._emit_table_has_columns(node)
        elif func_name == "Record.Field":
            return self._emit_record_field(node)
        elif func_name == "Web.Contents":
            return self._emit_web_contents(node)
        elif func_name == "Json.Document":
            return self._emit_json_document(node)
        elif func_name == "Table.FromRecords":
            return self._emit_table_from_records(node)
        elif func_name == "Lakehouse.Contents":
            return self._emit_lakehouse_contents(node)
        elif func_name == "Number.Abs":
            return self._emit_number_abs(node)
        elif func_name == "Number.Sign":
            return self._emit_number_sign(node)
        else:
            args = []
            for arg in node.arguments:
                arg_code = arg.accept(self)
                if isinstance(arg_code, UnsupportedFunctionResult):
                    arg_code = arg_code.passthrough_code
                if arg_code is None:
                    arg_code = "None"
                args.append(arg_code)

            sanitized_func_name = self._sanitize_identifier(func_name)
            if func_name != sanitized_func_name or "." in func_name:
                self.warnings.append(format_unsupported_message(func_name))

            return f"{sanitized_func_name}({', '.join(args)})"

    def visit_member_access(self, node: MemberAccess) -> Any:
        """Visit a member access expression."""
        if node.object:
            obj = node.object.accept(self)
            return f"{obj}.{node.member}"
        return node.member

    def visit_identifier(self, node: Identifier) -> Any:
        """Visit an identifier.

        If the identifier contains spaces or special characters (from #"..." syntax),
        emit it as a string literal since it represents a column name, not a variable.
        """
        if node.name == "_" and self._current_table:
            return self._current_table
        return self._sanitize_identifier(node.name)

    def visit_string_literal(self, node: StringLiteral) -> Any:
        """Visit a string literal."""
        # Escape any quotes and special characters in the string
        escaped = (
            node.value.replace("\\", "\\\\")  # Backslashes first
            .replace("'", "\\'")              # Single quotes
            .replace("\n", "\\n")             # Newlines
            .replace("\r", "\\r")             # Carriage returns
            .replace("\t", "\\t")             # Tabs
        )
        return f"'{escaped}'"

    def visit_list_literal(self, node: ListLiteral) -> Any:
        """Visit a list literal."""
        items = []
        for item in node.items:
            if isinstance(item, Identifier) and " " in item.name:
                escaped = item.name.replace("\\", "\\\\").replace("'", "\\'")
                items.append(f"'{escaped}'")
            else:
                items.append(item.accept(self))
        return f"[{', '.join(items)}]"

    def visit_number_literal(self, node: NumberLiteral) -> Any:
        """Visit a number literal."""
        return node.value

    def visit_each_expression(self, node: EachExpression) -> Any:
        """Visit an each expression.

        In the context of Table.SelectRows, this becomes the filter condition.
        """
        if node.body:
            return f"lambda _: {node.body.accept(self)}"
        return "lambda _: None"

    def visit_field_access(self, node: FieldAccess) -> Any:
        """Visit a field access.

        [FieldName] becomes df['FieldName'] in pandas context.
        When inside a Table.SelectRows or Table.AddColumn, uses the current table context.
        """
        table = self._current_table or "_"
        return f"{table}['{node.field_name}']"

    def visit_binary_expression(self, node: BinaryExpression) -> Any:
        """Visit a binary expression."""
        left = node.left.accept(self) if node.left else ""
        right = node.right.accept(self) if node.right else ""

        # Handle range operator (..) - inclusive range
        if node.operator == "..":
            return f"list(range({left}, {right} + 1))"

        # Handle null coalesce operator (??) specially
        # In pandas, use .fillna() for Series operations
        if node.operator == "??":
            return f"{left}.fillna({right})"

        # Handle concatenation operator (&) specially based on operand types
        if node.operator == "&":
            # Check if operands are records
            left_is_record = isinstance(node.left, RecordLiteral) or (
                isinstance(node.left, Identifier) and self._is_record_variable(node.left.name)
            )
            right_is_record = isinstance(node.right, RecordLiteral) or (
                isinstance(node.right, Identifier) and self._is_record_variable(node.right.name)
            )
            if left_is_record or right_is_record:
                return f"{{**{left}, **{right}}}"

            # Check if operands are tables - use pd.concat
            left_is_table = self._is_table_expression(node.left)
            right_is_table = self._is_table_expression(node.right)
            if left_is_table or right_is_table:
                return f"pd.concat([{left}, {right}], ignore_index=True)"

        # Map M operators to Python/pandas operators
        op_map = {
            "=": "==",
            "<>": "!=",
            ">": ">",
            "<": "<",
            ">=": ">=",
            "<=": "<=",
            "&": "+",  # Concatenation (text, list)
            "and": "&",
            "or": "|",
        }
        op = op_map.get(node.operator, node.operator)

        # Wrap logical expressions in parentheses for pandas
        if node.operator in ("and", "or"):
            return f"({left}) {op} ({right})"

        return f"{left} {op} {right}"

    def visit_unary_expression(self, node: UnaryExpression) -> Any:
        """Visit a unary expression."""
        operand = node.operand.accept(self) if node.operand else ""

        if node.operator == "not":
            return f"(not {operand})"

        return f"{node.operator}({operand})"

    def visit_type_check(self, node: TypeCheckExpression) -> Any:
        """Visit a type check expression."""
        operand = node.operand.accept(self) if node.operand else ""

        type_map = {
            "number": "(int, float)",
            "text": "str",
            "logical": "bool",
            "null": "type(None)",
        }
        python_type = type_map.get(node.type_name, "object")
        return f"isinstance({operand}, {python_type})"

    def visit_if_expression(self, node: IfExpression) -> Any:
        """Visit an if-then-else expression.

        For scalar conditions (like Table.HasColumns), uses Python ternary.
        For vectorized operations, uses np.where.
        """
        condition = node.condition.accept(self) if node.condition else "True"
        then_expr = node.then_expr.accept(self) if node.then_expr else "None"
        else_expr = node.else_expr.accept(self) if node.else_expr else "None"

        return f"({then_expr} if {condition} else {else_expr})"

    def _is_scalar_condition(self, condition: Optional[ASTNode]) -> bool:
        """Check if a condition is scalar (not vectorized).

        Scalar conditions include:
        - Table.HasColumns calls
        - Boolean comparisons involving non-column values
        """
        if condition is None:
            return False

        if isinstance(condition, FunctionCall):
            func_name = self._get_function_name(condition.function)
            # These functions return scalar boolean values
            if func_name in ("Table.HasColumns", "List.Contains", "Text.Contains"):
                return True

        return False

    def visit_null_literal(self, node: NullLiteral) -> Any:
        """Visit a null literal."""
        return "None"

    def visit_boolean_literal(self, node: BooleanLiteral) -> Any:
        """Visit a boolean literal."""
        return "True" if node.value else "False"

    def visit_type_expression(self, node: TypeExpression) -> Any:
        """Visit a type expression.

        Returns a string representation of the type for use in
        Table.TransformColumnTypes and similar functions.
        """
        # Return the type name as a string literal
        return f"'{node.type_name}'"

    def visit_try_expression(self, node: TryExpression) -> Any:
        """Visit a try-otherwise expression.

        Maps to Python try/except pattern. Uses a helper function to wrap the logic.
        """
        if node.expression is None:
            return "None"

        expr_code = node.expression.accept(self)

        if node.otherwise_expr is None:
            # try without otherwise - wrap in try/except returning None on error
            return f"(lambda: ({expr_code}))()"
        else:
            self._needs_try_otherwise_helper = True
            otherwise_code = node.otherwise_expr.accept(self)
            # Generate inline try/except using a helper pattern
            # We use a lambda with try/except to make it an expression
            return f"(_try_otherwise(lambda: {expr_code}, lambda: {otherwise_code}))"

    def visit_record_literal(self, node: RecordLiteral) -> Any:
        """Visit a record literal: [field1 = value1, ...].

        Maps to a Python dictionary.
        """
        if not node.fields:
            return "{}"
        
        field_code = []
        for field_name, field_value in node.fields.items():
            if field_value is not None:
                value_code = field_value.accept(self)
                field_code.append(f"'{field_name}': {value_code}")
        return "{" + ", ".join(field_code) + "}"

    def visit_function_expression(self, node: FunctionExpression) -> Any:
        """Visit a function expression: (x, y) => body.

        Maps to a Python lambda.
        Note: Some complex function expressions may not be fully supported.
        """
        self.warnings.append("Function expressions have limited support in pandas emitter")
        params = []
        if node.parameters:
            for param in node.parameters:
                params.append(param.name)
        params_str = ", ".join(params) if params else ""
        
        if node.body is not None:
            body_code = node.body.accept(self)
        else:
            body_code = "None"
        
        return f"lambda {params_str}: {body_code}"

    def visit_item_access(self, node: ItemAccess) -> Any:
        """Visit item access: target[index] or target{index}.

        Maps to Python indexing with optional null-coalescing for optional access.
        """
        if node.target is None:
            return "None"
        
        target_code = node.target.accept(self)
        
        if node.index is None:
            return target_code
        
        index_code = node.index.accept(self)
        
        return f"{target_code}[{index_code}]"

    def visit_inclusive_identifier(self, node: InclusiveIdentifier) -> Any:
        """Visit an inclusive identifier: @name.

        Maps to the identifier name (for recursive references).
        """
        return self._sanitize_identifier(node.name)

    def visit_error_expression(self, node: ErrorExpression) -> Any:
        """Visit an error expression: error <expr>.

        Maps to a Python raise statement (wrapped in a lambda).
        """
        self.warnings.append("Error expressions have limited support in pandas emitter")
        if node.expression is not None:
            expr_code = node.expression.accept(self)
            return f"(lambda: (_ for _ in ()).throw(RuntimeError({expr_code})))()"
        return f"(lambda: (_ for _ in ()).throw(RuntimeError('Error')))()"

    def visit_not_implemented_expression(self, node: NotImplementedExpression) -> Any:
        """Visit a not implemented expression: ...

        Maps to NotImplementedError.
        """
        self.warnings.append("Not implemented expressions cannot be transpiled")
        return "raise NotImplementedError('Not implemented')"

    def visit_meta_expression(self, node: MetaExpression) -> Any:
        """Visit a meta expression: value meta metadata.

        Meta expressions attach metadata to values. In pandas, we just emit
        the value (metadata is typically for documentation).
        """
        return node.value.accept(self) if node.value else ""

    def _get_function_name(self, func: Optional[ASTNode]) -> str:
        """Get the full name of a function (e.g., 'Csv.Document')."""
        if func is None:
            return ""
        if isinstance(func, Identifier):
            return func.name
        if isinstance(func, MemberAccess):
            if func.object:
                obj_name = self._get_function_name(func.object)
                return f"{obj_name}.{func.member}"
            return func.member
        return ""

    def _emit_csv_document(self, node: FunctionCall) -> str:
        """Emit code for Csv.Document(...).

        Csv.Document in M typically takes File.Contents(...) or Lakehouse file content
        as its first argument. We extract the file path and generate pd.read_csv(...).
        """
        if not node.arguments:
            self.warnings.append("Csv.Document called with no arguments")
            return "pd.read_csv('')"

        first_arg = node.arguments[0]

        # Check if the first argument is a Lakehouse file pattern
        filename = self._detect_lakehouse_file_pattern(first_arg)
        if filename:
            return self._emit_lakehouse_file_read(filename)

        # If the first argument is File.Contents(...), extract the path
        if isinstance(first_arg, FunctionCall):
            func_name = self._get_function_name(first_arg.function)
            if func_name == "File.Contents":
                path = self._emit_file_contents(first_arg)
                return f"pd.read_csv({path})"

        # If the argument is an identifier that we've already marked as a table,
        # it's likely the result of a lakehouse read - just return it
        if isinstance(first_arg, Identifier):
            if first_arg.name in self._table_variables:
                return first_arg.name

        # Otherwise, try to evaluate the argument directly
        arg_code = first_arg.accept(self)
        return f"pd.read_csv({arg_code})"

    def _emit_file_contents(self, node: FunctionCall) -> str:
        """Emit code for File.Contents(...).

        File.Contents takes a path string and returns binary content.
        For pd.read_csv, we just need the path string.
        """
        if not node.arguments:
            self.warnings.append("File.Contents called with no arguments")
            return "''"

        first_arg = node.arguments[0]
        if isinstance(first_arg, StringLiteral):
            # Escape and return the path
            escaped = first_arg.value.replace("\\", "\\\\").replace("'", "\\'")
            return f"'{escaped}'"

        # Otherwise, evaluate the argument
        return first_arg.accept(self)

    def _emit_table_select_columns(self, node: FunctionCall) -> str:
        """Emit code for Table.SelectColumns(table, columns).

        Table.SelectColumns returns only the specified columns.
        Maps to: df[columns] or df.loc[:, columns]
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.SelectColumns requires at least 2 arguments")
            return "# Table.SelectColumns: missing arguments"

        table_arg = node.arguments[0]
        columns_arg = node.arguments[1]

        # Get the table source
        table_code = table_arg.accept(self)

        # Get the columns list
        columns_code = columns_arg.accept(self)

        return f"{table_code}[{columns_code}]"

    def _emit_table_remove_columns(self, node: FunctionCall) -> str:
        """Emit code for Table.RemoveColumns(table, columns).

        Table.RemoveColumns returns all columns except the specified ones.
        Maps to: df.drop(columns=columns)
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.RemoveColumns requires at least 2 arguments")
            return "# Table.RemoveColumns: missing arguments"

        table_arg = node.arguments[0]
        columns_arg = node.arguments[1]

        # Get the table source
        table_code = table_arg.accept(self)

        # Get the columns list
        columns_code = columns_arg.accept(self)

        return f"{table_code}.drop(columns={columns_code})"

    def _emit_table_rename_columns(self, node: FunctionCall) -> str:
        """Emit code for Table.RenameColumns(table, renames).

        Table.RenameColumns renames columns in a table.
        M syntax: {{"old1", "new1"}, {"old2", "new2"}}
        Maps to: df.rename(columns={'old1': 'new1', 'old2': 'new2'})
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.RenameColumns requires at least 2 arguments")
            return "# Table.RenameColumns: missing arguments"

        table_arg = node.arguments[0]
        renames_arg = node.arguments[1]

        # Get the table source
        table_code = table_arg.accept(self)

        # Convert M list-of-lists to Python dict
        rename_dict = self._convert_renames_to_dict(renames_arg)

        return f"{table_code}.rename(columns={rename_dict})"

    def _convert_renames_to_dict(self, renames_node: ASTNode) -> str:
        """Convert M rename list to Python dict string.

        M format: {{"old1", "new1"}, {"old2", "new2"}}
        Python format: {'old1': 'new1', 'old2': 'new2'}
        """
        if not isinstance(renames_node, ListLiteral):
            self.warnings.append("Table.RenameColumns: expected list of renames")
            return "{}"

        pairs = []
        for item in renames_node.items:
            if isinstance(item, ListLiteral) and len(item.items) == 2:
                # Each item is a {old, new} pair
                old_name = item.items[0]
                new_name = item.items[1]
                if isinstance(old_name, StringLiteral) and isinstance(new_name, StringLiteral):
                    pairs.append(f"'{old_name.value}': '{new_name.value}'")

        return "{" + ", ".join(pairs) + "}"

    def _emit_table_select_rows(self, node: FunctionCall) -> str:
        """Emit code for Table.SelectRows(table, condition).

        Table.SelectRows filters rows based on a condition.
        M syntax: Table.SelectRows(Source, each [Value] > 100)
        Maps to: Source[Source['Value'] > 100]

        For complex predicates with let expressions, generates row-wise apply:
        M syntax: Table.SelectRows(Source, each let v = [Value] in v > 100)
        Maps to: Source[Source.apply(lambda row: (lambda v: v > 100)(row.get('Value')), axis=1)]
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.SelectRows requires at least 2 arguments")
            return "# Table.SelectRows: missing arguments"

        table_arg = node.arguments[0]
        condition_arg = node.arguments[1]

        # Get the table source (need the variable name for the condition)
        table_code = table_arg.accept(self)

        # Check if predicate contains LetExpression (requires row-wise apply)
        if self._contains_let_expression(condition_arg):
            # Generate row-wise filter function
            filter_code = self._emit_rowwise_filter(condition_arg)
            return f"{table_code}[{table_code}.apply({filter_code}, axis=1)].reset_index(drop=True)"

        # Simple vectorized condition
        self._current_table = table_code
        condition_code = self._emit_pandas_condition(condition_arg)
        self._current_table = None

        return f"{table_code}[{condition_code}].reset_index(drop=True)"

    def _contains_let_expression(self, node: ASTNode) -> bool:
        """Check if an AST node contains a LetExpression."""
        if isinstance(node, LetExpression):
            return True
        if isinstance(node, EachExpression) and node.body:
            return self._contains_let_expression(node.body)
        if isinstance(node, BinaryExpression):
            left_has = self._contains_let_expression(node.left) if node.left else False
            right_has = self._contains_let_expression(node.right) if node.right else False
            return left_has or right_has
        if isinstance(node, UnaryExpression) and node.operand:
            return self._contains_let_expression(node.operand)
        if isinstance(node, IfExpression):
            cond_has = self._contains_let_expression(node.condition) if node.condition else False
            then_has = self._contains_let_expression(node.then_expr) if node.then_expr else False
            else_has = self._contains_let_expression(node.else_expr) if node.else_expr else False
            return cond_has or then_has or else_has
        if isinstance(node, TryExpression):
            expr_has = self._contains_let_expression(node.expression) if node.expression else False
            other_has = self._contains_let_expression(node.otherwise_expr) if node.otherwise_expr else False
            return expr_has or other_has
        if isinstance(node, FunctionCall):
            for arg in node.arguments:
                if self._contains_let_expression(arg):
                    return True
        return False

    @python_only("Internal helper for compiling row-wise filter lambdas in Table.SelectRows")
    def _emit_rowwise_filter(self, condition_arg: ASTNode) -> str:
        """Emit a row-wise filter lambda for Table.SelectRows.

        Generates: lambda row: <expression>
        where field accesses become row.get('field')
        """
        # Unwrap each expression
        if isinstance(condition_arg, EachExpression) and condition_arg.body:
            body = condition_arg.body
        else:
            body = condition_arg

        # Generate row-wise expression
        expr_code = self._emit_rowwise_expression(body, "row")
        return f"lambda row: {expr_code}"

    @python_only("Internal helper for converting M expressions to row-wise Python expressions")
    def _emit_rowwise_expression(self, node: ASTNode, row_var: str = "row") -> str:
        """Emit an expression for row-wise evaluation.

        Converts M expressions to Python expressions that operate on a single row (dict).
        """
        if isinstance(node, LetExpression):
            # Build nested lambdas for let bindings to handle sequential dependencies
            # let a = x, b = f(a) in expr becomes:
            # (lambda a: (lambda b: expr)(f(a)))(x)
            result_code = self._emit_rowwise_expression(node.result, row_var) if node.result else "None"

            # Build inside-out: start with result, wrap with each variable binding
            code = result_code
            for var in reversed(node.variables):
                var_value = self._emit_rowwise_expression(var.value, row_var) if var.value else "None"
                code = f"(lambda {var.name}: {code})({var_value})"

            return code

        if isinstance(node, FieldAccess):
            return f"{row_var}.get('{node.field_name}')"

        if isinstance(node, Identifier):
            if node.name == "_":
                return row_var
            return node.name

        if isinstance(node, BinaryExpression):
            if isinstance(node.right, NullLiteral):
                left = self._emit_rowwise_expression(node.left, row_var) if node.left else ""
                if node.operator == "=":
                    return f"pd.isna({left})"
                if node.operator == "<>":
                    return f"pd.notna({left})"
            if isinstance(node.left, NullLiteral):
                right = self._emit_rowwise_expression(node.right, row_var) if node.right else ""
                if node.operator == "=":
                    return f"pd.isna({right})"
                if node.operator == "<>":
                    return f"pd.notna({right})"
            left = self._emit_rowwise_expression(node.left, row_var) if node.left else ""
            right = self._emit_rowwise_expression(node.right, row_var) if node.right else ""

            op_map = {
                "=": "==",
                "<>": "!=",
                ">": ">",
                "<": "<",
                ">=": ">=",
                "<=": "<=",
                "&": "+",  # Text concatenation
                "and": "and",
                "or": "or",
            }
            op = op_map.get(node.operator, node.operator)
            return f"({left} {op} {right})"

        if isinstance(node, UnaryExpression):
            operand = self._emit_rowwise_expression(node.operand, row_var) if node.operand else ""
            if node.operator == "not":
                return f"(not {operand})"
            if node.operator == "-":
                return f"(-{operand})"
            return f"{node.operator}({operand})"

        if isinstance(node, IfExpression):
            condition = self._emit_rowwise_expression(node.condition, row_var) if node.condition else "True"
            then_expr = self._emit_rowwise_expression(node.then_expr, row_var) if node.then_expr else "None"
            else_expr = self._emit_rowwise_expression(node.else_expr, row_var) if node.else_expr else "None"
            return f"({then_expr} if {condition} else {else_expr})"

        if isinstance(node, TryExpression):
            self._needs_try_otherwise_helper = True
            expr_code = self._emit_rowwise_expression(node.expression, row_var) if node.expression else "None"
            if node.otherwise_expr:
                otherwise_code = self._emit_rowwise_expression(node.otherwise_expr, row_var)
                return f"(_try_otherwise(lambda: {expr_code}, lambda: {otherwise_code}))"
            return f"(lambda: {expr_code})()"

        if isinstance(node, FunctionCall):
            func_name = self._get_function_name(node.function)
            args = [self._emit_rowwise_expression(arg, row_var) for arg in node.arguments]

            # Map M functions to Python for row-wise operations
            if func_name == "Text.Trim":
                return f"str({args[0]}).strip()" if args else "str().strip()"
            if func_name == "Text.From":
                return f"str({args[0]})" if args else "str()"
            if func_name == "Text.Upper":
                return f"str({args[0]}).upper()" if args else "str().upper()"
            if func_name == "Text.Lower":
                return f"str({args[0]}).lower()" if args else "str().lower()"
            if func_name == "Text.Length":
                return f"len(str({args[0]}))" if args else "0"
            if func_name == "Text.Contains":
                return f"({args[1]} in str({args[0]}))" if len(args) >= 2 else "False"
            if func_name == "Record.Field":
                return f"{args[0]}[{args[1]}]" if len(args) >= 2 else "None"

            # Fallback: emit function call as-is
            self.warnings.append(f"Row-wise emission for {func_name} may not work correctly")
            return f"{func_name}({', '.join(args)})"

        if isinstance(node, NumberLiteral):
            return str(node.value)

        if isinstance(node, StringLiteral):
            escaped = node.value.replace("\\", "\\\\").replace("'", "\\'")
            return f"'{escaped}'"

        if isinstance(node, NullLiteral):
            return "None"

        if isinstance(node, BooleanLiteral):
            return "True" if node.value else "False"

        if isinstance(node, ListLiteral):
            items = [self._emit_rowwise_expression(item, row_var) for item in node.items]
            return f"[{', '.join(items)}]"

        if isinstance(node, TypeCheckExpression):
            operand = self._emit_rowwise_expression(node.operand, row_var) if node.operand else ""
            if node.type_name == "null":
                return f"({operand} is None)"
            elif node.type_name == "number":
                return f"isinstance({operand}, (int, float))"
            return f"# Unsupported type check: is {node.type_name}"

        # Fallback
        return str(node) if node else "None"

    def _emit_table_add_column(self, node: FunctionCall) -> str:
        """Emit code for Table.AddColumn(table, newColumnName, each expression).

        Table.AddColumn adds a new computed column.
        M syntax: Table.AddColumn(Source, "FullName", each [FirstName] & " " & [LastName])
        Maps to: (lambda df: df.assign(FullName=df['FirstName'] + ' ' + df['LastName']))(Source)

        Returns a special marker that visit_variable_assignment handles.
        """
        if len(node.arguments) < 3:
            self.warnings.append("Table.AddColumn requires 3 arguments")
            return "# Table.AddColumn: missing arguments"

        table_arg = node.arguments[0]
        column_name_arg = node.arguments[1]
        expression_arg = node.arguments[2]

        # Get the table source
        table_code = table_arg.accept(self)

        # Get the new column name
        if isinstance(column_name_arg, StringLiteral):
            column_name = column_name_arg.value
        else:
            column_name = column_name_arg.accept(self)

        # Process the expression with table context
        self._current_table = table_code
        expr_code = self._emit_pandas_expression(expression_arg)
        self._current_table = None

        # Return structured result for visit_variable_assignment to handle
        return AddColumnResult(
            table_code=table_code,
            column_name=column_name,
            expression_code=expr_code
        )

    def _emit_pandas_expression(self, expr_node: ASTNode) -> str:
        """Emit an expression, prefixing field accesses with table name."""
        if isinstance(expr_node, EachExpression):
            return self._emit_pandas_expression(expr_node.body) if expr_node.body else ""

        if isinstance(expr_node, UnaryExpression):
            operand = self._emit_pandas_expression(expr_node.operand) if expr_node.operand else ""
            if expr_node.operator == "not":
                return f"~({operand})"
            return f"{expr_node.operator}({operand})"

        if isinstance(expr_node, BinaryExpression):
            left = self._emit_pandas_expression(expr_node.left) if expr_node.left else ""
            right = self._emit_pandas_expression(expr_node.right) if expr_node.right else ""

            # Handle null coalesce operator (??) specially
            if expr_node.operator == "??":
                return f"{left}.fillna({right})"

            op_map = {
                "=": "==",
                "<>": "!=",
                ">": ">",
                "<": "<",
                ">=": ">=",
                "<=": "<=",
                "&": "+",  # Text concatenation
                "and": "&",
                "or": "|",
            }
            op = op_map.get(expr_node.operator, expr_node.operator)

            # Wrap logical expressions in parentheses for pandas
            if expr_node.operator in ("and", "or"):
                return f"({left}) {op} ({right})"

            return f"{left} {op} {right}"

        if isinstance(expr_node, FieldAccess):
            return f"{self._current_table}['{expr_node.field_name}']"

        if isinstance(expr_node, NumberLiteral):
            return expr_node.value

        if isinstance(expr_node, StringLiteral):
            escaped = expr_node.value.replace("\\", "\\\\").replace("'", "\\'")
            return f"'{escaped}'"

        if isinstance(expr_node, TypeCheckExpression):
            operand = self._emit_pandas_expression(expr_node.operand) if expr_node.operand else ""
            if expr_node.type_name == "null":
                return f"{operand}.isna()"
            elif expr_node.type_name == "number":
                return f"pd.to_numeric({operand}, errors='coerce').notna()"
            return f"# Unsupported type check: is {expr_node.type_name}"

        if isinstance(expr_node, IfExpression):
            condition = self._emit_pandas_expression(expr_node.condition) if expr_node.condition else "True"
            then_expr = self._emit_pandas_expression(expr_node.then_expr) if expr_node.then_expr else "None"
            else_expr = self._emit_pandas_expression(expr_node.else_expr) if expr_node.else_expr else "None"
            if "import numpy as np" not in self.imports:
                self.imports.append("import numpy as np")
            return f"np.where({condition}, {then_expr}, {else_expr})"

        if isinstance(expr_node, NullLiteral):
            return "None"

        if isinstance(expr_node, BooleanLiteral):
            return "True" if expr_node.value else "False"

        # Fallback to regular visitor
        return expr_node.accept(self) if expr_node else ""

    def _emit_pandas_condition(self, condition_node: ASTNode) -> str:
        """Emit a filter condition, prefixing field accesses with table name."""
        # Reuse _emit_pandas_expression for conditions
        return self._emit_pandas_expression(condition_node)

    def _emit_table_skip(self, node: FunctionCall) -> str:
        """Emit code for Table.Skip(table, count).

        Table.Skip skips the first N rows.
        Maps to: df.iloc[n:].reset_index(drop=True)
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.Skip requires 2 arguments")
            return "# Table.Skip: missing arguments"

        table_arg = node.arguments[0]
        count_arg = node.arguments[1]

        # Get the table source
        table_code = table_arg.accept(self)

        # Get the count
        count_code = count_arg.accept(self)

        return f"{table_code}.iloc[{count_code}:].reset_index(drop=True)"

    def _emit_table_sort(self, node: FunctionCall) -> str:
        """Emit code for Table.Sort(table, sortSpecs).

        Table.Sort sorts a table by one or more columns.
        sortSpecs is a list of {column, order} records or {column} records.
        Order: Order.Ascending (0) or Order.Descending (1).
        Maps to: df.sort_values(by=[...], ascending=[...])
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.Sort requires 2 arguments")
            return "# Table.Sort: missing arguments"

        table_arg = node.arguments[0]
        sort_arg = node.arguments[1]

        # Get the table source
        table_code = table_arg.accept(self)

        # Parse sort specifications
        if isinstance(sort_arg, ListLiteral):
            sort_specs = []
            for item in sort_arg.items:
                if isinstance(item, ListLiteral) and len(item.items) >= 1:
                    # Format: {"ColumnName", Order.Ascending} or {"ColumnName", 0}
                    col_node = item.items[0]
                    if isinstance(col_node, StringLiteral):
                        col_name = col_node.value
                        # Default to ascending unless explicitly set to Order.Descending (1)
                        ascending = True
                        if len(item.items) >= 2:
                            order_node = item.items[1]
                            if isinstance(order_node, NumberLiteral):
                                ascending = order_node.value != 1
                        sort_specs.append((col_name, ascending))

            if sort_specs:
                cols = [f"'{col}'" for col, _ in sort_specs]
                ascending_list = [str(asc) for _, asc in sort_specs]
                return f"{table_code}.sort_values(by=[{', '.join(cols)}], ascending=[{', '.join(ascending_list)}])"

        return f"{table_code}.sort_values(...)"

    def _emit_table_first_n(self, node: FunctionCall) -> str:
        """Emit code for Table.FirstN(table, count).

        Table.FirstN returns the first N rows of a table.
        Maps to: df.head(n)
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.FirstN requires 2 arguments")
            return "# Table.FirstN: missing arguments"

        table_arg = node.arguments[0]
        count_arg = node.arguments[1]

        # Get the table source
        table_code = table_arg.accept(self)

        # Get the count
        count_code = count_arg.accept(self)

        return f"{table_code}.head({count_code})"

    def _emit_list_distinct(self, node: FunctionCall) -> str:
        """Emit code for List.Distinct(list).

        List.Distinct returns unique values preserving order.
        Maps to: list(dict.fromkeys(...))
        """
        if len(node.arguments) < 1:
            self.warnings.append("List.Distinct requires 1 argument")
            return "# List.Distinct: missing arguments"

        list_arg = node.arguments[0]
        list_code = list_arg.accept(self)

        return f"list(dict.fromkeys({list_code}))"

    def _emit_table_fill_down(self, node: FunctionCall) -> str:
        """Emit code for Table.FillDown(table, columns).

        Table.FillDown fills null values with the previous non-null value.
        Maps to: df.assign(**{col: df[col].ffill() for col in cols})
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.FillDown requires 2 arguments")
            return "# Table.FillDown: missing arguments"

        table_arg = node.arguments[0]
        columns_arg = node.arguments[1]

        # Get the table source
        table_code = table_arg.accept(self)

        # Get the columns list
        columns_code = columns_arg.accept(self)

        return f"{table_code}.assign(**{{col: {table_code}[col].ffill() for col in {columns_code}}})"

    def _emit_table_promote_headers(self, node: FunctionCall) -> str:
        """Emit code for Table.PromoteHeaders(table).

        Table.PromoteHeaders uses the first row as column headers.
        Maps to setting df.columns from first row, then slicing.
        """
        if len(node.arguments) < 1:
            self.warnings.append("Table.PromoteHeaders requires 1 argument")
            return "# Table.PromoteHeaders: missing arguments"

        table_arg = node.arguments[0]
        table_code = table_arg.accept(self)

        # Use a lambda to do the transformation inline
        return f"(lambda df: df.iloc[1:].set_axis(df.iloc[0].tolist(), axis=1).reset_index(drop=True))({table_code})"

    def _emit_date_constructor(self, node: FunctionCall) -> str:
        """Emit code for #date(year, month, day).

        #date constructs a date from year, month, day.
        Maps to: pd.to_datetime({'year': ..., 'month': ..., 'day': ...})
        """
        if len(node.arguments) < 3:
            self.warnings.append("#date requires 3 arguments (year, month, day)")
            return "# #date: missing arguments"

        year = node.arguments[0].accept(self)
        month = node.arguments[1].accept(self)
        day = node.arguments[2].accept(self)

        return f"pd.to_datetime({{'year': {year}, 'month': {month}, 'day': {day}}})"

    def _emit_date_month(self, node: FunctionCall) -> str:
        """Emit code for Date.Month(date).

        Date.Month extracts the month from a date.
        Maps to: .dt.month for Series, .month for scalar
        """
        if len(node.arguments) < 1:
            self.warnings.append("Date.Month requires 1 argument")
            return "# Date.Month: missing arguments"

        date_arg = node.arguments[0].accept(self)
        return f"{date_arg}.dt.month"

    def _emit_date_day(self, node: FunctionCall) -> str:
        """Emit code for Date.Day(date).

        Date.Day extracts the day from a date.
        Maps to: .dt.day for Series, .day for scalar
        """
        if len(node.arguments) < 1:
            self.warnings.append("Date.Day requires 1 argument")
            return "# Date.Day: missing arguments"

        date_arg = node.arguments[0].accept(self)
        return f"{date_arg}.dt.day"

    def _emit_date_year(self, node: FunctionCall) -> str:
        """Emit code for Date.Year(date).

        Date.Year extracts the year from a date.
        Maps to: .dt.year for Series, .year for scalar
        """
        if len(node.arguments) < 1:
            self.warnings.append("Date.Year requires 1 argument")
            return "# Date.Year: missing arguments"

        date_arg = node.arguments[0].accept(self)
        return f"{date_arg}.dt.year"

    def _emit_table_transform_column_types(self, node: FunctionCall) -> str:
        """Emit code for Table.TransformColumnTypes(table, transformations).

        Table.TransformColumnTypes changes column data types.
        For now, this is a pass-through since pandas infers types.
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.TransformColumnTypes requires 2 arguments")
            return "# Table.TransformColumnTypes: missing arguments"

        table_arg = node.arguments[0]
        table_code = table_arg.accept(self)

        # For now, just return the table unchanged
        # A full implementation would parse the type transformations
        return table_code

    def _emit_table_unpivot_other_columns(self, node: FunctionCall) -> str:
        """Emit code for Table.UnpivotOtherColumns(table, pivotColumns, attrCol, valCol).

        Table.UnpivotOtherColumns converts wide format to long format.
        Maps to: pd.melt(df, id_vars=[...], var_name='...', value_name='...')
        """
        if len(node.arguments) < 4:
            self.warnings.append("Table.UnpivotOtherColumns requires 4 arguments")
            return "# Table.UnpivotOtherColumns: missing arguments"

        table_arg = node.arguments[0]
        pivot_cols_arg = node.arguments[1]
        attr_col_arg = node.arguments[2]
        value_col_arg = node.arguments[3]

        table_code = table_arg.accept(self)
        pivot_cols_code = pivot_cols_arg.accept(self)
        attr_col_code = attr_col_arg.accept(self)
        value_col_code = value_col_arg.accept(self)

        return f"pd.melt({table_code}, id_vars={pivot_cols_code}, var_name={attr_col_code}, value_name={value_col_code})"

    def _emit_table_pivot(self, node: FunctionCall) -> str:
        """Emit code for Table.Pivot(table, pivotColumn, valueColumn, aggFunc).

        Table.Pivot converts long format to wide format.
        Maps to: df.pivot_table(columns=..., values=..., aggfunc=...).reset_index()
        """
        if len(node.arguments) < 4:
            self.warnings.append("Table.Pivot requires 4 arguments")
            return "# Table.Pivot: missing arguments"

        table_arg = node.arguments[0]
        pivot_col_arg = node.arguments[1]
        value_col_arg = node.arguments[2]
        agg_func_arg = node.arguments[3]

        table_code = table_arg.accept(self)
        pivot_col_code = pivot_col_arg.accept(self)
        value_col_code = value_col_arg.accept(self)

        # Map M aggregation functions to pandas aggfunc
        agg_func = "'sum'"  # Default
        agg_func_name = self._get_function_name(agg_func_arg)
        if agg_func_name == "List.Sum":
            agg_func = "'sum'"
        elif agg_func_name == "List.Average":
            agg_func = "'mean'"
        elif agg_func_name == "List.Max":
            agg_func = "'max'"
        elif agg_func_name == "List.Min":
            agg_func = "'min'"
        elif agg_func_name == "List.Count":
            agg_func = "'count'"

        # Generate pivot_table code - index is all columns except pivot and value columns
        # We compute the index dynamically since we don't know column names at transpile time
        return (
            f"{table_code}.pivot_table("
            f"index=[c for c in {table_code}.columns if c not in [{pivot_col_code}, {value_col_code}]], "
            f"columns={pivot_col_code}, "
            f"values={value_col_code}, aggfunc={agg_func}).reset_index().rename_axis(None, axis=1)"
        )

    def _emit_table_constructor(self, node: FunctionCall) -> str:
        """Emit code for #table(columns, rows).

        #table creates a table from column names and row data.
        Supports two forms:
        1. #table({"col1", "col2"}, {{val1, val2}, ...}) - column names as list
        2. #table(type table [col1 = type1, col2 = type2], {{val1, val2}, ...}) - typed columns

        Maps to: pd.DataFrame(rows, columns=columns)
        """
        if len(node.arguments) < 2:
            self.warnings.append("#table requires 2 arguments (columns, rows)")
            return "# #table: missing arguments"

        columns_arg = node.arguments[0]
        rows_arg = node.arguments[1]

        # Check if first argument is a TypeExpression (typed table)
        if isinstance(columns_arg, TypeExpression) and columns_arg.type_name == "table" and columns_arg.columns:
            # Extract column names from the type definition
            column_names = list(columns_arg.columns.keys())
            columns_code = repr(column_names)
        else:
            # Get columns list from regular expression
            columns_code = columns_arg.accept(self)

        # Get rows - need to emit as list of lists
        rows_code = rows_arg.accept(self)

        return f"pd.DataFrame({rows_code}, columns={columns_code})"

    def _emit_table_from_rows(self, node: FunctionCall) -> str:
        """Emit code for Table.FromRows(rows, columns).

        Table.FromRows creates a table from row data and column names.
        Maps to: pd.DataFrame(rows, columns=columns)
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.FromRows requires 2 arguments (rows, columns)")
            return "# Table.FromRows: missing arguments"

        rows_arg = node.arguments[0]
        columns_arg = node.arguments[1]

        # Get rows list
        rows_code = rows_arg.accept(self)

        # Get columns list
        columns_code = columns_arg.accept(self)

        return f"pd.DataFrame({rows_code}, columns={columns_code})"

    def _emit_list_select(self, node: FunctionCall) -> str:
        """Emit code for List.Select(list, condition).

        List.Select filters a list based on a condition.
        Maps to: [x for x in list if condition(x)]
        """
        if len(node.arguments) < 2:
            self.warnings.append("List.Select requires 2 arguments (list, condition)")
            return "# List.Select: missing arguments"

        list_arg = node.arguments[0]
        condition_arg = node.arguments[1]

        list_code = list_arg.accept(self)

        # Handle each expression - convert to lambda condition
        if isinstance(condition_arg, EachExpression) and condition_arg.body:
            # Extract the condition, replacing _ with x
            condition_code = self._emit_lambda_body(condition_arg.body, "x")
            return f"[x for x in {list_code} if {condition_code}]"

        # Fallback for other conditions
        condition_code = condition_arg.accept(self)
        return f"[x for x in {list_code} if {condition_code}(x)]"

    def _emit_list_transform(self, node: FunctionCall) -> str:
        """Emit code for List.Transform(list, transform).

        List.Transform applies a function to each element.
        Maps to: [transform(x) for x in list]
        """
        if len(node.arguments) < 2:
            self.warnings.append("List.Transform requires 2 arguments (list, transform)")
            return "# List.Transform: missing arguments"

        list_arg = node.arguments[0]
        transform_arg = node.arguments[1]

        list_code = list_arg.accept(self)

        # Handle each expression - convert to lambda expression
        if isinstance(transform_arg, EachExpression) and transform_arg.body:
            # Extract the transform, replacing _ with x
            transform_code = self._emit_lambda_body(transform_arg.body, "x")
            return f"[{transform_code} for x in {list_code}]"

        # Fallback for other transforms
        transform_code = transform_arg.accept(self)
        return f"[{transform_code}(x) for x in {list_code}]"

    @python_only("Internal helper for compiling each expressions (_) to Python lambda bodies")
    def _emit_lambda_body(self, expr: ASTNode, var_name: str = "x") -> str:
        """Emit an expression body, replacing _ with the variable name.

        Used for converting M each expressions to Python list comprehensions.
        """
        if isinstance(expr, Identifier):
            if expr.name == "_":
                return var_name
            return expr.name

        if isinstance(expr, FieldAccess):
            return f"{var_name}['{expr.field_name}']"

        if isinstance(expr, ItemAccess):
            target = self._emit_lambda_body(expr.target, var_name) if expr.target else ""
            index = self._emit_lambda_body(expr.index, var_name) if expr.index else ""
            return f"{target}[{index}]"

        if isinstance(expr, BinaryExpression):
            left = self._emit_lambda_body(expr.left, var_name) if expr.left else ""
            right = self._emit_lambda_body(expr.right, var_name) if expr.right else ""

            op_map = {
                "=": "==",
                "<>": "!=",
                ">": ">",
                "<": "<",
                ">=": ">=",
                "<=": "<=",
                "&": "+",
                "and": "and",
                "or": "or",
            }
            op = op_map.get(expr.operator, expr.operator)
            return f"{left} {op} {right}"

        if isinstance(expr, UnaryExpression):
            operand = self._emit_lambda_body(expr.operand, var_name) if expr.operand else ""
            if expr.operator == "not":
                return f"not {operand}"
            return f"{expr.operator}{operand}"

        if isinstance(expr, NumberLiteral):
            return expr.value

        if isinstance(expr, StringLiteral):
            escaped = expr.value.replace("\\", "\\\\").replace("'", "\\'")
            return f"'{escaped}'"

        if isinstance(expr, ListLiteral):
            items = [self._emit_lambda_body(item, var_name) for item in expr.items]
            return f"[{', '.join(items)}]"

        if isinstance(expr, NullLiteral):
            return "None"

        if isinstance(expr, BooleanLiteral):
            return "True" if expr.value else "False"

        # Fallback to visitor
        return expr.accept(self) if expr else ""

    def _emit_table_lambda_body(self, expr: ASTNode, var_name: str = "x") -> str:
        """Emit an each expression body using table context."""
        previous_table = self._current_table
        self._current_table = var_name
        try:
            if isinstance(expr, EachExpression) and expr.body:
                expr_node = expr.body
            else:
                expr_node = expr
            return expr_node.accept(self)
        finally:
            self._current_table = previous_table

    def _emit_table_combine(self, node: FunctionCall) -> str:
        """Emit code for Table.Combine(tables).

        Table.Combine vertically combines multiple tables.
        Maps to: pd.concat(tables, ignore_index=True)
        """
        if len(node.arguments) < 1:
            self.warnings.append("Table.Combine requires 1 argument (list of tables)")
            return "# Table.Combine: missing arguments"

        tables_arg = node.arguments[0]
        tables_code = tables_arg.accept(self)

        return f"pd.concat({tables_code}, ignore_index=True)"

    def _emit_table_nested_join(self, node: FunctionCall) -> str:
        """Emit code for Table.NestedJoin(left, leftKey, right, rightKey, newCol).

        Table.NestedJoin performs a left outer join with nested table result.
        For pandas, we use merge with indicator, then group matching rows.
        """
        if len(node.arguments) < 5:
            self.warnings.append("Table.NestedJoin requires 5 arguments")
            return "# Table.NestedJoin: missing arguments"

        left_arg = node.arguments[0]
        left_key_arg = node.arguments[1]
        right_arg = node.arguments[2]
        right_key_arg = node.arguments[3]
        new_col_arg = node.arguments[4]

        left_code = left_arg.accept(self)
        right_code = right_arg.accept(self)

        # Get key column names
        if isinstance(left_key_arg, StringLiteral):
            left_key = f"'{left_key_arg.value}'"
        else:
            left_key = left_key_arg.accept(self)

        if isinstance(right_key_arg, StringLiteral):
            right_key = f"'{right_key_arg.value}'"
        else:
            right_key = right_key_arg.accept(self)

        if isinstance(new_col_arg, StringLiteral):
            new_col = f"'{new_col_arg.value}'"
        else:
            new_col = new_col_arg.accept(self)

        # For nested join, store matching rows as list of dicts for easy expansion
        return (
            f"(lambda l, r, lk, rk, nc: "
            f"l.assign(**{{nc: l[lk].apply(lambda k: r[r[rk] == k].drop(columns=[rk]).to_dict('records'))}}))"
            f"({left_code}, {right_code}, {left_key}, {right_key}, {new_col})"
        )

    def _emit_table_join(self, node: FunctionCall) -> str:
        """Emit code for Table.Join(left, leftKey, right, rightKey).

        Table.Join performs an inner join.
        Maps to: left.merge(right, left_on=leftKey, right_on=rightKey)
        """
        if len(node.arguments) < 4:
            self.warnings.append("Table.Join requires 4 arguments")
            return "# Table.Join: missing arguments"

        left_arg = node.arguments[0]
        left_key_arg = node.arguments[1]
        right_arg = node.arguments[2]
        right_key_arg = node.arguments[3]

        left_code = left_arg.accept(self)
        right_code = right_arg.accept(self)

        if isinstance(left_key_arg, StringLiteral):
            left_key = f"'{left_key_arg.value}'"
        else:
            left_key = left_key_arg.accept(self)

        if isinstance(right_key_arg, StringLiteral):
            right_key = f"'{right_key_arg.value}'"
        else:
            right_key = right_key_arg.accept(self)

        return f"{left_code}.merge({right_code}, left_on={left_key}, right_on={right_key})"

    def _emit_table_expand_table_column(self, node: FunctionCall) -> str:
        """Emit code for Table.ExpandTableColumn(table, column, expandColumns).

        Table.ExpandTableColumn expands a nested table column.
        """
        if len(node.arguments) < 3:
            self.warnings.append("Table.ExpandTableColumn requires 3 arguments")
            return "# Table.ExpandTableColumn: missing arguments"

        table_arg = node.arguments[0]
        column_arg = node.arguments[1]
        expand_cols_arg = node.arguments[2]

        table_code = table_arg.accept(self)

        if isinstance(column_arg, StringLiteral):
            column = f"'{column_arg.value}'"
        else:
            column = column_arg.accept(self)

        expand_cols_code = expand_cols_arg.accept(self)

        # Expand nested table column - explode list of dicts and extract columns
        return (
            f"(lambda df, col, exp_cols: "
            f"df.explode(col).reset_index(drop=True).assign("
            f"**{{c: lambda d, c=c: d[col].apply(lambda x: x.get(c) if isinstance(x, dict) else None) for c in exp_cols}}"
            f").drop(columns=[col]))"
            f"({table_code}, {column}, {expand_cols_code})"
        )

    def _emit_table_group(self, node: FunctionCall) -> str:
        """Emit code for Table.Group(table, groupColumns, aggregations).

        Table.Group groups by columns and applies aggregations.
        Maps to: table.groupby(cols).agg(...).reset_index()
        """
        if len(node.arguments) < 3:
            self.warnings.append("Table.Group requires 3 arguments")
            return "# Table.Group: missing arguments"

        table_arg = node.arguments[0]
        group_cols_arg = node.arguments[1]
        aggs_arg = node.arguments[2]

        table_code = table_arg.accept(self)
        group_cols_code = group_cols_arg.accept(self)

        # Parse aggregations - list of {newCol, each aggregation}
        agg_parts = []
        if isinstance(aggs_arg, ListLiteral):
            for agg_item in aggs_arg.items:
                if isinstance(agg_item, ListLiteral) and len(agg_item.items) >= 2:
                    new_col = agg_item.items[0]
                    agg_expr = agg_item.items[1]

                    if isinstance(new_col, StringLiteral):
                        col_name = new_col.value

                        # Parse the aggregation expression
                        agg_func, source_col = self._parse_aggregation(agg_expr)
                        if agg_func and source_col:
                            agg_parts.append((col_name, source_col, agg_func))

        if agg_parts:
            # Build the aggregation dict and rename mapping
            agg_dict_items = []
            rename_items = []
            for new_col, source_col, agg_func in agg_parts:
                agg_dict_items.append(f"'{source_col}': '{agg_func}'")
                if new_col != source_col:
                    rename_items.append(f"'{source_col}': '{new_col}'")

            agg_dict = "{" + ", ".join(agg_dict_items) + "}"
            result = f"{table_code}.groupby({group_cols_code}).agg({agg_dict}).reset_index()"

            if rename_items:
                rename_dict = "{" + ", ".join(rename_items) + "}"
                result += f".rename(columns={rename_dict})"

            return result

        # Fallback
        return f"{table_code}.groupby({group_cols_code}).agg('first').reset_index()"

    def _parse_aggregation(self, agg_expr: ASTNode) -> tuple:
        """Parse an aggregation expression like 'each List.Sum([Amount])'.

        Returns (agg_func, source_column) tuple.
        """
        if isinstance(agg_expr, EachExpression) and agg_expr.body:
            return self._parse_aggregation(agg_expr.body)

        if isinstance(agg_expr, FunctionCall):
            func_name = self._get_function_name(agg_expr.function)

            # Map M aggregation functions to pandas
            func_map = {
                "List.Sum": "sum",
                "List.Average": "mean",
                "List.Max": "max",
                "List.Min": "min",
                "List.Count": "count",
            }

            if func_name in func_map and agg_expr.arguments:
                agg_func = func_map[func_name]
                # Extract the column from [ColumnName]
                first_arg = agg_expr.arguments[0]
                if isinstance(first_arg, FieldAccess):
                    return (agg_func, first_arg.field_name)

        return (None, None)

    def _emit_table_add_index_column(self, node: FunctionCall) -> str:
        """Emit code for Table.AddIndexColumn(table, columnName, start, step).

        Table.AddIndexColumn adds an index column to the table.
        Maps to: table.assign(columnName=range(start, start + len(table) * step, step))
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.AddIndexColumn requires at least 2 arguments")
            return "# Table.AddIndexColumn: missing arguments"

        table_arg = node.arguments[0]
        col_name_arg = node.arguments[1]

        table_code = table_arg.accept(self)

        if isinstance(col_name_arg, StringLiteral):
            col_name = col_name_arg.value
        else:
            col_name = col_name_arg.accept(self).strip("'")

        # Default start and step
        start = "0"
        step = "1"

        if len(node.arguments) >= 3:
            start = node.arguments[2].accept(self)
        if len(node.arguments) >= 4:
            step = node.arguments[3].accept(self)

        return (
            f"(lambda df, s, st: df.assign(**{{'{col_name}': range(s, s + len(df) * st, st)}}))"
            f"({table_code}, {start}, {step})"
        )

    def _emit_table_transform_columns(self, node: FunctionCall) -> str:
        """Emit code for Table.TransformColumns(table, transformations).

        Table.TransformColumns applies transformations to specified columns.
        Maps to: table.assign(col=table['col'].apply(lambda x: ...))
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.TransformColumns requires 2 arguments")
            return "# Table.TransformColumns: missing arguments"

        table_arg = node.arguments[0]
        transforms_arg = node.arguments[1]

        table_code = table_arg.accept(self)

        # Parse transformations - list of {column, each transform}
        assign_parts = []
        if isinstance(transforms_arg, ListLiteral):
            for transform_item in transforms_arg.items:
                if isinstance(transform_item, ListLiteral) and len(transform_item.items) >= 2:
                    col_arg = transform_item.items[0]
                    transform_expr = transform_item.items[1]

                    if isinstance(col_arg, StringLiteral):
                        col_name = col_arg.value

                        # Parse the transform expression
                        transform_code = self._emit_table_lambda_body(transform_expr, "x")
                        if transform_code:
                            assign_parts.append(f"'{col_name}': {table_code}['{col_name}'].apply(lambda x: {transform_code})")

        if assign_parts:
            assign_dict = "{" + ", ".join(assign_parts) + "}"
            return f"{table_code}.assign(**{assign_dict})"

        # Fallback - no transformations
        return table_code

    def _emit_table_row_count(self, node: FunctionCall) -> str:
        """Emit code for Table.RowCount(table)."""
        if len(node.arguments) < 1:
            self.warnings.append("Table.RowCount requires 1 argument")
            return "# Table.RowCount: missing arguments"

        table_arg = node.arguments[0]
        table_code = table_arg.accept(self)
        return f"len({table_code})"

    def _emit_list_generate(self, node: FunctionCall) -> str:
        """Emit code for List.Generate(initial, condition, next).

        List.Generate creates a list using iteration.
        Maps to: a helper function that generates values iteratively.
        """
        if len(node.arguments) < 3:
            self.warnings.append("List.Generate requires 3 arguments")
            return "# List.Generate: missing arguments"

        initial_arg = node.arguments[0]
        condition_arg = node.arguments[1]
        next_arg = node.arguments[2]

        initial_code = initial_arg.accept(self)

        # Parse condition and next as each expressions
        if isinstance(condition_arg, EachExpression) and condition_arg.body:
            condition_code = self._emit_lambda_body(condition_arg.body, "_v")
        else:
            condition_code = condition_arg.accept(self)

        if isinstance(next_arg, EachExpression) and next_arg.body:
            next_code = self._emit_lambda_body(next_arg.body, "_v")
        else:
            next_code = next_arg.accept(self)

        # Generate using a simple while-loop equivalent via helper function
        return (
            f"(lambda: (lambda cond, nxt: "
            f"(lambda f, init: f(f, init, []))"
            f"(lambda rec, _v, acc: acc if not cond(_v) else rec(rec, nxt(_v), acc + [_v]), {initial_code}))"
            f"(lambda _v: {condition_code}, lambda _v: {next_code}))()"
        )

    def _emit_list_sum(self, node: FunctionCall) -> str:
        """Emit code for List.Sum(list).

        List.Sum returns the sum of a list.
        Maps to: sum(list)
        """
        if len(node.arguments) < 1:
            self.warnings.append("List.Sum requires 1 argument")
            return "# List.Sum: missing arguments"

        list_arg = node.arguments[0]
        list_code = list_arg.accept(self)

        return f"sum({list_code})"

    def _emit_list_average(self, node: FunctionCall) -> str:
        """Emit code for List.Average(list).

        List.Average returns the average of a list.
        Maps to: sum(list)/len(list) or statistics.mean(list)
        """
        if len(node.arguments) < 1:
            self.warnings.append("List.Average requires 1 argument")
            return "# List.Average: missing arguments"

        list_arg = node.arguments[0]
        list_code = list_arg.accept(self)

        return f"(sum({list_code}) / len({list_code}) if len({list_code}) > 0 else 0)"

    def _emit_list_max(self, node: FunctionCall) -> str:
        """Emit code for List.Max(list).

        List.Max returns the maximum of a list.
        Maps to: max(list)
        """
        if len(node.arguments) < 1:
            self.warnings.append("List.Max requires 1 argument")
            return "# List.Max: missing arguments"

        list_arg = node.arguments[0]
        list_code = list_arg.accept(self)

        return f"max({list_code})"

    def _emit_list_min(self, node: FunctionCall) -> str:
        """Emit code for List.Min(list).

        List.Min returns the minimum of a list.
        Maps to: min(list)
        """
        if len(node.arguments) < 1:
            self.warnings.append("List.Min requires 1 argument")
            return "# List.Min: missing arguments"

        list_arg = node.arguments[0]
        list_code = list_arg.accept(self)

        return f"min({list_code})"

    def _emit_list_count(self, node: FunctionCall) -> str:
        """Emit code for List.Count(list).

        List.Count returns the length of a list.
        Maps to: len(list)
        """
        if len(node.arguments) < 1:
            self.warnings.append("List.Count requires 1 argument")
            return "# List.Count: missing arguments"

        list_arg = node.arguments[0]
        list_code = list_arg.accept(self)

        return f"len({list_code})"

    def _emit_text_trim(self, node: FunctionCall) -> str:
        """Emit code for Text.Trim(text).

        Text.Trim removes leading and trailing whitespace.
        Maps to: str.strip()
        """
        if len(node.arguments) < 1:
            self.warnings.append("Text.Trim requires 1 argument")
            return "# Text.Trim: missing arguments"

        text_arg = node.arguments[0]
        text_code = text_arg.accept(self)

        return f"str({text_code}).strip()"

    def _emit_text_from(self, node: FunctionCall) -> str:
        """Emit code for Text.From(value).

        Text.From converts a value to text.
        Maps to: str(value)
        """
        if len(node.arguments) < 1:
            self.warnings.append("Text.From requires 1 argument")
            return "# Text.From: missing arguments"

        value_arg = node.arguments[0]
        value_code = value_arg.accept(self)

        return f"str({value_code})"

    def _emit_text_upper(self, node: FunctionCall) -> str:
        """Emit code for Text.Upper(text).

        Text.Upper converts text to uppercase.
        Maps to: str.upper()
        """
        if len(node.arguments) < 1:
            self.warnings.append("Text.Upper requires 1 argument")
            return "# Text.Upper: missing arguments"

        text_arg = node.arguments[0]
        text_code = text_arg.accept(self)

        return f"str({text_code}).upper()"

    def _emit_text_lower(self, node: FunctionCall) -> str:
        """Emit code for Text.Lower(text).

        Text.Lower converts text to lowercase.
        Maps to: str.lower()
        """
        if len(node.arguments) < 1:
            self.warnings.append("Text.Lower requires 1 argument")
            return "# Text.Lower: missing arguments"

        text_arg = node.arguments[0]
        text_code = text_arg.accept(self)

        return f"str({text_code}).lower()"

    def _emit_text_length(self, node: FunctionCall) -> str:
        """Emit code for Text.Length(text).

        Text.Length returns the number of characters in text.
        Maps to: len(str)
        """
        if len(node.arguments) < 1:
            self.warnings.append("Text.Length requires 1 argument")
            return "# Text.Length: missing arguments"

        text_arg = node.arguments[0]
        text_code = text_arg.accept(self)

        return f"len(str({text_code}))"

    def _emit_text_contains(self, node: FunctionCall) -> str:
        """Emit code for Text.Contains(text, substring).

        Text.Contains checks if text contains a substring.
        Maps to: substring in text
        """
        if len(node.arguments) < 2:
            self.warnings.append("Text.Contains requires 2 arguments")
            return "# Text.Contains: missing arguments"

        text_arg = node.arguments[0]
        substring_arg = node.arguments[1]

        text_code = text_arg.accept(self)
        substring_code = substring_arg.accept(self)

        return f"({substring_code} in str({text_code}))"

    def _emit_text_start(self, node: FunctionCall) -> str:
        """Emit code for Text.Start(text, count).

        Text.Start returns the first count characters of text.
        Maps to: str[:count]
        """
        if len(node.arguments) < 2:
            self.warnings.append("Text.Start requires 2 arguments")
            return "# Text.Start: missing arguments"

        text_arg = node.arguments[0]
        count_arg = node.arguments[1]

        text_code = text_arg.accept(self)
        count_code = count_arg.accept(self)

        return f"str({text_code})[{count_code}]"

    def _emit_text_end(self, node: FunctionCall) -> str:
        """Emit code for Text.End(text, count).

        Text.End returns the last count characters of text.
        Maps to: str[-count:]
        """
        if len(node.arguments) < 2:
            self.warnings.append("Text.End requires 2 arguments")
            return "# Text.End: missing arguments"

        text_arg = node.arguments[0]
        count_arg = node.arguments[1]

        text_code = text_arg.accept(self)
        count_code = count_arg.accept(self)

        return f"str({text_code})[-{count_code}:]"

    def _emit_text_replace(self, node: FunctionCall) -> str:
        """Emit code for Text.Replace(text, old, new).

        Text.Replace replaces occurrences of old with new in text.
        Maps to: str.replace(old, new)
        """
        if len(node.arguments) < 3:
            self.warnings.append("Text.Replace requires 3 arguments")
            return "# Text.Replace: missing arguments"

        text_arg = node.arguments[0]
        old_arg = node.arguments[1]
        new_arg = node.arguments[2]

        text_code = text_arg.accept(self)
        old_code = old_arg.accept(self)
        new_code = new_arg.accept(self)

        return f"str({text_code}).replace({old_code}, {new_code})"

    def _emit_table_has_columns(self, node: FunctionCall) -> str:
        """Emit code for Table.HasColumns(table, columns).

        Table.HasColumns checks if a table has the specified columns.
        Maps to: all(col in df.columns for col in columns)
        """
        if len(node.arguments) < 2:
            self.warnings.append("Table.HasColumns requires 2 arguments")
            return "# Table.HasColumns: missing arguments"

        table_arg = node.arguments[0]
        columns_arg = node.arguments[1]

        table_code = table_arg.accept(self)
        columns_code = columns_arg.accept(self)

        # Handle single column (string) vs list of columns
        if isinstance(columns_arg, StringLiteral):
            return f"({columns_code} in {table_code}.columns)"
        else:
            return f"all(col in {table_code}.columns for col in {columns_code})"

    def _emit_record_field(self, node: FunctionCall) -> str:
        """Emit code for Record.Field(record, fieldName).

        Record.Field accesses a field in a record.
        Maps to: record[fieldName] or record.get(fieldName)
        """
        if len(node.arguments) < 2:
            self.warnings.append("Record.Field requires 2 arguments")
            return "# Record.Field: missing arguments"

        record_arg = node.arguments[0]
        field_arg = node.arguments[1]

        record_code = record_arg.accept(self)
        field_code = field_arg.accept(self)

        return f"{record_code}[{field_code}]"

    def _emit_web_contents(self, node: FunctionCall) -> str:
        """Emit code for Web.Contents(url).

        Web.Contents fetches data from a URL.
        Maps to: requests.get(url).content
        """
        if len(node.arguments) < 1:
            self.warnings.append("Web.Contents requires 1 argument (url)")
            return "# Web.Contents: missing arguments"

        url_arg = node.arguments[0]
        url_code = url_arg.accept(self)

        return f"__import__('requests').get({url_code}).content"

    def _emit_json_document(self, node: FunctionCall) -> str:
        """Emit code for Json.Document(source).

        Json.Document parses JSON content.
        Maps to: json.loads(source)
        """
        if len(node.arguments) < 1:
            self.warnings.append("Json.Document requires 1 argument (source)")
            return "# Json.Document: missing arguments"

        source_arg = node.arguments[0]
        source_code = source_arg.accept(self)

        return f"__import__('json').loads({source_code})"

    def _emit_table_from_records(self, node: FunctionCall) -> str:
        """Emit code for Table.FromRecords(records).

        Table.FromRecords creates a table from a list of records (dicts).
        Maps to: pd.DataFrame(records)
        """
        if len(node.arguments) < 1:
            self.warnings.append("Table.FromRecords requires 1 argument (records)")
            return "# Table.FromRecords: missing arguments"

        records_arg = node.arguments[0]
        records_code = records_arg.accept(self)

        return f"pd.DataFrame.from_records({records_code})"

    def _emit_lakehouse_contents(self, node: FunctionCall) -> str:
        """Emit code for Lakehouse.Contents(...).

        Lakehouse.Contents returns a navigation table for Fabric lakehouses.
        When used standalone, returns a placeholder string.
        The full lakehouse navigation pattern is detected in visit_variable_assignment.
        """
        # Standalone Lakehouse.Contents is typically navigated further
        # Return a placeholder that will be enhanced when the pattern is detected
        return "'# Lakehouse.Contents() - navigation table (use fixture injection)'"

    def _emit_number_abs(self, node: FunctionCall) -> str:
        """Emit code for Number.Abs(number)."""
        if len(node.arguments) < 1:
            self.warnings.append("Number.Abs requires 1 argument")
            return "# Number.Abs: missing arguments"
        
        arg_code = node.arguments[0].accept(self)
        return f"Number_Abs({arg_code})"

    def _emit_number_sign(self, node: FunctionCall) -> str:
        """Emit code for Number.Sign(number)."""
        if len(node.arguments) < 1:
            self.warnings.append("Number.Sign requires 1 argument")
            return "# Number.Sign: missing arguments"
        
        arg_code = node.arguments[0].accept(self)
        return f"Number_Sign({arg_code})"

    def _is_lakehouse_root(self, node: ASTNode) -> bool:
        """Check if a node resolves to a Lakehouse.Contents call (possibly with navigation)."""
        current = node
        while current is not None:
            if isinstance(current, ItemAccess):
                current = current.target
            elif isinstance(current, FunctionCall):
                func_name = self._get_function_name(current.function)
                if func_name == "Lakehouse.Contents":
                    return True
                return False
            else:
                return False
        return False

    def _detect_lakehouse_file_pattern(self, node: ASTNode) -> Optional[str]:
        """Detect Lakehouse navigation pattern and extract the filename.

        The pattern is:
        Lakehouse.Contents(null){[workspaceId="..."]}[Data]
                                {[lakehouseId="..."]}[Data]
                                {[Id="Files"]}[Data]
                                {[Name="file.csv"]}[Content]

        Also handles wrapping in Csv.Document(...) and Let expressions.

        Returns the filename if pattern is detected, None otherwise.
        """
        current = node
        filename = None
        found_content_access = False
        found_lakehouse_call = False
        var_map: Dict[str, ASTNode] = {}
        seen_identifiers: Set[str] = set()

        # Track navigation steps as we unwind the chain
        while current is not None:
            if isinstance(current, LetExpression):
                # Capture variables for resolution and continue with result
                for v in current.variables:
                    var_map[v.name] = v.value
                current = current.result
                continue

            elif isinstance(current, Identifier):
                # Resolve variable if possible
                if current.name in seen_identifiers:
                    break
                seen_identifiers.add(current.name)
                if current.name in var_map:
                    current = var_map[current.name]
                    continue
                if current.name in self.let_var_map:
                    current = self.let_var_map[current.name]
                    continue
                if current.name in self.section_var_map:
                    current = self.section_var_map[current.name]
                    continue
                # Check if this variable refers to a known Lakehouse root
                if current.name in self.lakehouse_roots:
                    found_lakehouse_call = True
                break

            elif isinstance(current, ItemAccess):
                # Check if this is [Content] or [Data] access (StringLiteral index)
                if isinstance(current.index, StringLiteral):
                    if current.index.value == "Content":
                        found_content_access = True
                    # [Data] is intermediate navigation - continue
                    current = current.target
                # Check if this is a record predicate {[Name="filename"]}
                elif isinstance(current.index, RecordLiteral):
                    fields = current.index.fields
                    if "Name" in fields:
                        name_value = fields["Name"]
                        if isinstance(name_value, StringLiteral):
                            filename = name_value.value
                    current = current.target
                else:
                    # Unknown access pattern
                    current = current.target

            elif isinstance(current, FunctionCall):
                func_name = self._get_function_name(current.function)
                if func_name == "Lakehouse.Contents":
                    found_lakehouse_call = True
                    break
                elif func_name == "Csv.Document":
                    # Pass through Csv.Document
                    if current.arguments:
                        current = current.arguments[0]
                        continue
                break
            
            else:
                break

        if found_content_access and found_lakehouse_call and filename:
            return filename

        return None

    def _emit_lakehouse_file_read(self, filename: str) -> str:
        """Emit code to read a file from the lakehouse.

        Generates appropriate read call based on lakehouse_mode:
        - "fabric": Uses Fabric notebook paths (/lakehouse/default/Files/...)
        - "spark": Uses Spark DataFrame with .toPandas()
        - "fixture": Uses local fixture paths for testing
        """
        # Determine file type from extension
        ext = filename.lower().split('.')[-1] if '.' in filename else ''

        if self.lakehouse_mode == "spark":
            # Use Spark to read, then convert to pandas
            if ext == 'csv':
                return f"spark.read.csv('Files/{filename}', header=True, inferSchema=True).toPandas()"
            elif ext == 'parquet':
                return f"spark.read.parquet('Files/{filename}').toPandas()"
            elif ext == 'json':
                return f"spark.read.json('Files/{filename}').toPandas()"
            elif ext in ('xlsx', 'xls'):
                # Excel not directly supported by Spark, fall back to pandas
                return f"pd.read_excel('/lakehouse/default/Files/{filename}')"
            else:
                return f"spark.read.csv('Files/{filename}', header=True, inferSchema=True).toPandas()"

        elif self.lakehouse_mode == "fixture":
            # Local fixture paths for testing
            if ext == 'csv':
                return f"pd.read_csv('fixtures/{filename}')"
            elif ext == 'parquet':
                return f"pd.read_parquet('fixtures/{filename}')"
            elif ext == 'json':
                return f"pd.read_json('fixtures/{filename}')"
            elif ext in ('xlsx', 'xls'):
                return f"pd.read_excel('fixtures/{filename}')"
            else:
                return f"pd.read_csv('fixtures/{filename}')"

        else:  # "fabric" mode (default)
            # Fabric notebook paths - uses the mounted lakehouse
            if ext == 'csv':
                return f"pd.read_csv('/lakehouse/default/Files/{filename}')"
            elif ext == 'parquet':
                return f"pd.read_parquet('/lakehouse/default/Files/{filename}')"
            elif ext == 'json':
                return f"pd.read_json('/lakehouse/default/Files/{filename}')"
            elif ext in ('xlsx', 'xls'):
                return f"pd.read_excel('/lakehouse/default/Files/{filename}')"
            else:
                return f"pd.read_csv('/lakehouse/default/Files/{filename}')"

    def _extract_lakehouse_references(self, section: SectionDocument) -> None:
        """Extract lakehouse references from a section document.

        Extracts workspace ID and lakehouse ID from Lakehouse.Contents calls.
        Uses two strategies:
        1. Check document annotation for DefaultOutputDestinationSettings
        2. Scan all queries for Lakehouse.Contents references

        Multiple lakehouses are deduplicated and sorted with default first.
        """
        lakehouse_map: Dict[str, LakehouseReference] = {}
        default_destination_query_name: Optional[str] = None

        # Option 1: Check document annotation for default destination
        if section.document_annotation:
            fields = section.document_annotation.fields
            if "DefaultOutputDestinationSettings" in fields:
                dest_settings = fields["DefaultOutputDestinationSettings"]
                if isinstance(dest_settings, RecordLiteral):
                    dest_def_node = dest_settings.fields.get("DestinationDefinition")
                    if isinstance(dest_def_node, RecordLiteral):
                        query_name_node = dest_def_node.fields.get("QueryName")
                        if isinstance(query_name_node, StringLiteral):
                            default_destination_query_name = query_name_node.value

        # Option 2: Scan all queries for Lakehouse.Contents references
        for member in section.members:
            if member.value:
                lakehouse_info = self._extract_lakehouse_from_query(member.value)
                if lakehouse_info:
                    workspace_id, lakehouse_id = lakehouse_info
                    key = f"{workspace_id}:{lakehouse_id}"
                    if key not in lakehouse_map:
                        lakehouse_map[key] = LakehouseReference(
                            lakehouse_id=lakehouse_id,
                            workspace_id=workspace_id,
                            query_name=member.name,
                            is_default_destination=(member.name == default_destination_query_name)
                        )

        # Convert to list and sort with default first
        self.lakehouse_references = sorted(
            lakehouse_map.values(),
            key=lambda ref: (not ref.is_default_destination, ref.lakehouse_id)
        )

        # Add warning if multiple lakehouses found
        if len(self.lakehouse_references) > 1:
            lakehouse_names = [ref.query_name or ref.lakehouse_id for ref in self.lakehouse_references]
            self.warnings.append(
                f"Multiple lakehouses found: {', '.join(lakehouse_names)}. "
                f"Using default: {self.lakehouse_references[0].query_name or self.lakehouse_references[0].lakehouse_id}"
            )

    def _extract_lakehouse_from_query(self, node: ASTNode) -> Optional[Tuple[str, str]]:
        """Extract workspace ID and lakehouse ID from a query value.

        Walks through the AST to find Lakehouse.Contents calls and extract
        the workspace ID and lakehouse ID from record predicates.

        Returns:
            Tuple of (workspace_id, lakehouse_id) if found, None otherwise.
        """
        # Build variable map for let expressions
        var_map: Dict[str, ASTNode] = {}
        if isinstance(node, LetExpression):
            for assignment in node.variables:
                var_map[assignment.name] = assignment.value

        return self._extract_lakehouse_ids_from_node(node, var_map)

    def _extract_lakehouse_ids_from_node(
        self, node: ASTNode, var_map: Dict[str, ASTNode]
    ) -> Optional[Tuple[str, str]]:
        """Extract lakehouse IDs from a node by walking the navigation chain.

        Args:
            node: The AST node to extract from.
            var_map: Map of variable names to their values (for following references).

        Returns:
            Tuple of (workspace_id, lakehouse_id) if both found, None otherwise.
        """
        workspace_id: Optional[str] = None
        lakehouse_id: Optional[str] = None
        current: Optional[ASTNode] = node

        while current:
            if isinstance(current, ItemAccess):
                # Check if this is a record predicate with workspaceId or lakehouseId
                if isinstance(current.index, RecordLiteral):
                    fields = current.index.fields
                    if "workspaceId" in fields:
                        ws_node = fields["workspaceId"]
                        if isinstance(ws_node, StringLiteral):
                            workspace_id = ws_node.value
                    if "lakehouseId" in fields:
                        lh_node = fields["lakehouseId"]
                        if isinstance(lh_node, StringLiteral):
                            lakehouse_id = lh_node.value
                current = current.target
            elif isinstance(current, FunctionCall):
                func_name = self._get_function_name(current.function)
                if func_name == "Lakehouse.Contents":
                    break
                current = None
            elif isinstance(current, Identifier):
                # Follow variable reference
                current = var_map.get(current.name)
            elif isinstance(current, LetExpression):
                # Check the result expression
                return self._extract_lakehouse_ids_from_node(current.result, var_map)
            else:
                current = None

        return (workspace_id, lakehouse_id) if (workspace_id and lakehouse_id) else None

    def visit_section_document(self, node: SectionDocument) -> Any:
        """Visit a section document.

        Section documents contain multiple member declarations.
        Each member is emitted as a separate variable assignment.
        Only shared members are emitted by default.
        """
        self.section_var_map = {
            member.name: member.value
            for member in node.members
            if member.value is not None
        }
        # Add a comment for the section
        self.statements.append(f"# Section: {node.name}")
        self.statements.append("")

        # Process each member
        for member in node.members:
            member.accept(self)

        return None

    def visit_section_member(self, node: SectionMember) -> Any:
        """Visit a section member.

        Section members are variable assignments with optional attributes.
        """
        if node.value:
            if isinstance(node.value, LetExpression) and not self.explicit_steps:
                filename = self._analyze_lakehouse_pattern(node.value)
                if filename:
                    file_read_code = self._emit_lakehouse_file_read(filename)
                    self.statements.append(f"{node.name} = {file_read_code}")
                    self._table_variables.add(node.name)
                    for statement in self._emit_post_csv_transformations(node.value, node.name):
                        self.statements.append(statement)
                    return None

            # Check if this member is a Lakehouse root
            if self._is_lakehouse_root(node.value):
                self.lakehouse_roots.add(node.name)

            # Check for lakehouse file pattern
            filename = self._detect_lakehouse_file_pattern(node.value)
            if filename:
                # Emit optimized file read
                file_read_code = self._emit_lakehouse_file_read(filename)
                self.statements.append(f"{node.name} = {file_read_code}")
                self._table_variables.add(node.name)
            else:
                # Standard emission
                value_code = node.value.accept(self)
                if value_code:
                    # Add comment for attributes if present
                    if node.attributes and node.attributes.fields:
                        attr_strs = [f"{k}={v.accept(self)}" for k, v in node.attributes.fields.items() if v]
                        if attr_strs:
                            self.statements.append(f"# Attributes: {', '.join(attr_strs)}")

                    if isinstance(value_code, AddColumnResult):
                        self.statements.append(f"{node.name} = {value_code.table_code}.copy()")
                        self.statements.append(f"{node.name}['{value_code.column_name}'] = {value_code.expression_code}")
                    else:
                        self.statements.append(f"{node.name} = {value_code}")

        return None

    def _analyze_lakehouse_pattern(self, let_expr: LetExpression) -> Optional[str]:
        """Analyze a let expression to detect Lakehouse -> Csv.Document pattern."""
        var_map: Dict[str, ASTNode] = {var.name: var.value for var in let_expr.variables}
        previous_let_var_map = self.let_var_map
        self.let_var_map = var_map
        try:
            for var in let_expr.variables:
                if isinstance(var.value, FunctionCall):
                    func_name = self._get_function_name(var.value.function)
                    if func_name == "Csv.Document" and var.value.arguments:
                        filename = self._detect_lakehouse_file_pattern(var.value.arguments[0])
                        if filename:
                            return filename
        finally:
            self.let_var_map = previous_let_var_map

        return None

    def _emit_post_csv_transformations(self, let_expr: LetExpression, query_name: str) -> List[str]:
        """Emit post-CSV transformations for lakehouse optimizations."""
        if self.explicit_steps:
            return []

        found_csv = False
        statements: List[str] = []

        for var in let_expr.variables:
            if isinstance(var.value, FunctionCall):
                func_name = self._get_function_name(var.value.function)

                if func_name == "Csv.Document":
                    found_csv = True
                    continue

                if found_csv and func_name == "Table.PromoteHeaders":
                    statements.append(
                        f"{query_name} = {query_name}.iloc[1:].set_axis({query_name}.iloc[0].tolist(), axis=1).reset_index(drop=True)"
                    )

        return statements

    def _sanitize_identifier(self, name: str) -> str:
        """Sanitize an identifier for Python use.

        Converts M identifiers (which may contain spaces/special chars) to
        valid Python identifiers.
        """
        if name.isidentifier():
            return name
        # Replace spaces and special chars with underscores
        import re
        sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', name)
        if not sanitized:
            return "unknown"
        if sanitized[0].isdigit():
            sanitized = '_' + sanitized
        return sanitized
