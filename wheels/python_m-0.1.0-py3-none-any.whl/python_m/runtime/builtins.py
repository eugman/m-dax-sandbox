"""Built-in M functions for the runtime interpreter.

This module implements the M standard library functions that the runtime
supports. Functions are organized by namespace (File.*, Csv.*, Table.*, etc.)
and registered in a central registry for lookup during evaluation.

Implementation Strategy:
1. Functions are implemented as Python callables
2. They accept MValue arguments and return MValue results
3. A registry maps M function names to implementations
4. The evaluator looks up functions during FunctionCall evaluation

Currently Implemented:
- File.Contents - Read file as binary
- Csv.Document - Parse CSV content into table

Planned:
- Table.SelectColumns, Table.RemoveColumns, Table.RenameColumns
- Table.TransformColumnTypes, Table.AddColumn, Table.Sort
- Table.SelectRows, Table.Group, Table.Join
- Text.*, Number.*, List.* functions

References:
    - Microsoft Docs: Power Query M function reference
    - https://learn.microsoft.com/en-us/powerquery-m/power-query-m-function-reference
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

import polars as pl

from datetime import date as pydate, timedelta

from python_m.runtime.values import (
    MValue, MNull, MText, MNumber, MLogical, MDate, MDuration, MList, MRecord, MTable, MBinary, MFunction
)

if TYPE_CHECKING:
    from python_m.runtime.environment import Environment, GlobalEnvironment


# Type alias for builtin function implementations
BuiltinFunc = Callable[..., MValue]


class BuiltinRegistry:
    """Registry for M built-in functions.

    Provides a central lookup for all standard library functions.
    Functions are registered by their full M name (e.g., "Csv.Document").

    Example:
        registry = BuiltinRegistry()
        registry.register("Text.Length", text_length_impl)
        fn = registry.get("Text.Length")
        result = fn(MText("hello"))  # Returns MNumber(5)
    """

    def __init__(self) -> None:
        """Create an empty registry."""
        self._functions: Dict[str, BuiltinFunc] = {}

    def register(self, name: str, func: BuiltinFunc) -> None:
        """Register a built-in function.

        Args:
            name: Full M function name (e.g., "Csv.Document")
            func: Implementation callable
        """
        self._functions[name] = func

    def get(self, name: str) -> Optional[BuiltinFunc]:
        """Look up a built-in function.

        Args:
            name: Full M function name

        Returns:
            The implementation, or None if not registered
        """
        return self._functions.get(name)

    def has(self, name: str) -> bool:
        """Check if a function is registered."""
        return name in self._functions

    def list_functions(self) -> List[str]:
        """Get all registered function names."""
        return sorted(self._functions.keys())

    def list_by_namespace(self, namespace: str) -> List[str]:
        """Get functions in a specific namespace.

        Args:
            namespace: Namespace prefix (e.g., "Table", "Text")

        Returns:
            List of function names in that namespace
        """
        prefix = f"{namespace}."
        return sorted(name for name in self._functions if name.startswith(prefix))


# Global registry instance
_registry = BuiltinRegistry()


def builtin(name: str) -> Callable[[BuiltinFunc], BuiltinFunc]:
    """Decorator to register a function as a built-in.

    Usage:
        @builtin("Text.Length")
        def text_length(text: MText) -> MNumber:
            return MNumber(len(text.value))
    """
    def decorator(func: BuiltinFunc) -> BuiltinFunc:
        _registry.register(name, func)
        return func
    return decorator


def get_builtin(name: str) -> Optional[BuiltinFunc]:
    """Get a built-in function by name."""
    return _registry.get(name)


def has_builtin(name: str) -> bool:
    """Check if a built-in function exists."""
    return _registry.has(name)


def list_builtins() -> List[str]:
    """List all registered built-in functions."""
    return _registry.list_functions()


def register_builtins(env: 'GlobalEnvironment') -> None:
    """Register all built-in functions in a global environment.

    Called during interpreter initialization to populate the
    global scope with standard library functions.

    Args:
        env: The global environment to populate
    """
    for name in _registry.list_functions():
        func = _registry.get(name)
        if func:
            env.bind_builtin(name, func)


# =============================================================================
# File Functions
# =============================================================================

@builtin("File.Contents")
def file_contents(path: MValue, options: Optional[MRecord] = None) -> MBinary:
    """Read file contents as binary.

    M Signature:
        File.Contents(path as text, optional options as record) as binary

    Args:
        path: File path (MText)
        options: Optional settings (timeout, etc.) - currently ignored

    Returns:
        MBinary containing file contents

    Raises:
        FileNotFoundError: If file doesn't exist
        TypeError: If path is not text
    """
    if not isinstance(path, MText):
        raise TypeError(f"File.Contents expects text path, got {path.type_name}")

    file_path = Path(path.value)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {path.value}")

    content = file_path.read_bytes()
    return MBinary(content)


# =============================================================================
# CSV Functions
# =============================================================================

@builtin("Csv.Document")
def csv_document(
    source: MValue,
    columns: Optional[MValue] = None,
    delimiter: Optional[MValue] = None,
    extra_values: Optional[MValue] = None,
    encoding: Optional[MValue] = None
) -> MTable:
    """Parse CSV content into a table.

    M Signature:
        Csv.Document(source as any, optional columns as any,
                     optional delimiter as any, optional extraValues as number,
                     optional encoding as any) as table

    Args:
        source: MBinary (file contents) or MText (path or content)
        columns: Column count or list of column specifications
        delimiter: Field delimiter (default comma)
        extra_values: How to handle extra values
        encoding: Text encoding (default UTF-8)

    Returns:
        MTable containing parsed CSV data
    """
    # Handle different source types
    if isinstance(source, MBinary):
        # Binary content from File.Contents
        content = source.value.decode('utf-8')
        df = pl.read_csv(content.encode(), infer_schema_length=10000)
    elif isinstance(source, MText):
        # Could be a path or inline CSV content
        if '\n' in source.value or ',' in source.value:
            # Looks like inline CSV content
            df = pl.read_csv(source.value.encode(), infer_schema_length=10000)
        else:
            # Treat as file path
            df = pl.read_csv(source.value, infer_schema_length=10000)
    else:
        raise TypeError(f"Csv.Document expects binary or text, got {source.type_name}")

    return MTable.from_polars(df)


# =============================================================================
# Table Functions
# =============================================================================

@builtin("Table.SelectColumns")
def table_select_columns(table: MValue, columns: MValue) -> MTable:
    """Select specific columns from a table.

    M Signature:
        Table.SelectColumns(table as table, columns as any) as table

    Args:
        table: Input table
        columns: Column name (text) or list of column names

    Returns:
        Table with only the specified columns
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.SelectColumns expects table, got {table.type_name}")

    if isinstance(columns, MText):
        col_list = [columns.value]
    elif isinstance(columns, MList):
        col_list = []
        for i, item in enumerate(columns.items):
            if not isinstance(item, MText):
                raise TypeError(
                    f"Table.SelectColumns: column name at index {i} must be text, got {item.type_name}"
                )
            col_list.append(item.value)
    else:
        raise TypeError(f"Table.SelectColumns expects text or list of columns, got {columns.type_name}")

    return table.select_columns(col_list)


@builtin("Table.RemoveColumns")
def table_remove_columns(table: MValue, columns: MValue) -> MTable:
    """Remove specific columns from a table.

    M Signature:
        Table.RemoveColumns(table as table, columns as any) as table

    Args:
        table: Input table
        columns: Column name (text) or list of column names to remove

    Returns:
        Table without the specified columns
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.RemoveColumns expects table, got {table.type_name}")

    if isinstance(columns, MText):
        col_list = [columns.value]
    elif isinstance(columns, MList):
        col_list = []
        for i, item in enumerate(columns.items):
            if not isinstance(item, MText):
                raise TypeError(
                    f"Table.RemoveColumns: column name at index {i} must be text, got {item.type_name}"
                )
            col_list.append(item.value)
    else:
        raise TypeError(f"Table.RemoveColumns expects text or list, got {columns.type_name}")

    return table.remove_columns(col_list)


@builtin("Table.RenameColumns")
def table_rename_columns(table: MValue, renames: MValue) -> MTable:
    """Rename columns in a table.

    M Signature:
        Table.RenameColumns(table as table, renames as list) as table

    Args:
        table: Input table
        renames: List of {old_name, new_name} pairs

    Returns:
        Table with renamed columns
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.RenameColumns expects table, got {table.type_name}")

    if not isinstance(renames, MList):
        raise TypeError(f"Table.RenameColumns expects list of renames, got {renames.type_name}")

    # renames is a list of lists: {{"old1", "new1"}, {"old2", "new2"}}
    mapping: Dict[str, str] = {}
    for item in renames.items:
        if isinstance(item, MList) and len(item.items) >= 2:
            old_name = item.items[0]
            new_name = item.items[1]
            if isinstance(old_name, MText) and isinstance(new_name, MText):
                mapping[old_name.value] = new_name.value

    return table.rename_columns(mapping)


@builtin("Table.AddColumn")
def table_add_column(
    table: MValue,
    new_column_name: MValue,
    column_generator: MValue,
    column_type: Optional[MValue] = None
) -> MTable:
    """Add a computed column to a table.

    M Signature:
        Table.AddColumn(table as table, newColumnName as text,
                       columnGenerator as function, optional columnType as type) as table

    Args:
        table: Input table
        new_column_name: Name for the new column
        column_generator: Function to compute column values
        column_type: Optional type for the new column

    Returns:
        Table with the new column added

    Warning:
        This is a STUB that returns the table unchanged. The full implementation
        is in Evaluator._eval_table_add_column() which has access to the
        evaluation context needed to execute the column_generator function.
        Do not call this builtin directly - use the evaluator instead.
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.AddColumn expects table, got {table.type_name}")
    if not isinstance(new_column_name, MText):
        raise TypeError(f"Table.AddColumn expects text column name, got {new_column_name.type_name}")

    # STUB: Returns table unchanged. See Evaluator._eval_table_add_column() for
    # the full implementation that executes the column_generator function.
    return table


@builtin("Table.Sort")
def table_sort(table: MValue, comparers: MValue) -> MTable:
    """Sort table rows.

    M Signature:
        Table.Sort(table as table, comparers as any) as table

    Args:
        table: Input table
        comparers: Column name, list of columns, or list of {column, order} pairs

    Returns:
        Sorted table
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.Sort expects table, got {table.type_name}")

    if isinstance(comparers, MText):
        # Single column name
        return table.sort([comparers.value])
    elif isinstance(comparers, MList):
        # List of columns or {column, order} pairs
        columns: List[str] = []
        descending: List[bool] = []

        for item in comparers.items:
            if isinstance(item, MText):
                columns.append(item.value)
                descending.append(False)
            elif isinstance(item, MList) and len(item.items) >= 1:
                col = item.items[0]
                if isinstance(col, MText):
                    columns.append(col.value)
                    # Check for Order.Descending
                    if len(item.items) >= 2:
                        order = item.items[1]
                        # Order.Descending = 1, Order.Ascending = 0
                        if isinstance(order, MNumber):
                            descending.append(order.value == 1)
                        else:
                            descending.append(False)
                    else:
                        descending.append(False)

        return table.sort(columns, descending=descending)

    raise TypeError(f"Table.Sort expects column name or list, got {comparers.type_name}")


@builtin("Table.SelectRows")
def table_select_rows(table: MValue, condition: MValue) -> MTable:
    """Filter table rows based on a condition.

    M Signature:
        Table.SelectRows(table as table, condition as function) as table

    Args:
        table: Input table
        condition: Function that returns true for rows to keep

    Returns:
        Filtered table

    Warning:
        This is a STUB that returns the table unchanged. The full implementation
        is in Evaluator._eval_table_select_rows() which has access to the
        evaluation context needed to execute the condition function.
        Do not call this builtin directly - use the evaluator instead.
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.SelectRows expects table, got {table.type_name}")

    # STUB: Returns table unchanged. See Evaluator._eval_table_select_rows() for
    # the full implementation that executes the condition function.
    return table


@builtin("Table.Skip")
def table_skip(table: MValue, count: MValue) -> MTable:
    """Skip first N rows.

    M Signature:
        Table.Skip(table as table, countOrCondition as any) as table
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.Skip expects table, got {table.type_name}")
    if not isinstance(count, MNumber):
        raise TypeError(f"Table.Skip expects number, got {count.type_name}")

    return table.skip(int(count.value))


@builtin("Table.FillDown")
def table_fill_down(table: MValue, columns: MValue) -> MTable:
    """Fill null values with previous non-null value.

    M Signature:
        Table.FillDown(table as table, columns as list) as table
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.FillDown expects table, got {table.type_name}")
    if not isinstance(columns, MList):
        raise TypeError(f"Table.FillDown expects list of columns, got {columns.type_name}")

    col_names = [item.value for item in columns.items if isinstance(item, MText)]
    return table.fill_down(col_names)


@builtin("Table.FirstN")
def table_first_n(table: MValue, count: MValue) -> MTable:
    """Get first N rows.

    M Signature:
        Table.FirstN(table as table, countOrCondition as any) as table
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.FirstN expects table, got {table.type_name}")
    if not isinstance(count, MNumber):
        raise TypeError(f"Table.FirstN expects number, got {count.type_name}")

    return table.head(int(count.value))


@builtin("Table.LastN")
def table_last_n(table: MValue, count: MValue) -> MTable:
    """Get last N rows.

    M Signature:
        Table.LastN(table as table, countOrCondition as any) as table
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.LastN expects table, got {table.type_name}")
    if not isinstance(count, MNumber):
        raise TypeError(f"Table.LastN expects number, got {count.type_name}")

    return table.tail(int(count.value))


@builtin("Table.Distinct")
def table_distinct(table: MValue, columns: Optional[MValue] = None) -> MTable:
    """Remove duplicate rows.

    M Signature:
        Table.Distinct(table as table, optional columns as any) as table
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.Distinct expects table, got {table.type_name}")

    # For now, simple distinct - columns parameter would select which columns to consider
    return table.distinct()


@builtin("Table.RowCount")
def table_row_count(table: MValue) -> MNumber:
    """Get number of rows in table.

    M Signature:
        Table.RowCount(table as table) as number
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.RowCount expects table, got {table.type_name}")

    return MNumber(len(table))


@builtin("Table.ColumnNames")
def table_column_names(table: MValue) -> MList:
    """Get list of column names.

    M Signature:
        Table.ColumnNames(table as table) as list
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.ColumnNames expects table, got {table.type_name}")

    return MList([MText(name) for name in table.column_names])


# =============================================================================
# Text Functions
# =============================================================================

@builtin("Text.Length")
def text_length(text: MValue) -> MNumber:
    """Get length of text string.

    M Signature:
        Text.Length(text as nullable text) as nullable number
    """
    if text.is_null():
        return MNull()
    if not isinstance(text, MText):
        raise TypeError(f"Text.Length expects text, got {text.type_name}")

    return MNumber(len(text.value))


@builtin("Text.Upper")
def text_upper(text: MValue) -> MValue:
    """Convert text to uppercase.

    M Signature:
        Text.Upper(text as nullable text) as nullable text
    """
    if text.is_null():
        return MNull()
    if not isinstance(text, MText):
        raise TypeError(f"Text.Upper expects text, got {text.type_name}")

    return MText(text.value.upper())


@builtin("Text.Lower")
def text_lower(text: MValue) -> MValue:
    """Convert text to lowercase.

    M Signature:
        Text.Lower(text as nullable text) as nullable text
    """
    if text.is_null():
        return MNull()
    if not isinstance(text, MText):
        raise TypeError(f"Text.Lower expects text, got {text.type_name}")

    return MText(text.value.lower())


@builtin("Text.Trim")
def text_trim(text: MValue) -> MValue:
    """Trim whitespace from both ends.

    M Signature:
        Text.Trim(text as nullable text) as nullable text
    """
    if text.is_null():
        return MNull()
    if not isinstance(text, MText):
        raise TypeError(f"Text.Trim expects text, got {text.type_name}")

    return MText(text.value.strip())


@builtin("Text.Contains")
def text_contains(text: MValue, substring: MValue) -> MValue:
    """Check if text contains substring.

    M Signature:
        Text.Contains(text as nullable text, substring as text) as nullable logical
    """
    if text.is_null():
        return MNull()
    if not isinstance(text, MText):
        raise TypeError(f"Text.Contains expects text, got {text.type_name}")
    if not isinstance(substring, MText):
        raise TypeError(f"Text.Contains expects text substring, got {substring.type_name}")

    return MLogical(substring.value in text.value)


@builtin("Text.Start")
def text_start(text: MValue, count: MValue) -> MValue:
    """Get first N characters.

    M Signature:
        Text.Start(text as nullable text, count as number) as nullable text
    """
    if text.is_null():
        return MNull()
    if not isinstance(text, MText):
        raise TypeError(f"Text.Start expects text, got {text.type_name}")
    if not isinstance(count, MNumber):
        raise TypeError(f"Text.Start expects number, got {count.type_name}")

    return MText(text.value[:int(count.value)])


@builtin("Text.End")
def text_end(text: MValue, count: MValue) -> MValue:
    """Get last N characters.

    M Signature:
        Text.End(text as nullable text, count as number) as nullable text
    """
    if text.is_null():
        return MNull()
    if not isinstance(text, MText):
        raise TypeError(f"Text.End expects text, got {text.type_name}")
    if not isinstance(count, MNumber):
        raise TypeError(f"Text.End expects number, got {count.type_name}")

    n = int(count.value)
    return MText(text.value[-n:] if n > 0 else "")


# =============================================================================
# Number Functions
# =============================================================================

@builtin("Number.Round")
def number_round(number: MValue, digits: Optional[MValue] = None) -> MValue:
    """Round a number.

    M Signature:
        Number.Round(number as nullable number, optional digits as number) as nullable number
    """
    if number.is_null():
        return MNull()
    if not isinstance(number, MNumber):
        raise TypeError(f"Number.Round expects number, got {number.type_name}")

    d = 0 if digits is None or digits.is_null() else int(digits.value)
    return MNumber(round(number.value, d))


@builtin("Number.Abs")
def number_abs(number: MValue) -> MValue:
    """Get absolute value.

    M Signature:
        Number.Abs(number as nullable number) as nullable number
    """
    if number.is_null():
        return MNull()
    if not isinstance(number, MNumber):
        raise TypeError(f"Number.Abs expects number, got {number.type_name}")

    return MNumber(abs(number.value))


@builtin("Number.Sign")
def number_sign(number: MValue) -> MValue:
    """Get sign of number (-1, 0, or 1).

    M Signature:
        Number.Sign(number as nullable number) as nullable number
    """
    if number.is_null():
        return MNull()
    if not isinstance(number, MNumber):
        raise TypeError(f"Number.Sign expects number, got {number.type_name}")

    v = number.value
    if v > 0:
        return MNumber(1)
    elif v < 0:
        return MNumber(-1)
    else:
        return MNumber(0)


# =============================================================================
# List Functions
# =============================================================================

@builtin("List.Count")
def list_count(lst: MValue) -> MNumber:
    """Get number of items in list.

    M Signature:
        List.Count(list as list) as number
    """
    if not isinstance(lst, MList):
        raise TypeError(f"List.Count expects list, got {lst.type_name}")

    return MNumber(len(lst))


@builtin("List.First")
def list_first(lst: MValue, default: Optional[MValue] = None) -> MValue:
    """Get first item in list.

    M Signature:
        List.First(list as list, optional defaultValue as any) as any
    """
    if not isinstance(lst, MList):
        raise TypeError(f"List.First expects list, got {lst.type_name}")

    if len(lst) == 0:
        return default if default is not None else MNull()
    return lst[0]


@builtin("List.Last")
def list_last(lst: MValue, default: Optional[MValue] = None) -> MValue:
    """Get last item in list.

    M Signature:
        List.Last(list as list, optional defaultValue as any) as any
    """
    if not isinstance(lst, MList):
        raise TypeError(f"List.Last expects list, got {lst.type_name}")

    if len(lst) == 0:
        return default if default is not None else MNull()
    return lst[-1]


@builtin("List.Sum")
def list_sum(lst: MValue) -> MValue:
    """Sum numeric items in list.

    M Signature:
        List.Sum(list as list) as nullable number
    """
    if not isinstance(lst, MList):
        raise TypeError(f"List.Sum expects list, got {lst.type_name}")

    total = 0
    for item in lst.items:
        if isinstance(item, MNumber):
            total += item.value
        elif item.is_null():
            continue  # Skip nulls
        else:
            raise TypeError(f"List.Sum expects numeric list, got {item.type_name}")

    return MNumber(total)


@builtin("List.Average")
def list_average(lst: MValue) -> MValue:
    """Average numeric items in list.

    M Signature:
        List.Average(list as list) as nullable number
    """
    if not isinstance(lst, MList):
        raise TypeError(f"List.Average expects list, got {lst.type_name}")

    total = 0
    count = 0
    for item in lst.items:
        if isinstance(item, MNumber):
            total += item.value
            count += 1
        elif item.is_null():
            continue
        else:
            raise TypeError(f"List.Average expects numeric list, got {item.type_name}")

    if count == 0:
        return MNull()
    return MNumber(total / count)


@builtin("List.Max")
def list_max(lst: MValue) -> MValue:
    """Get maximum value in list.

    M Signature:
        List.Max(list as list, optional defaultValue as any) as any
    """
    if not isinstance(lst, MList):
        raise TypeError(f"List.Max expects list, got {lst.type_name}")

    max_val = None
    for item in lst.items:
        if isinstance(item, MNumber):
            if max_val is None or item.value > max_val:
                max_val = item.value
        elif item.is_null():
            continue

    return MNumber(max_val) if max_val is not None else MNull()


@builtin("List.Min")
def list_min(lst: MValue) -> MValue:
    """Get minimum value in list.

    M Signature:
        List.Min(list as list, optional defaultValue as any) as any
    """
    if not isinstance(lst, MList):
        raise TypeError(f"List.Min expects list, got {lst.type_name}")

    min_val = None
    for item in lst.items:
        if isinstance(item, MNumber):
            if min_val is None or item.value < min_val:
                min_val = item.value
        elif item.is_null():
            continue

    return MNumber(min_val) if min_val is not None else MNull()


@builtin("List.Distinct")
def list_distinct(lst: MValue) -> MList:
    """Get unique values from list, preserving order.

    M Signature:
        List.Distinct(list as list, optional equationCriteria as any) as list
    """
    if not isinstance(lst, MList):
        raise TypeError(f"List.Distinct expects list, got {lst.type_name}")

    seen: List[Any] = []
    result: List[MValue] = []
    for item in lst.items:
        # Use Python value for comparison
        py_val = item.to_python()
        if py_val not in seen:
            seen.append(py_val)
            result.append(item)

    return MList(result)


@builtin("Table.PromoteHeaders")
def table_promote_headers(table: MValue, options: Optional[MValue] = None) -> MTable:
    """Use the first row as column headers.

    M Signature:
        Table.PromoteHeaders(table as table, optional options as record) as table
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.PromoteHeaders expects table, got {table.type_name}")

    return table.promote_headers()


# =============================================================================
# Date Functions
# =============================================================================


@builtin("#date")
def date_constructor(year: MValue, month: MValue, day: MValue) -> MDate:
    """Construct a date from year, month, day.

    M Signature:
        #date(year as number, month as number, day as number) as date
    """
    if not isinstance(year, MNumber):
        raise TypeError(f"#date expects number for year, got {year.type_name}")
    if not isinstance(month, MNumber):
        raise TypeError(f"#date expects number for month, got {month.type_name}")
    if not isinstance(day, MNumber):
        raise TypeError(f"#date expects number for day, got {day.type_name}")

    return MDate(pydate(int(year.value), int(month.value), int(day.value)))


@builtin("#duration")
def duration_constructor(days: MValue, hours: MValue, minutes: MValue, seconds: MValue) -> MDuration:
    """Construct a duration from days, hours, minutes, seconds.

    M Signature:
        #duration(days as number, hours as number, minutes as number, seconds as number) as duration
    """
    if not isinstance(days, MNumber):
        raise TypeError(f"#duration expects number for days, got {days.type_name}")
    if not isinstance(hours, MNumber):
        raise TypeError(f"#duration expects number for hours, got {hours.type_name}")
    if not isinstance(minutes, MNumber):
        raise TypeError(f"#duration expects number for minutes, got {minutes.type_name}")
    if not isinstance(seconds, MNumber):
        raise TypeError(f"#duration expects number for seconds, got {seconds.type_name}")

    return MDuration(timedelta(
        days=int(days.value),
        hours=int(hours.value),
        minutes=int(minutes.value),
        seconds=float(seconds.value)
    ))


@builtin("Date.Month")
def date_month(d: MValue) -> MValue:
    """Get the month component from a date.

    M Signature:
        Date.Month(dateTime as any) as nullable number

    Returns MNull if input is null (null propagation).
    """
    if isinstance(d, MNull):
        return MNull()
    if not isinstance(d, MDate):
        raise TypeError(f"Date.Month expects date, got {d.type_name}")

    return MNumber(d.value.month)


@builtin("Date.Day")
def date_day(d: MValue) -> MValue:
    """Get the day component from a date.

    M Signature:
        Date.Day(dateTime as any) as nullable number

    Returns MNull if input is null (null propagation).
    """
    if isinstance(d, MNull):
        return MNull()
    if not isinstance(d, MDate):
        raise TypeError(f"Date.Day expects date, got {d.type_name}")

    return MNumber(d.value.day)


@builtin("Date.Year")
def date_year(d: MValue) -> MValue:
    """Get the year component from a date.

    M Signature:
        Date.Year(dateTime as any) as nullable number

    Returns MNull if input is null (null propagation).
    """
    if isinstance(d, MNull):
        return MNull()
    if not isinstance(d, MDate):
        raise TypeError(f"Date.Year expects date, got {d.type_name}")

    return MNumber(d.value.year)


# =============================================================================
# Table Transform Functions
# =============================================================================


@builtin("Table.TransformColumnTypes")
def table_transform_column_types(
    table: MValue, type_transformations: MValue, culture: Optional[MValue] = None
) -> MTable:
    """Transform the types of columns in a table.

    M Signature:
        Table.TransformColumnTypes(table as table, typeTransformations as list,
                                   optional culture as text) as table

    Note: This is a stub that returns the table unchanged.
    Full implementation would need type system support.
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.TransformColumnTypes expects table, got {table.type_name}")

    # For now, return table unchanged (types will be handled by pandas read_csv inference)
    return table


@builtin("Table.UnpivotOtherColumns")
def table_unpivot_other_columns(
    table: MValue, pivot_columns: MValue, attribute_column: MValue, value_column: MValue
) -> MTable:
    """Unpivot columns that are not in the pivot columns list.

    M Signature:
        Table.UnpivotOtherColumns(table as table, pivotColumns as list,
                                  attributeColumn as text, valueColumn as text) as table
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.UnpivotOtherColumns expects table, got {table.type_name}")
    if not isinstance(pivot_columns, MList):
        raise TypeError(f"Table.UnpivotOtherColumns expects list for pivotColumns")
    if not isinstance(attribute_column, MText):
        raise TypeError(f"Table.UnpivotOtherColumns expects text for attributeColumn")
    if not isinstance(value_column, MText):
        raise TypeError(f"Table.UnpivotOtherColumns expects text for valueColumn")

    # Get the column names to keep
    id_cols = [item.value for item in pivot_columns.items if isinstance(item, MText)]
    attr_name = attribute_column.value
    val_name = value_column.value

    # Use polars melt
    df = table._lazy_frame.collect()
    value_cols = [c for c in df.columns if c not in id_cols]

    melted = df.unpivot(
        index=id_cols,
        on=value_cols,
        variable_name=attr_name,
        value_name=val_name
    )

    return MTable(melted.lazy(), _column_names=list(melted.columns))


@builtin("Table.Pivot")
def table_pivot(
    table: MValue, pivot_column: MValue, value_column: MValue, aggregation_function: MValue
) -> MTable:
    """Pivot a table, turning column values into column headers.

    M Signature:
        Table.Pivot(table as table, pivotColumn as text, valueColumn as text,
                    aggregationFunction as function) as table

    Args:
        table: Input table
        pivot_column: Column whose values become new column headers
        value_column: Column whose values fill the pivot cells
        aggregation_function: Function to aggregate values (e.g., List.Sum)

    Returns:
        Pivoted table
    """
    if not isinstance(table, MTable):
        raise TypeError(f"Table.Pivot expects table, got {table.type_name}")
    if not isinstance(pivot_column, MText):
        raise TypeError(f"Table.Pivot expects text for pivotColumn")
    if not isinstance(value_column, MText):
        raise TypeError(f"Table.Pivot expects text for valueColumn")

    pivot_col = pivot_column.value
    value_col = value_column.value

    # Get aggregation function name
    agg_func_name = "sum"  # Default
    if isinstance(aggregation_function, MFunction):
        func_name = aggregation_function.name
        if func_name == "List.Sum":
            agg_func_name = "sum"
        elif func_name == "List.Average":
            agg_func_name = "mean"
        elif func_name == "List.Max":
            agg_func_name = "max"
        elif func_name == "List.Min":
            agg_func_name = "min"
        elif func_name == "List.Count":
            agg_func_name = "count"

    # Use polars pivot
    df = table._lazy_frame.collect()

    # Find index columns (all columns except pivot and value)
    index_cols = [c for c in df.columns if c not in [pivot_col, value_col]]

    pivoted = df.pivot(
        on=pivot_col,
        index=index_cols,
        values=value_col,
        aggregate_function=agg_func_name
    )

    return MTable(pivoted.lazy(), _column_names=list(pivoted.columns))


@builtin("#table")
def table_constructor(columns: MValue, rows: MValue) -> MTable:
    """Construct a table from column names and row data.

    M Signature:
        #table(columns as list, rows as list) as table
        #table(type table [...], rows as list) as table

    Args:
        columns: List of column names (text) or a table type
        rows: List of lists, where each inner list is a row

    Returns:
        A new table with the specified structure and data

    Example:
        #table({"Name", "Age"}, {{"Alice", 30}, {"Bob", 25}})
    """
    from python_m.runtime.values import MType

    # Handle column names - either a list or a table type
    if isinstance(columns, MType):
        # Extract column names from table type
        if columns.value != "table":
            raise TypeError(f"#table expects table type, got type {columns.value}")
        # For typed tables, we need the column definitions from the type
        # This is a simplified version - full support would need type parsing
        raise NotImplementedError("#table with type table not yet fully supported")
    elif isinstance(columns, MList):
        column_names = []
        for col in columns.items:
            if not isinstance(col, MText):
                raise TypeError(f"#table column names must be text, got {col.type_name}")
            column_names.append(col.value)
    else:
        raise TypeError(f"#table expects list of column names, got {columns.type_name}")

    if not isinstance(rows, MList):
        raise TypeError(f"#table expects list of rows, got {rows.type_name}")

    # Build data rows
    data_rows = []
    for row in rows.items:
        if not isinstance(row, MList):
            raise TypeError(f"#table rows must be lists, got {row.type_name}")
        if len(row.items) != len(column_names):
            raise ValueError(
                f"#table row has {len(row.items)} values but expected {len(column_names)} columns"
            )
        row_dict = {}
        for col_name, value in zip(column_names, row.items):
            row_dict[col_name] = value.to_python()
        data_rows.append(row_dict)

    # Create table
    if data_rows:
        df = pl.DataFrame(data_rows)
    else:
        # Empty table with column names
        df = pl.DataFrame({col: [] for col in column_names})

    return MTable(df.lazy(), _column_names=column_names)
