"""M Language value types for the runtime interpreter.

Power Query M has a rich type system with several primitive and complex types.
This module implements Python representations for each M type.

M Types Implemented:
- null: MNull - The null/missing value
- logical: MLogical - Boolean (true/false)
- number: MNumber - Numeric values (int or float)
- text: MText - Unicode strings
- list: MList - Ordered sequences
- record: MRecord - Key-value mappings
- table: MTable - Tabular data (backed by Polars LazyFrame)
- function: MFunction - Callable functions
- binary: MBinary - Binary data
- type: MType - Type values
- date/time/datetime/duration: Future extensions

Design Principles:
1. Immutability - M values are immutable; operations return new values
2. Lazy Tables - MTable wraps Polars LazyFrame for deferred execution
3. Interop - Easy conversion to/from Python native types
4. Null Propagation - Operations handle null gracefully

References:
    - M Language Spec: Types
    - Polars Documentation: https://docs.pola.rs/
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any, Callable, Dict, Iterator, List, Optional, Sequence, Union, TYPE_CHECKING

import polars as pl

if TYPE_CHECKING:
    from python_m.runtime.environment import Environment


class MValue(ABC):
    """Base class for all M language values.

    All M values share common operations:
    - Type checking via type_name property
    - Conversion to Python via to_python()
    - String representation via __repr__
    - Equality comparison

    Subclasses implement specific M type semantics.
    """

    @property
    @abstractmethod
    def type_name(self) -> str:
        """Return the M type name (e.g., 'text', 'number', 'table')."""
        ...

    @abstractmethod
    def to_python(self) -> Any:
        """Convert to the most natural Python equivalent."""
        ...

    def is_null(self) -> bool:
        """Check if this value is null."""
        return False

    def equals(self, other: MValue) -> MValue:
        """M equality comparison with null propagation.

        Returns MNull if either operand is null, otherwise MLogical.
        """
        if self.is_null() or other.is_null():
            return MNull()  # null = anything is null
        return MLogical(self._equals_impl(other))

    def _equals_impl(self, other: MValue) -> bool:
        """Override in subclasses for type-specific equality."""
        return self.to_python() == other.to_python()


@dataclass(frozen=True)
class MNull(MValue):
    """M null value - represents missing or unknown data.

    In M, null propagates through most operations:
    - null + 1 = null
    - null = null is null (not true!)
    - null ?? default returns default

    Example:
        >>> MNull().to_python()
        None
        >>> MNull().is_null()
        True
    """

    @property
    def type_name(self) -> str:
        return "null"

    def to_python(self) -> None:
        return None

    def is_null(self) -> bool:
        return True

    def __repr__(self) -> str:
        return "null"


@dataclass(frozen=True)
class MLogical(MValue):
    """M logical (boolean) value - true or false.

    M logical operations:
    - and, or, not (short-circuit evaluation)
    - Null propagation: null and true = null

    Example:
        >>> MLogical(True).to_python()
        True
    """
    value: bool

    @property
    def type_name(self) -> str:
        return "logical"

    def to_python(self) -> bool:
        return self.value

    def __bool__(self) -> bool:
        return self.value

    def __repr__(self) -> str:
        return "true" if self.value else "false"

    def logical_and(self, other: MValue) -> MValue:
        """M 'and' with short-circuit and null propagation."""
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MLogical):
            raise TypeError(f"Cannot 'and' logical with {other.type_name}")
        return MLogical(self.value and other.value)

    def logical_or(self, other: MValue) -> MValue:
        """M 'or' with short-circuit and null propagation."""
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MLogical):
            raise TypeError(f"Cannot 'or' logical with {other.type_name}")
        return MLogical(self.value or other.value)

    def logical_not(self) -> MValue:
        """M 'not' operator."""
        return MLogical(not self.value)


@dataclass(frozen=True)
class MDate(MValue):
    """M date value - a date (year, month, day).

    Constructed using #date(year, month, day) in M.

    Example:
        >>> MDate(date(2024, 1, 15)).to_python()
        datetime.date(2024, 1, 15)
    """
    value: date

    @property
    def type_name(self) -> str:
        return "date"

    def to_python(self) -> date:
        return self.value

    def __repr__(self) -> str:
        return f"#date({self.value.year}, {self.value.month}, {self.value.day})"


@dataclass(frozen=True)
class MDuration(MValue):
    """M duration value - a time span.

    Constructed using #duration(days, hours, minutes, seconds) in M.
    Stored internally as a Python timedelta.

    Example:
        >>> MDuration(timedelta(days=1, hours=2, minutes=30)).to_python()
        datetime.timedelta(days=1, seconds=9000)
    """
    value: timedelta

    @property
    def type_name(self) -> str:
        return "duration"

    def to_python(self) -> timedelta:
        return self.value

    def __repr__(self) -> str:
        # Extract components for M representation
        total_seconds = self.value.total_seconds()
        days = self.value.days
        remaining = total_seconds - (days * 86400)
        hours = int(remaining // 3600)
        remaining -= hours * 3600
        minutes = int(remaining // 60)
        seconds = remaining - (minutes * 60)
        return f"#duration({days}, {hours}, {minutes}, {seconds})"


@dataclass(frozen=True)
class MNumber(MValue):
    """M number value - integers or floating-point.

    M uses arbitrary precision for exact integers and IEEE 754
    for floating-point. This implementation uses Python's int/float.

    Example:
        >>> MNumber(42).to_python()
        42
        >>> MNumber(3.14).to_python()
        3.14
    """
    value: Union[int, float]

    @property
    def type_name(self) -> str:
        return "number"

    def to_python(self) -> Union[int, float]:
        return self.value

    def __repr__(self) -> str:
        return str(self.value)

    def __add__(self, other: MValue) -> MValue:
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MNumber):
            raise TypeError(f"Cannot add number and {other.type_name}")
        return MNumber(self.value + other.value)

    def __sub__(self, other: MValue) -> MValue:
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MNumber):
            raise TypeError(f"Cannot subtract {other.type_name} from number")
        return MNumber(self.value - other.value)

    def __mul__(self, other: MValue) -> MValue:
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MNumber):
            raise TypeError(f"Cannot multiply number and {other.type_name}")
        return MNumber(self.value * other.value)

    def __truediv__(self, other: MValue) -> MValue:
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MNumber):
            raise TypeError(f"Cannot divide number by {other.type_name}")
        if other.value == 0:
            raise ZeroDivisionError("Division by zero")
        return MNumber(self.value / other.value)

    def __neg__(self) -> MNumber:
        return MNumber(-self.value)

    def __lt__(self, other: MValue) -> MValue:
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MNumber):
            raise TypeError(f"Cannot compare number with {other.type_name}")
        return MLogical(self.value < other.value)

    def __le__(self, other: MValue) -> MValue:
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MNumber):
            raise TypeError(f"Cannot compare number with {other.type_name}")
        return MLogical(self.value <= other.value)

    def __gt__(self, other: MValue) -> MValue:
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MNumber):
            raise TypeError(f"Cannot compare number with {other.type_name}")
        return MLogical(self.value > other.value)

    def __ge__(self, other: MValue) -> MValue:
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MNumber):
            raise TypeError(f"Cannot compare number with {other.type_name}")
        return MLogical(self.value >= other.value)


@dataclass(frozen=True)
class MText(MValue):
    """M text value - Unicode string.

    M text is immutable and supports:
    - Concatenation with &
    - Comparison (case-sensitive by default)
    - Various Text.* functions

    Example:
        >>> MText("hello").to_python()
        'hello'
    """
    value: str

    @property
    def type_name(self) -> str:
        return "text"

    def to_python(self) -> str:
        return self.value

    def __repr__(self) -> str:
        return f'"{self.value}"'

    def concatenate(self, other: MValue) -> MValue:
        """M text concatenation (&)."""
        if self.is_null() or other.is_null():
            return MNull()
        if not isinstance(other, MText):
            raise TypeError(f"Cannot concatenate text with {other.type_name}")
        return MText(self.value + other.value)

    def __len__(self) -> int:
        return len(self.value)


@dataclass
class MList(MValue):
    """M list value - ordered sequence of values.

    M lists:
    - Are 0-indexed (unlike 1-indexed in M surface syntax, we use 0 internally)
    - Can contain mixed types
    - Are immutable (operations return new lists)
    - Support list comprehensions: {x * 2 | x in source}

    Note:
        While this dataclass is not frozen for technical reasons (mutable
        default field), MList instances should be treated as immutable.
        Do not modify the `items` list after construction.

    Example:
        >>> lst = MList([MNumber(1), MNumber(2), MNumber(3)])
        >>> lst.to_python()
        [1, 2, 3]
    """
    items: List[MValue] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Defensively copy the items list to ensure immutability."""
        # Copy the list to prevent external mutation of the original
        object.__setattr__(self, 'items', list(self.items))

    @property
    def type_name(self) -> str:
        return "list"

    def to_python(self) -> List[Any]:
        return [item.to_python() for item in self.items]

    def __repr__(self) -> str:
        items_str = ", ".join(repr(item) for item in self.items)
        return f"{{{items_str}}}"

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self) -> Iterator[MValue]:
        return iter(self.items)

    def __getitem__(self, index: int) -> MValue:
        """Access item by index (0-based internally)."""
        if index < 0 or index >= len(self.items):
            return MNull()  # M returns null for out-of-bounds
        return self.items[index]

    def get(self, index: int) -> MValue:
        """M's {index} accessor with null for out-of-bounds."""
        return self[index]


@dataclass
class MRecord(MValue):
    """M record value - key-value mapping.

    M records:
    - Have ordered fields (insertion order preserved)
    - Field names are text
    - Values can be any M type
    - Are immutable (operations return new records)
    - Support field access: record[fieldName]

    Note:
        While this dataclass is not frozen for technical reasons (mutable
        default field), MRecord instances should be treated as immutable.
        Do not modify the `fields` dict after construction. Use `with_field()`
        and `without_field()` methods to create modified copies.

    Example:
        >>> rec = MRecord({"name": MText("Alice"), "age": MNumber(30)})
        >>> rec.to_python()
        {'name': 'Alice', 'age': 30}
    """
    fields: Dict[str, MValue] = field(default_factory=dict)

    @property
    def type_name(self) -> str:
        return "record"

    def to_python(self) -> Dict[str, Any]:
        return {k: v.to_python() for k, v in self.fields.items()}

    def __repr__(self) -> str:
        fields_str = ", ".join(f"{k} = {v!r}" for k, v in self.fields.items())
        return f"[{fields_str}]"

    def __getitem__(self, field_name: str) -> MValue:
        """Access field by name."""
        return self.fields.get(field_name, MNull())

    def get(self, field_name: str, default: Optional[MValue] = None) -> MValue:
        """Get field with optional default."""
        result = self.fields.get(field_name)
        if result is None:
            return default if default is not None else MNull()
        return result

    def has_field(self, field_name: str) -> bool:
        """Check if record has a field."""
        return field_name in self.fields

    def field_names(self) -> List[str]:
        """Get list of field names in order."""
        return list(self.fields.keys())

    def with_field(self, name: str, value: MValue) -> MRecord:
        """Return new record with added/updated field."""
        new_fields = dict(self.fields)
        new_fields[name] = value
        return MRecord(new_fields)

    def without_field(self, name: str) -> MRecord:
        """Return new record with field removed."""
        new_fields = {k: v for k, v in self.fields.items() if k != name}
        return MRecord(new_fields)


@dataclass
class MTable(MValue):
    """M table value - tabular data backed by Polars LazyFrame.

    M tables are the primary data structure for data transformation.
    This implementation uses Polars LazyFrame to provide:
    - Native lazy evaluation (aligns with M's partially lazy semantics)
    - Automatic query optimization (predicate pushdown, projection pushdown)
    - Efficient columnar storage
    - Pre-installed in Microsoft Fabric

    Key Features:
    - Operations are lazy by default (added to query plan)
    - collect() materializes the query
    - Automatic schema tracking
    - Integration with M's Table.* functions

    Example:
        >>> df = pl.LazyFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
        >>> table = MTable(df)
        >>> table.column_names
        ['A', 'B']
    """
    _lazy_frame: pl.LazyFrame
    _column_names: Optional[List[str]] = field(default=None, repr=False)

    @property
    def type_name(self) -> str:
        return "table"

    @property
    def lazy_frame(self) -> pl.LazyFrame:
        """Access the underlying Polars LazyFrame."""
        return self._lazy_frame

    @property
    def column_names(self) -> List[str]:
        """Get column names without materializing.

        Returns a copy to preserve immutability.
        """
        if self._column_names is None:
            self._column_names = self._lazy_frame.collect_schema().names()
        return list(self._column_names)  # Return copy to preserve immutability

    @property
    def schema(self) -> Dict[str, pl.DataType]:
        """Get column schema without materializing."""
        schema = self._lazy_frame.collect_schema()
        return dict(zip(schema.names(), schema.dtypes()))

    def to_python(self) -> pl.DataFrame:
        """Materialize and return as Polars DataFrame."""
        return self._lazy_frame.collect()

    def to_pandas(self):
        """Materialize and return as pandas DataFrame."""
        return self._lazy_frame.collect().to_pandas()

    def collect(self) -> pl.DataFrame:
        """Explicitly materialize the lazy query."""
        return self._lazy_frame.collect()

    def __repr__(self) -> str:
        cols = self.column_names
        return f"Table({len(cols)} columns: {cols})"

    def __len__(self) -> int:
        """Get row count (materializes the query!)."""
        return self._lazy_frame.collect().height

    # Table operations (return new MTable with lazy operations)

    def select_columns(self, columns: List[str]) -> MTable:
        """Select specific columns (lazy)."""
        new_lf = self._lazy_frame.select(columns)
        return MTable(new_lf, _column_names=columns)

    def remove_columns(self, columns: List[str]) -> MTable:
        """Remove specific columns (lazy)."""
        remaining = [c for c in self.column_names if c not in columns]
        new_lf = self._lazy_frame.select(remaining)
        return MTable(new_lf, _column_names=remaining)

    def rename_columns(self, mapping: Dict[str, str]) -> MTable:
        """Rename columns (lazy)."""
        new_lf = self._lazy_frame.rename(mapping)
        new_names = [mapping.get(c, c) for c in self.column_names]
        return MTable(new_lf, _column_names=new_names)

    def add_column(self, name: str, expr: pl.Expr) -> MTable:
        """Add a computed column (lazy)."""
        new_lf = self._lazy_frame.with_columns(expr.alias(name))
        return MTable(new_lf, _column_names=self.column_names + [name])

    def filter_rows(self, predicate: pl.Expr) -> MTable:
        """Filter rows by predicate (lazy)."""
        new_lf = self._lazy_frame.filter(predicate)
        return MTable(new_lf, _column_names=self._column_names)

    def sort(self, columns: List[str], descending: Union[bool, List[bool]] = False) -> MTable:
        """Sort by columns (lazy)."""
        new_lf = self._lazy_frame.sort(columns, descending=descending)
        return MTable(new_lf, _column_names=self._column_names)

    def head(self, n: int) -> MTable:
        """Take first n rows (lazy)."""
        new_lf = self._lazy_frame.head(n)
        return MTable(new_lf, _column_names=self._column_names)

    def tail(self, n: int) -> MTable:
        """Take last n rows (lazy)."""
        new_lf = self._lazy_frame.tail(n)
        return MTable(new_lf, _column_names=self._column_names)

    def distinct(self) -> MTable:
        """Remove duplicate rows (lazy)."""
        new_lf = self._lazy_frame.unique()
        return MTable(new_lf, _column_names=self._column_names)

    def skip(self, n: int) -> MTable:
        """Skip first n rows (lazy)."""
        new_lf = self._lazy_frame.slice(n, None)
        return MTable(new_lf, _column_names=self._column_names)

    def fill_down(self, columns: List[str]) -> MTable:
        """Fill null values with previous non-null value (lazy)."""
        exprs = [
            pl.col(c).forward_fill() if c in columns else pl.col(c)
            for c in self.column_names
        ]
        new_lf = self._lazy_frame.select(exprs)
        return MTable(new_lf, _column_names=self._column_names)

    def promote_headers(self) -> MTable:
        """Use the first row as column headers (materializes the query)."""
        df = self._lazy_frame.collect()
        if len(df) == 0:
            return self
        # Get first row values as new column names
        first_row = df.row(0)
        new_names = [str(v) if v is not None else f"Column{i}" for i, v in enumerate(first_row)]
        # Get remaining rows
        remaining = df.slice(1, None)
        remaining.columns = new_names
        return MTable(remaining.lazy(), _column_names=new_names)

    def group_by(self, columns: List[str]) -> pl.LazyGroupBy:
        """Start a group by operation (returns Polars GroupBy for aggregation)."""
        return self._lazy_frame.group_by(columns)

    def join(
        self,
        other: MTable,
        on: Optional[Union[str, List[str]]] = None,
        left_on: Optional[Union[str, List[str]]] = None,
        right_on: Optional[Union[str, List[str]]] = None,
        how: str = "inner"
    ) -> MTable:
        """Join with another table (lazy)."""
        new_lf = self._lazy_frame.join(
            other._lazy_frame,
            on=on,
            left_on=left_on,
            right_on=right_on,
            how=how
        )
        return MTable(new_lf)

    # Row access

    def row(self, index: int) -> MRecord:
        """Get a single row as a record (materializes up to that row)."""
        df = self._lazy_frame.head(index + 1).collect()
        if index >= len(df):
            return MRecord({})  # Empty record for out of bounds
        row_data = df.row(index, named=True)
        return MRecord({k: python_to_mvalue(v) for k, v in row_data.items()})

    # Factory methods

    @staticmethod
    def from_polars(df: Union[pl.DataFrame, pl.LazyFrame]) -> MTable:
        """Create MTable from Polars DataFrame or LazyFrame."""
        if isinstance(df, pl.DataFrame):
            return MTable(df.lazy())
        return MTable(df)

    @staticmethod
    def from_pandas(df) -> MTable:
        """Create MTable from pandas DataFrame."""
        return MTable(pl.from_pandas(df).lazy())

    @staticmethod
    def from_records(records: List[MRecord]) -> MTable:
        """Create MTable from list of MRecord values."""
        if not records:
            return MTable(pl.LazyFrame())
        dicts = [rec.to_python() for rec in records]
        return MTable(pl.LazyFrame(dicts))

    @staticmethod
    def from_dicts(dicts: List[Dict[str, Any]]) -> MTable:
        """Create MTable from list of dictionaries."""
        return MTable(pl.LazyFrame(dicts))


@dataclass
class MFunction(MValue):
    """M function value - callable with optional closure.

    M functions capture their defining environment (closure) and
    support both positional and optional parameters.

    Components:
    - parameters: List of parameter names
    - body: The AST node to evaluate (or a Python callable)
    - closure: The environment where the function was defined

    Example:
        >>> # M: (x) => x + 1
        >>> fn = MFunction(["x"], lambda env: env.get("x") + MNumber(1))
    """
    parameters: List[str]
    body: Any  # AST node or Python callable
    closure: Optional[Environment] = field(default=None, repr=False)
    name: Optional[str] = None

    @property
    def type_name(self) -> str:
        return "function"

    def to_python(self) -> Callable:
        """Return a Python callable wrapper."""
        def wrapper(*args):
            # This is a simplified wrapper - full implementation
            # would properly set up the environment and evaluate
            if callable(self.body):
                return self.body(*args)
            raise NotImplementedError("AST body evaluation requires evaluator")
        return wrapper

    def __repr__(self) -> str:
        params = ", ".join(self.parameters)
        name = f" {self.name}" if self.name else ""
        return f"Function{name}({params}) => ..."

    @property
    def arity(self) -> int:
        """Number of parameters."""
        return len(self.parameters)


@dataclass(frozen=True)
class MBinary(MValue):
    """M binary value - raw bytes.

    Used for file contents, encoded data, etc.

    Example:
        >>> MBinary(b"hello").to_python()
        b'hello'
    """
    value: bytes

    @property
    def type_name(self) -> str:
        return "binary"

    def to_python(self) -> bytes:
        return self.value

    def __repr__(self) -> str:
        if len(self.value) <= 20:
            return f"Binary({self.value!r})"
        return f"Binary({len(self.value)} bytes)"

    def __len__(self) -> int:
        return len(self.value)


@dataclass(frozen=True)
class MType(MValue):
    """M type value - represents a type.

    M has first-class types that can be passed around and used
    for type checking and transformation.

    Example:
        >>> MType("number").to_python()
        'number'
    """
    value: str  # Type name like "number", "text", "table", etc.

    @property
    def type_name(self) -> str:
        return "type"

    def to_python(self) -> str:
        return self.value

    def __repr__(self) -> str:
        return f"type {self.value}"


# Type conversion utilities

def python_to_mvalue(value: Any) -> MValue:
    """Convert a Python value to an MValue.

    Args:
        value: Any Python value

    Returns:
        Corresponding MValue

    Example:
        >>> python_to_mvalue(42)
        42
        >>> python_to_mvalue("hello")
        "hello"
    """
    if value is None:
        return MNull()
    if isinstance(value, bool):
        return MLogical(value)
    if isinstance(value, (int, float)):
        return MNumber(value)
    # Handle numpy numeric types
    try:
        import numpy as np
        if isinstance(value, (np.integer, np.floating)):
            return MNumber(float(value))
    except ImportError:
        pass
    if isinstance(value, str):
        return MText(value)
    if isinstance(value, bytes):
        return MBinary(value)
    if isinstance(value, list):
        return MList([python_to_mvalue(item) for item in value])
    if isinstance(value, dict):
        return MRecord({k: python_to_mvalue(v) for k, v in value.items()})
    if isinstance(value, pl.DataFrame):
        return MTable.from_polars(value)
    if isinstance(value, pl.LazyFrame):
        return MTable.from_polars(value)
    if isinstance(value, MValue):
        return value  # Already an MValue

    # For pandas DataFrame
    try:
        import pandas as pd
        if isinstance(value, pd.DataFrame):
            return MTable.from_pandas(value)
    except ImportError:
        pass

    raise TypeError(f"Cannot convert {type(value).__name__} to MValue")


def mvalue_to_python(value: MValue) -> Any:
    """Convert an MValue to its Python equivalent.

    Args:
        value: Any MValue

    Returns:
        Corresponding Python value
    """
    return value.to_python()
