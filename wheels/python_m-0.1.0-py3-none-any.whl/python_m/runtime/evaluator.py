"""Tree-walking interpreter for M language.

This module implements a direct interpreter that walks the AST and executes
M code in real-time, complementing the transpiler which generates Python code.

The evaluator implements M's evaluation semantics:
1. Call-by-need (lazy evaluation with memoization) via thunks
2. Lexical scoping via environment chains
3. Forward reference support within let expressions
4. Null propagation in expressions

Architecture:
- Evaluator: AST visitor that produces MValue results
- Environment: Scope chain for variable bindings
- Thunk: Delayed computation with memoization
- Builtins: Standard library function implementations

Example:
    from python_m.runtime import evaluate

    result = evaluate('''
        let
            Source = Csv.Document(File.Contents("data.csv")),
            Filtered = Table.SelectRows(Source, each [Amount] > 100)
        in
            Filtered
    ''')

    df = result.to_pandas()

References:
    - SICP 4.1: The Metacircular Evaluator
    - SICP 4.2: Variations on a Scheme — Lazy Evaluation
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING

from python_m.ast.nodes import (
    ASTNode,
    ASTVisitor,
    LetExpression,
    VariableAssignment,
    FunctionCall,
    MemberAccess,
    Identifier,
    StringLiteral,
    ListLiteral,
    NumberLiteral,
    EachExpression,
    FieldAccess,
    BinaryExpression,
    UnaryExpression,
    TypeCheckExpression,
    IfExpression,
    NullLiteral,
    BooleanLiteral,
    TypeExpression,
    RecordLiteral,
    FunctionExpression,
    FunctionParameter,
    ItemAccess,
    InclusiveIdentifier,
    ErrorExpression,
    NotImplementedExpression,
    MetaExpression,
    TryExpression,
    SectionDocument,
    SectionMember,
)
from python_m.parser import parse
from python_m.runtime.thunk import Thunk
from python_m.runtime.environment import Environment, GlobalEnvironment
from python_m.runtime.values import (
    MValue,
    MNull,
    MText,
    MNumber,
    MLogical,
    MList,
    MRecord,
    MTable,
    MFunction,
    python_to_mvalue,
)
from python_m.runtime.builtins import get_builtin, has_builtin, register_builtins


class Evaluator(ASTVisitor):
    """Tree-walking interpreter for M language AST.

    The evaluator traverses the AST and executes M code, producing MValue
    results. It maintains an environment for variable bindings and supports
    lazy evaluation via thunks.

    Attributes:
        env: Current evaluation environment
        global_env: Global environment with built-in functions

    Example:
        evaluator = Evaluator()
        ast = parse("let x = 1 in x + 1")
        result = evaluator.evaluate(ast)  # Returns MNumber(2)
    """

    def __init__(self, env: Optional[Environment] = None) -> None:
        """Create a new evaluator.

        Args:
            env: Optional initial environment. If not provided, creates
                 a global environment with built-in functions.
        """
        if env is None:
            self.global_env = GlobalEnvironment()
            register_builtins(self.global_env)
            self.env = self.global_env
        else:
            self.env = env
            # Find the global env by walking up
            current = env
            while current.parent is not None:
                current = current.parent
            if isinstance(current, GlobalEnvironment):
                self.global_env = current
            else:
                self.global_env = GlobalEnvironment()
                register_builtins(self.global_env)

    def evaluate(self, node: ASTNode) -> MValue:
        """Evaluate an AST node, returning the result.

        This is the main entry point for evaluation.

        Args:
            node: The AST node to evaluate.

        Returns:
            The M value result of evaluation.
        """
        result = node.accept(self)
        # Ensure we return an MValue
        if isinstance(result, MValue):
            return result
        # Convert Python values to MValue
        return python_to_mvalue(result)

    def with_environment(self, env: Environment) -> Evaluator:
        """Create a new evaluator with a different environment.

        Used for evaluating subexpressions in new scopes.

        Args:
            env: The environment to use.

        Returns:
            New evaluator with the given environment.
        """
        new_eval = Evaluator.__new__(Evaluator)
        new_eval.env = env
        new_eval.global_env = self.global_env
        return new_eval

    def _values_equal(self, left: MValue, right: MValue) -> bool:
        """Check if two M values are equal.

        Handles deep equality for records and lists.

        Args:
            left: First value to compare.
            right: Second value to compare.

        Returns:
            True if values are equal, False otherwise.
        """
        # Handle null
        if isinstance(left, MNull) and isinstance(right, MNull):
            return True
        if isinstance(left, MNull) or isinstance(right, MNull):
            return False

        # Primitive types
        if isinstance(left, MNumber) and isinstance(right, MNumber):
            return left.value == right.value
        if isinstance(left, MText) and isinstance(right, MText):
            return left.value == right.value
        if isinstance(left, MLogical) and isinstance(right, MLogical):
            return left.value == right.value

        # Records: same field names with equal values
        if isinstance(left, MRecord) and isinstance(right, MRecord):
            if set(left.fields.keys()) != set(right.fields.keys()):
                return False
            for name in left.fields:
                if not self._values_equal(left.fields[name], right.fields[name]):
                    return False
            return True

        # Lists: same length with equal elements
        if isinstance(left, MList) and isinstance(right, MList):
            if len(left.items) != len(right.items):
                return False
            for i, item in enumerate(left.items):
                if not self._values_equal(item, right.items[i]):
                    return False
            return True

        # Different types
        return False

    # =========================================================================
    # AST Visitor Methods
    # =========================================================================

    def visit_let_expression(self, node: LetExpression) -> MValue:
        """Evaluate a let expression.

        let
            var1 = expr1,
            var2 = expr2,
            ...
        in
            result_expr

        Creates a new scope and binds all variables as thunks (for lazy
        evaluation and forward reference support), then evaluates the
        result expression in that scope.

        Args:
            node: The LetExpression AST node.

        Returns:
            The value of the result expression.
        """
        # Create a new scope for the let bindings
        let_env = self.env.extend("let-scope")

        # First pass: bind all variables as lazy thunks
        # This enables forward references within the let block
        for var in node.variables:
            if var.value is not None:
                # Capture the variable and evaluator in the closure
                # Use default argument to capture current value (avoid late binding)
                def make_computation(expr=var.value, evaluator=self, env=let_env):
                    return evaluator.with_environment(env).evaluate(expr)

                let_env.bind_lazy(var.name, make_computation)
            else:
                # Variable with no value - bind to null
                let_env.bind(var.name, MNull())

        # Evaluate the result expression in the let scope
        if node.result is not None:
            result_evaluator = self.with_environment(let_env)
            return result_evaluator.evaluate(node.result)

        return MNull()

    def visit_variable_assignment(self, node: VariableAssignment) -> MValue:
        """Evaluate a variable assignment.

        This is typically handled by visit_let_expression, but can be
        used for standalone assignments.

        Args:
            node: The VariableAssignment AST node.

        Returns:
            The value of the assignment expression.
        """
        if node.value is not None:
            value = self.evaluate(node.value)
            self.env.bind(node.name, value)
            return value
        return MNull()

    def visit_function_call(self, node: FunctionCall) -> MValue:
        """Evaluate a function call.

        FunctionName(arg1, arg2, ...)

        Resolves the function, evaluates arguments, and invokes the function.

        Args:
            node: The FunctionCall AST node.

        Returns:
            The result of the function call.
        """
        # Get the function name
        func_name = self._get_function_name(node.function)

        # Handle Table.AddColumn specially (needs evaluator context)
        if func_name == "Table.AddColumn":
            return self._eval_table_add_column(node.arguments)

        # Handle Table.SelectRows specially (needs evaluator context)
        if func_name == "Table.SelectRows":
            return self._eval_table_select_rows(node.arguments)

        # Check if it's a built-in function
        builtin = get_builtin(func_name) if func_name else None

        if builtin is not None:
            # Evaluate arguments
            args = [self.evaluate(arg) for arg in node.arguments]
            # Call the built-in function
            return builtin(*args)

        # Try to look up in environment (user-defined function)
        if func_name and self.env.is_bound(func_name):
            func_value = self.env.get(func_name)
            if isinstance(func_value, MFunction):
                return self._call_function(func_value, node.arguments)

        # If function name looks like a qualified name (Namespace.Function),
        # it might be an unimplemented built-in
        if func_name and '.' in func_name:
            raise NotImplementedError(
                f"Built-in function '{func_name}' is not yet implemented"
            )

        raise NameError(f"Unknown function: {func_name}")

    def visit_member_access(self, node: MemberAccess) -> MValue:
        """Evaluate a member access expression.

        object.member

        For M standard library functions like Csv.Document, this returns
        the function reference. For record field access, returns the field value.

        Args:
            node: The MemberAccess AST node.

        Returns:
            The accessed member value.
        """
        # Get the qualified name (e.g., "Csv.Document")
        qualified_name = self._get_qualified_name(node)

        # Check if it's a built-in function reference
        if qualified_name and has_builtin(qualified_name):
            builtin = get_builtin(qualified_name)
            return MFunction(
                parameters=[],
                body=builtin,
                closure=None,
                name=qualified_name
            )

        # Otherwise, evaluate as record field access
        obj_value = self.evaluate(node.object)

        if isinstance(obj_value, MRecord):
            return obj_value.get(node.member)

        if isinstance(obj_value, MTable):
            # Table column access: Table[ColumnName]
            # This would need different syntax in M, but we support it
            if node.member in obj_value.column_names:
                # Return the column as a list
                df = obj_value.collect()
                return MList([python_to_mvalue(v) for v in df[node.member].to_list()])

        raise AttributeError(
            f"Cannot access member '{node.member}' on {obj_value.type_name}"
        )

    def visit_identifier(self, node: Identifier) -> MValue:
        """Evaluate an identifier reference.

        Returns the value bound to the identifier in the current scope.

        Note:
            Keywords like null, true, false are handled by the parser which
            creates NullLiteral/BooleanLiteral nodes, not Identifier nodes.

        Args:
            node: The Identifier AST node.

        Returns:
            The value bound to the identifier.

        Raises:
            NameError: If the identifier is not bound.
        """
        return self.env.get(node.name)

    def visit_string_literal(self, node: StringLiteral) -> MText:
        """Evaluate a string literal.

        Args:
            node: The StringLiteral AST node.

        Returns:
            The MText value.
        """
        return MText(node.value)

    def visit_list_literal(self, node: ListLiteral) -> MList:
        """Evaluate a list literal.

        Args:
            node: The ListLiteral AST node.

        Returns:
            The MList value containing evaluated items.
        """
        items = [self.evaluate(item) for item in node.items]
        return MList(items)

    def visit_number_literal(self, node: NumberLiteral) -> MNumber:
        """Evaluate a number literal.

        Args:
            node: The NumberLiteral AST node.

        Returns:
            The MNumber value.
        """
        # Parse the string value to a number
        if '.' in node.value:
            return MNumber(float(node.value))
        return MNumber(int(node.value))

    def visit_each_expression(self, node: EachExpression) -> MFunction:
        """Evaluate an each expression.

        each <expr> is shorthand for (_) => <expr>

        Args:
            node: The EachExpression AST node.

        Returns:
            An MFunction representing the anonymous function.
        """
        # Create a function that takes one argument (_) and evaluates the body
        def each_func(row: MValue) -> MValue:
            # Create environment with _ bound to the row
            func_env = self.env.extend("each-body")
            func_env.bind("_", row)
            # Also allow field access on the row for records
            if isinstance(row, MRecord):
                for field_name in row.fields:
                    func_env.bind(field_name, row.get(field_name))
            # Evaluate body with row context
            eval_with_row = self.with_environment(func_env)
            eval_with_row._current_row = row  # Store for field access
            if node.body is not None:
                return eval_with_row.evaluate(node.body)
            return MNull()

        return MFunction(
            parameters=["_"],
            body=each_func,
            closure=self.env,
            name="<each>"
        )

    def visit_field_access(self, node: FieldAccess) -> MValue:
        """Evaluate a field access.

        [FieldName] accesses a field from the current row context.

        Args:
            node: The FieldAccess AST node.

        Returns:
            The value of the accessed field.
        """
        # Check if we have a current row in context
        if hasattr(self, '_current_row') and self._current_row is not None:
            if isinstance(self._current_row, MRecord):
                return self._current_row.get(node.field_name)

        # Try to find the field in the current environment
        if self.env.is_bound(node.field_name):
            return self.env.get(node.field_name)

        raise NameError(f"Field '{node.field_name}' not found in current context")

    def visit_binary_expression(self, node: BinaryExpression) -> MValue:
        """Evaluate a binary expression.

        Supports:
        - Comparison: =, <>, >, <, >=, <=
        - Arithmetic: +, -, *, /
        - Text concatenation: &
        - Null coalesce: ??

        Args:
            node: The BinaryExpression AST node.

        Returns:
            The result of the binary operation.
        """
        # Null coalesce operator - short circuit evaluation
        if node.operator == "??":
            left = self.evaluate(node.left) if node.left else MNull()
            if not isinstance(left, MNull):
                return left
            return self.evaluate(node.right) if node.right else MNull()

        left = self.evaluate(node.left) if node.left else MNull()
        right = self.evaluate(node.right) if node.right else MNull()

        # Handle null propagation
        if isinstance(left, MNull) or isinstance(right, MNull):
            return MNull()

        # Comparison operations
        if node.operator == "=" or node.operator == "==":
            return MLogical(left.value == right.value)
        elif node.operator == "<>" or node.operator == "!=":
            return MLogical(left.value != right.value)
        elif node.operator == ">":
            return MLogical(left.value > right.value)
        elif node.operator == "<":
            return MLogical(left.value < right.value)
        elif node.operator == ">=":
            return MLogical(left.value >= right.value)
        elif node.operator == "<=":
            return MLogical(left.value <= right.value)

        # Arithmetic operations
        elif node.operator == "+":
            if isinstance(left, MNumber) and isinstance(right, MNumber):
                return MNumber(left.value + right.value)
            raise TypeError(f"Cannot add {left.type_name} and {right.type_name}")
        elif node.operator == "-":
            if isinstance(left, MNumber) and isinstance(right, MNumber):
                return MNumber(left.value - right.value)
            raise TypeError(f"Cannot subtract {right.type_name} from {left.type_name}")
        elif node.operator == "*":
            if isinstance(left, MNumber) and isinstance(right, MNumber):
                return MNumber(left.value * right.value)
            raise TypeError(f"Cannot multiply {left.type_name} and {right.type_name}")
        elif node.operator == "/":
            if isinstance(left, MNumber) and isinstance(right, MNumber):
                if right.value == 0:
                    raise ZeroDivisionError("Division by zero")
                return MNumber(left.value / right.value)
            raise TypeError(f"Cannot divide {left.type_name} by {right.type_name}")

        # Text concatenation
        elif node.operator == "&":
            # Convert to text if needed and concatenate
            left_text = str(left.value) if not isinstance(left, MText) else left.value
            right_text = str(right.value) if not isinstance(right, MText) else right.value
            return MText(left_text + right_text)

        # Logical operations
        elif node.operator == "and":
            if isinstance(left, MLogical) and isinstance(right, MLogical):
                return MLogical(left.value and right.value)
            raise TypeError(f"Cannot 'and' {left.type_name} and {right.type_name}")
        elif node.operator == "or":
            if isinstance(left, MLogical) and isinstance(right, MLogical):
                return MLogical(left.value or right.value)
            raise TypeError(f"Cannot 'or' {left.type_name} and {right.type_name}")

        raise ValueError(f"Unknown operator: {node.operator}")

    def visit_unary_expression(self, node: UnaryExpression) -> MValue:
        """Evaluate a unary expression.

        Supports:
        - Logical negation: not
        - Numeric negation: -

        Args:
            node: The UnaryExpression AST node.

        Returns:
            The result of the unary operation.
        """
        operand = self.evaluate(node.operand) if node.operand else MNull()

        # Handle null propagation
        if isinstance(operand, MNull):
            return MNull()

        if node.operator == "not":
            if isinstance(operand, MLogical):
                return MLogical(not operand.value)
            raise TypeError(f"Cannot 'not' {operand.type_name}")

        if node.operator == "-":
            if isinstance(operand, MNumber):
                return MNumber(-operand.value)
            raise TypeError(f"Cannot negate {operand.type_name}")

        raise ValueError(f"Unknown unary operator: {node.operator}")

    def visit_type_check(self, node: TypeCheckExpression) -> MValue:
        """Evaluate a type check expression.

        [Value] is null -> checks if Value is null
        [Value] is number -> checks if Value is a number

        Args:
            node: The TypeCheckExpression AST node.

        Returns:
            MLogical indicating if the type check passes.
        """
        operand = self.evaluate(node.operand) if node.operand else MNull()

        if node.type_name == "null":
            return MLogical(isinstance(operand, MNull))
        elif node.type_name == "number":
            return MLogical(isinstance(operand, MNumber))
        elif node.type_name == "text":
            return MLogical(isinstance(operand, MText))
        elif node.type_name == "logical":
            return MLogical(isinstance(operand, MLogical))
        elif node.type_name == "list":
            return MLogical(isinstance(operand, MList))
        elif node.type_name == "record":
            return MLogical(isinstance(operand, MRecord))
        elif node.type_name == "table":
            return MLogical(isinstance(operand, MTable))
        else:
            # Unknown type - return false
            return MLogical(False)

    def visit_if_expression(self, node: IfExpression) -> MValue:
        """Evaluate an if-then-else expression.

        if condition then thenExpr else elseExpr

        Args:
            node: The IfExpression AST node.

        Returns:
            The value of the then or else branch.
        """
        condition = self.evaluate(node.condition) if node.condition else MNull()

        # Handle null condition
        if isinstance(condition, MNull):
            return MNull()

        # Determine truthiness
        is_truthy = False
        if isinstance(condition, MLogical):
            is_truthy = condition.value
        elif isinstance(condition, MNumber):
            is_truthy = condition.value != 0
        elif isinstance(condition, MText):
            is_truthy = len(condition.value) > 0

        if is_truthy:
            return self.evaluate(node.then_expr) if node.then_expr else MNull()
        else:
            return self.evaluate(node.else_expr) if node.else_expr else MNull()

    def visit_null_literal(self, node: NullLiteral) -> MValue:
        """Evaluate a null literal.

        Args:
            node: The NullLiteral AST node.

        Returns:
            MNull value.
        """
        return MNull()

    def visit_boolean_literal(self, node: BooleanLiteral) -> MValue:
        """Evaluate a boolean literal.

        Args:
            node: The BooleanLiteral AST node.

        Returns:
            MLogical value.
        """
        return MLogical(node.value)

    def visit_type_expression(self, node: TypeExpression) -> MValue:
        """Evaluate a type expression.

        Args:
            node: The TypeExpression AST node.

        Returns:
            MText representing the type name (used as a type specifier).
        """
        # Type expressions are used in Table.TransformColumnTypes etc.
        # Return as text since the type name is used for type specification
        return MText(node.type_name)

    def visit_try_expression(self, node: "TryExpression") -> MValue:
        """Evaluate a try-otherwise expression.

        Args:
            node: The TryExpression AST node.

        Returns:
            The result of the expression, or the otherwise value if an error occurs.
        """
        from python_m.ast.nodes import TryExpression as TryExpressionNode

        try:
            if node.expression is None:
                return MNull()
            return node.expression.accept(self)
        except Exception:
            if node.otherwise_expr is not None:
                return node.otherwise_expr.accept(self)
            return MNull()

    def visit_record_literal(self, node: RecordLiteral) -> MValue:
        """Evaluate a record literal: [field1 = value1, field2 = value2, ...].

        Args:
            node: The RecordLiteral AST node.

        Returns:
            MRecord with the evaluated field values.
        """
        record_fields: Dict[str, MValue] = {}
        for field_name, field_value in node.fields.items():
            if field_value is not None:
                record_fields[field_name] = field_value.accept(self)
        return MRecord(record_fields)

    def visit_function_expression(self, node: FunctionExpression) -> MValue:
        """Evaluate a function expression: (x, y) => x + y.

        Args:
            node: The FunctionExpression AST node.

        Returns:
            MFunction that can be called with arguments.
        """
        # Capture the current environment for closure semantics
        captured_env = self.env

        def closure(*args: MValue) -> MValue:
            # Create a new environment extending the captured one
            local_env = Environment(captured_env)
            
            # Bind parameters to arguments
            param_list = node.parameters if node.parameters else []
            for i, param in enumerate(param_list):
                if i < len(args):
                    local_env.set(param.name, args[i])
                elif param.optional:
                    local_env.set(param.name, MNull())
                else:
                    raise RuntimeError(f"Missing required argument: {param.name}")
            
            # Evaluate the body in the new environment
            old_env = self.env
            self.env = local_env
            try:
                if node.body is None:
                    return MNull()
                return node.body.accept(self)
            finally:
                self.env = old_env

        return MFunction(closure)

    def visit_item_access(self, node: ItemAccess) -> MValue:
        """Evaluate item access: target[index] or target{index}.

        Args:
            node: The ItemAccess AST node.

        Returns:
            The accessed item, or MNull for optional access when item doesn't exist.
        """
        if node.target is None:
            return MNull()

        target = node.target.accept(self)
        
        if node.index is None:
            return MNull()

        index = node.index.accept(self)

        try:
            if isinstance(target, MRecord):
                # Record field access
                if isinstance(index, MText):
                    field_name = index.value
                    if field_name in target.fields:
                        return target.fields[field_name]
                    elif node.optional:
                        return MNull()
                    else:
                        raise RuntimeError(f"Field not found: {field_name}")
                elif node.optional:
                    return MNull()
                else:
                    raise RuntimeError(f"Invalid record index type: {type(index)}")
            elif isinstance(target, MList):
                # List item access
                if isinstance(index, MNumber):
                    idx = int(index.value)
                    if 0 <= idx < len(target.items):
                        return target.items[idx]
                    elif node.optional:
                        return MNull()
                    else:
                        raise RuntimeError(f"List index out of range: {idx}")
                elif node.optional:
                    return MNull()
                else:
                    raise RuntimeError(f"Invalid list index type: {type(index)}")
            elif isinstance(target, MTable):
                # Table row access
                if isinstance(index, MNumber):
                    idx = int(index.value)
                    # Return row as a record
                    df = target.to_pandas()
                    if 0 <= idx < len(df):
                        row = df.iloc[idx]
                        return MRecord({col: python_to_mvalue(row[col]) for col in df.columns})
                    elif node.optional:
                        return MNull()
                    else:
                        raise RuntimeError(f"Row index out of range: {idx}")
                elif isinstance(index, MRecord):
                    # Record predicate: find row where all fields match
                    df = target.to_pandas()
                    matches = []
                    for i in range(len(df)):
                        row = df.iloc[i]
                        all_match = True
                        for field_name, field_value in index.fields.items():
                            if field_name not in df.columns:
                                all_match = False
                                break
                            row_value = python_to_mvalue(row[field_name])
                            if not self._values_equal(row_value, field_value):
                                all_match = False
                                break
                        if all_match:
                            matches.append(i)

                    if len(matches) == 0:
                        if node.optional:
                            return MNull()
                        raise RuntimeError("Expression.Error: The key didn't match any rows in the table")
                    if len(matches) > 1:
                        raise RuntimeError("Expression.Error: The key matched more than one row in the table")

                    row = df.iloc[matches[0]]
                    return MRecord({col: python_to_mvalue(row[col]) for col in df.columns})
                elif node.optional:
                    return MNull()
                else:
                    raise RuntimeError(f"Invalid table index type: {type(index)}")
            elif node.optional:
                return MNull()
            else:
                raise RuntimeError(f"Cannot index into {type(target)}")
        except Exception:
            if node.optional:
                return MNull()
            raise

    def visit_inclusive_identifier(self, node: InclusiveIdentifier) -> MValue:
        """Evaluate an inclusive identifier reference: @name.

        Used for recursive function references.

        Args:
            node: The InclusiveIdentifier AST node.

        Returns:
            The value bound to the identifier in the current environment.
        """
        # @name refers to the current binding being defined, enabling recursion
        value = self.env.get(node.name)
        if value is None:
            raise RuntimeError(f"Undefined identifier: @{node.name}")
        return value

    def visit_error_expression(self, node: ErrorExpression) -> MValue:
        """Evaluate an error expression: error <expr>.

        Args:
            node: The ErrorExpression AST node.

        Returns:
            Never returns - always raises an error.
        """
        if node.expression is not None:
            error_value = node.expression.accept(self)
            raise RuntimeError(f"Error: {error_value}")
        raise RuntimeError("Error raised")

    def visit_not_implemented_expression(self, node: NotImplementedExpression) -> MValue:
        """Evaluate a not implemented expression: ...

        Args:
            node: The NotImplementedExpression AST node.

        Returns:
            Never returns - always raises an error.
        """
        raise NotImplementedError("Expression not implemented")

    def visit_meta_expression(self, node: "MetaExpression") -> MValue:
        """Evaluate a meta expression: value meta metadata.

        In Power Query, the meta operator attaches metadata to a value.
        For simplicity, we evaluate both the value and metadata, and
        return the value (metadata can be retrieved via Value.Metadata).

        Args:
            node: The MetaExpression AST node.

        Returns:
            The evaluated value (metadata is attached but not returned).
        """
        value = node.value.accept(self)
        metadata = node.metadata.accept(self)

        # Store metadata on the value if possible
        # For now, we just return the value - full metadata support
        # would require attaching metadata to MValue instances
        if hasattr(value, "_metadata"):
            value._metadata = metadata

        return value

    def visit_section_document(self, node: SectionDocument) -> MValue:
        """Evaluate a section document.

        Section documents contain multiple member declarations.
        Returns a record containing all shared members.

        Args:
            node: The SectionDocument AST node.

        Returns:
            MRecord containing all shared member values.
        """
        # Create a new environment scope for the section
        section_env = self.env.extend(node.name)

        # First pass: bind all members as thunks (lazy evaluation)
        for member in node.members:
            thunk = Thunk(member.value, section_env, self)
            section_env.bind(member.name, thunk)

        # Second pass: evaluate and collect shared members
        shared_members: Dict[str, MValue] = {}
        for member in node.members:
            if member.shared:
                value = section_env.lookup(member.name)
                if isinstance(value, Thunk):
                    value = value.force()
                shared_members[member.name] = value

        return MRecord(shared_members)

    def visit_section_member(self, node: SectionMember) -> MValue:
        """Evaluate a section member.

        This is typically called during iteration of section members
        in visit_section_document.

        Args:
            node: The SectionMember AST node.

        Returns:
            The evaluated member value.
        """
        if node.value is not None:
            return node.value.accept(self)
        return MNull()

    # =========================================================================
    # Helper Methods
    # =========================================================================

    def _get_function_name(self, node: Optional[ASTNode]) -> Optional[str]:
        """Extract the function name from a function reference node.

        Handles both simple identifiers and qualified names (Namespace.Function).

        Args:
            node: The function reference node.

        Returns:
            The function name as a string, or None if invalid.
        """
        if node is None:
            return None

        if isinstance(node, Identifier):
            return node.name

        if isinstance(node, MemberAccess):
            return self._get_qualified_name(node)

        return None

    def _get_qualified_name(self, node: MemberAccess) -> Optional[str]:
        """Get the fully qualified name from a member access chain.

        Handles nested access like A.B.C -> "A.B.C"

        Args:
            node: The MemberAccess node.

        Returns:
            The qualified name string.
        """
        parts: List[str] = []

        current: Optional[ASTNode] = node
        while current is not None:
            if isinstance(current, MemberAccess):
                parts.append(current.member)
                current = current.object
            elif isinstance(current, Identifier):
                parts.append(current.name)
                break
            else:
                break

        parts.reverse()
        return ".".join(parts) if parts else None

    def _call_function(self, func: MFunction, arg_nodes: List[ASTNode]) -> MValue:
        """Call a user-defined M function.

        Args:
            func: The MFunction to call.
            arg_nodes: AST nodes for the arguments.

        Returns:
            The result of the function call.
        """
        # Evaluate arguments
        args = [self.evaluate(arg) for arg in arg_nodes]

        # If body is a Python callable (for built-ins wrapped as MFunction)
        if callable(func.body):
            return func.body(*args)

        # For AST-body functions, create function scope with parameters bound
        if func.closure is not None:
            func_env = func.closure.extend("function-body")
        else:
            func_env = self.env.extend("function-body")

        # Bind parameters to arguments
        for param, arg in zip(func.parameters, args):
            func_env.bind(param, arg)

        # Evaluate function body
        func_evaluator = self.with_environment(func_env)
        return func_evaluator.evaluate(func.body)

    def _eval_table_add_column(self, arg_nodes: List[ASTNode]) -> MTable:
        """Evaluate Table.AddColumn with evaluator context.

        Table.AddColumn(table, newColumnName, columnGenerator)

        Args:
            arg_nodes: AST nodes for [table, newColumnName, columnGenerator].

        Returns:
            Table with the new column added.
        """
        import polars as pl

        if len(arg_nodes) < 3:
            raise TypeError("Table.AddColumn requires at least 3 arguments")

        # Evaluate table and column name
        table = self.evaluate(arg_nodes[0])
        column_name = self.evaluate(arg_nodes[1])

        if not isinstance(table, MTable):
            raise TypeError(f"Table.AddColumn expects table, got {table.type_name}")
        if not isinstance(column_name, MText):
            raise TypeError(f"Table.AddColumn expects text column name, got {column_name.type_name}")

        # Get the column generator (each expression or function)
        generator_node = arg_nodes[2]

        # Collect the table to iterate over rows
        df = table.collect()
        new_values = []

        # Evaluate the generator for each row
        for i in range(len(df)):
            row_data = df.row(i, named=True)
            row_record = MRecord({k: python_to_mvalue(v) for k, v in row_data.items()})

            # If generator is an EachExpression, evaluate with row context
            if isinstance(generator_node, EachExpression):
                func_env = self.env.extend("each-body")
                func_env.bind("_", row_record)
                for field_name in row_record.fields:
                    func_env.bind(field_name, row_record.get(field_name))
                row_eval = self.with_environment(func_env)
                row_eval._current_row = row_record
                if generator_node.body is not None:
                    result = row_eval.evaluate(generator_node.body)
                else:
                    result = MNull()
            else:
                # Evaluate as a function
                func = self.evaluate(generator_node)
                if isinstance(func, MFunction) and callable(func.body):
                    result = func.body(row_record)
                else:
                    result = MNull()

            new_values.append(result.to_python() if hasattr(result, 'to_python') else result)

        # Add the new column to the dataframe
        new_df = df.with_columns(pl.Series(column_name.value, new_values))
        return MTable.from_polars(new_df)

    def _eval_table_select_rows(self, arg_nodes: List[ASTNode]) -> MTable:
        """Evaluate Table.SelectRows with evaluator context.

        Table.SelectRows(table, condition)

        Args:
            arg_nodes: AST nodes for [table, condition].

        Returns:
            Filtered table with rows matching the condition.
        """
        if len(arg_nodes) < 2:
            raise TypeError("Table.SelectRows requires 2 arguments")

        # Evaluate table
        table = self.evaluate(arg_nodes[0])

        if not isinstance(table, MTable):
            raise TypeError(f"Table.SelectRows expects table, got {table.type_name}")

        # Get the condition (each expression or function)
        condition_node = arg_nodes[1]

        # Collect the table to iterate over rows
        df = table.collect()
        keep_indices = []

        # Evaluate the condition for each row
        for i in range(len(df)):
            row_data = df.row(i, named=True)
            row_record = MRecord({k: python_to_mvalue(v) for k, v in row_data.items()})

            # If condition is an EachExpression, evaluate with row context
            if isinstance(condition_node, EachExpression):
                func_env = self.env.extend("each-body")
                func_env.bind("_", row_record)
                for field_name in row_record.fields:
                    func_env.bind(field_name, row_record.get(field_name))
                row_eval = self.with_environment(func_env)
                row_eval._current_row = row_record
                if condition_node.body is not None:
                    result = row_eval.evaluate(condition_node.body)
                else:
                    result = MLogical(True)
            else:
                # Evaluate as a function
                func = self.evaluate(condition_node)
                if isinstance(func, MFunction) and callable(func.body):
                    result = func.body(row_record)
                else:
                    result = MLogical(True)

            # Check if result is truthy
            if isinstance(result, MLogical) and result.value:
                keep_indices.append(i)
            elif isinstance(result, MNumber) and result.value != 0:
                keep_indices.append(i)

        # Filter the dataframe
        filtered_df = df[keep_indices] if keep_indices else df.clear()
        return MTable.from_polars(filtered_df)


def evaluate(source: str, env: Optional[Environment] = None) -> MValue:
    """Parse and evaluate M source code.

    This is the main entry point for executing M code.

    Args:
        source: M source code string.
        env: Optional environment with pre-defined bindings.

    Returns:
        The result of evaluating the M code.

    Example:
        result = evaluate('''
            let
                x = 1,
                y = 2
            in
                x + y
        ''')
        print(result)  # MNumber(3)
    """
    # Parse the source code
    ast = parse(source)

    if ast is None:
        raise SyntaxError("Failed to parse M source code")

    # Create evaluator and execute
    evaluator = Evaluator(env)
    return evaluator.evaluate(ast)


def evaluate_with_context(
    source: str,
    context: dict[str, Any]
) -> MValue:
    """Evaluate M code with pre-defined context variables.

    Useful for providing external data to M code.

    Args:
        source: M source code string.
        context: Dictionary of name -> value bindings to pre-define.

    Returns:
        The result of evaluating the M code.

    Example:
        import polars as pl
        df = pl.DataFrame({"A": [1, 2, 3]})

        result = evaluate_with_context('''
            let
                Result = Table.SelectColumns(InputTable, {"A"})
            in
                Result
        ''', {"InputTable": df})
    """
    # Create environment with context
    global_env = GlobalEnvironment()
    register_builtins(global_env)

    context_env = global_env.extend("context")
    for name, value in context.items():
        context_env.bind(name, python_to_mvalue(value))

    # Parse and evaluate
    ast = parse(source)
    if ast is None:
        raise SyntaxError("Failed to parse M source code")

    evaluator = Evaluator(context_env)
    return evaluator.evaluate(ast)
