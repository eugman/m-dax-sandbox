"""Dataflow Transpiler - Convert Power Query M code to Pandas, PySpark, and Fabric pipelines."""

__version__ = "0.1.0"
__author__ = "Dataflow Transpiler Team"

from python_m.transpiler import transpile, TranspileResult

__all__ = ["transpile", "TranspileResult", "__version__"]
