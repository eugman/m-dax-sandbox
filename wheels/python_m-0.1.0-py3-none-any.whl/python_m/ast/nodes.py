"""AST node definitions for Power Query M language.

This module defines the Abstract Syntax Tree nodes used to represent
parsed M code. Each node type corresponds to a construct in the M language.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


class ASTNode(ABC):
    """Base class for all AST nodes.

    Provides the visitor pattern interface for traversing the AST.
    """

    @abstractmethod
    def accept(self, visitor: "ASTVisitor") -> Any:
        """Accept a visitor for traversing the AST.

        Args:
            visitor: The visitor implementing the traversal logic.

        Returns:
            The result of visiting this node.
        """
        pass


class ASTVisitor(ABC):
    """Base class for AST visitors.

    Implement this interface to traverse and process the AST.
    """

    @abstractmethod
    def visit_let_expression(self, node: "LetExpression") -> Any:
        pass

    @abstractmethod
    def visit_variable_assignment(self, node: "VariableAssignment") -> Any:
        pass

    @abstractmethod
    def visit_function_call(self, node: "FunctionCall") -> Any:
        pass

    @abstractmethod
    def visit_member_access(self, node: "MemberAccess") -> Any:
        pass

    @abstractmethod
    def visit_identifier(self, node: "Identifier") -> Any:
        pass

    @abstractmethod
    def visit_string_literal(self, node: "StringLiteral") -> Any:
        pass

    @abstractmethod
    def visit_list_literal(self, node: "ListLiteral") -> Any:
        pass

    @abstractmethod
    def visit_number_literal(self, node: "NumberLiteral") -> Any:
        pass

    @abstractmethod
    def visit_each_expression(self, node: "EachExpression") -> Any:
        pass

    @abstractmethod
    def visit_field_access(self, node: "FieldAccess") -> Any:
        pass

    @abstractmethod
    def visit_binary_expression(self, node: "BinaryExpression") -> Any:
        pass

    @abstractmethod
    def visit_unary_expression(self, node: "UnaryExpression") -> Any:
        pass

    @abstractmethod
    def visit_type_check(self, node: "TypeCheckExpression") -> Any:
        pass

    @abstractmethod
    def visit_if_expression(self, node: "IfExpression") -> Any:
        pass

    @abstractmethod
    def visit_null_literal(self, node: "NullLiteral") -> Any:
        pass

    @abstractmethod
    def visit_boolean_literal(self, node: "BooleanLiteral") -> Any:
        pass

    @abstractmethod
    def visit_type_expression(self, node: "TypeExpression") -> Any:
        pass

    @abstractmethod
    def visit_try_expression(self, node: "TryExpression") -> Any:
        pass

    @abstractmethod
    def visit_record_literal(self, node: "RecordLiteral") -> Any:
        pass

    @abstractmethod
    def visit_function_expression(self, node: "FunctionExpression") -> Any:
        pass

    @abstractmethod
    def visit_item_access(self, node: "ItemAccess") -> Any:
        pass

    @abstractmethod
    def visit_inclusive_identifier(self, node: "InclusiveIdentifier") -> Any:
        pass

    @abstractmethod
    def visit_error_expression(self, node: "ErrorExpression") -> Any:
        pass

    @abstractmethod
    def visit_not_implemented_expression(self, node: "NotImplementedExpression") -> Any:
        pass

    @abstractmethod
    def visit_meta_expression(self, node: "MetaExpression") -> Any:
        pass

    @abstractmethod
    def visit_section_document(self, node: "SectionDocument") -> Any:
        pass

    @abstractmethod
    def visit_section_member(self, node: "SectionMember") -> Any:
        pass


# Type alias for expressions (any node that can appear in expression position)
Expression = ASTNode


@dataclass
class LetExpression(ASTNode):
    """Represents the top-level 'let ... in ...' construct.

    Example:
        let
            Source = Csv.Document(...)
        in
            Source

    Attributes:
        variables: List of variable bindings in the let block.
        result: The expression after 'in' that produces the final result.
    """

    variables: List["VariableAssignment"] = field(default_factory=list)
    result: Optional[Expression] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_let_expression(self)


@dataclass
class VariableAssignment(ASTNode):
    """Represents a single 'name = expression' binding.

    Example:
        Source = Csv.Document(File.Contents("data.csv"))

    Attributes:
        name: The variable identifier.
        value: The expression assigned to the variable.
        comment: Optional comment preceding this assignment.
    """

    name: str = ""
    value: Optional[Expression] = None
    comment: Optional[str] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_variable_assignment(self)


@dataclass
class FunctionCall(ASTNode):
    """Represents a function invocation.

    Example:
        Csv.Document(File.Contents("path.csv"))

    Attributes:
        function: The function being called (Identifier or MemberAccess).
        arguments: List of positional arguments passed to the function.
    """

    function: Optional[Expression] = None
    arguments: List[Expression] = field(default_factory=list)

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_function_call(self)


@dataclass
class MemberAccess(ASTNode):
    """Represents dotted member access like 'Csv.Document'.

    Example:
        Csv.Document
        File.Contents

    Attributes:
        object: The left side of the dot (the object being accessed).
        member: The right side of the dot (the member name).
    """

    object: Optional[Expression] = None
    member: str = ""

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_member_access(self)


@dataclass
class Identifier(ASTNode):
    """Represents a simple name reference.

    Example:
        Source
        Csv
        File

    Attributes:
        name: The identifier text.
    """

    name: str = ""

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_identifier(self)


@dataclass
class StringLiteral(ASTNode):
    """Represents a quoted string value.

    Example:
        "path/to/file.csv"
        "Hello, World!"

    Attributes:
        value: The string contents (without surrounding quotes).
    """

    value: str = ""

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_string_literal(self)


@dataclass
class ListLiteral(ASTNode):
    """Represents a list literal with curly braces.

    Example:
        {"col1", "col2", "col3"}
        {1, 2, 3}

    Attributes:
        items: The list of expressions in the list.
    """

    items: List[Expression] = field(default_factory=list)

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_list_literal(self)


@dataclass
class NumberLiteral(ASTNode):
    """Represents a numeric literal value.

    Example:
        42
        3.14
        100

    Attributes:
        value: The numeric value as a string (to preserve precision).
    """

    value: str = ""

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_number_literal(self)


@dataclass
class EachExpression(ASTNode):
    """Represents an 'each' expression (anonymous function).

    Example:
        each [CustomerID] > 2
        each Text.Upper([Name])

    The 'each' keyword is shorthand for '(_) =>' where _ is the current row.

    Attributes:
        body: The expression to evaluate for each row.
    """

    body: Optional[Expression] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_each_expression(self)


@dataclass
class FieldAccess(ASTNode):
    """Represents field access using bracket notation.

    Example:
        [CustomerID]
        [Name]

    Used within 'each' expressions to access fields of the current row.

    Attributes:
        field_name: The name of the field being accessed.
    """

    field_name: str = ""

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_field_access(self)


@dataclass
class BinaryExpression(ASTNode):
    """Represents a binary operation.

    Example:
        [Value] > 100
        [Name] = "Bob"
        [Active] and [Verified]

    Attributes:
        left: The left operand.
        operator: The operator (e.g., ">", "<", ">=", "<=", "<>", "=", "and", "or").
        right: The right operand.
    """

    left: Optional[Expression] = None
    operator: str = ""
    right: Optional[Expression] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_binary_expression(self)


@dataclass
class UnaryExpression(ASTNode):
    """Represents a unary operation.

    Example:
        not [Active]
        not ([Value] > 100)

    Attributes:
        operator: The operator (e.g., "not").
        operand: The expression being operated on.
    """

    operator: str = ""
    operand: Optional[Expression] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_unary_expression(self)


@dataclass
class TypeCheckExpression(ASTNode):
    """Represents an 'is' type check expression.

    Example:
        [Value] is null
        [Amount] is number

    Attributes:
        operand: The expression being type-checked.
        type_name: The type to check for (e.g., "null", "number").
    """

    operand: Optional[Expression] = None
    type_name: str = ""

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_type_check(self)


@dataclass
class IfExpression(ASTNode):
    """Represents an if-then-else expression.

    Example:
        if [Value] > 100 then "High" else "Low"

    Attributes:
        condition: The condition to evaluate.
        then_expr: The expression if condition is true.
        else_expr: The expression if condition is false.
    """

    condition: Optional[Expression] = None
    then_expr: Optional[Expression] = None
    else_expr: Optional[Expression] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_if_expression(self)


@dataclass
class NullLiteral(ASTNode):
    """Represents the null literal value.

    Example:
        null
    """

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_null_literal(self)


@dataclass
class BooleanLiteral(ASTNode):
    """Represents a boolean literal value.

    Example:
        true
        false

    Attributes:
        value: The boolean value.
    """

    value: bool = False

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_boolean_literal(self)


@dataclass
class TypeExpression(ASTNode):
    """Represents a type expression.

    Example:
        type number
        type text
        type date
        type table [id = number, name = text]

    Used in Table.TransformColumnTypes and other type-related functions.

    Attributes:
        type_name: The name of the type (e.g., "number", "text", "date", "table").
        columns: For table types, a dict mapping column names to their type names.
    """

    type_name: str = ""
    columns: Optional[Dict[str, str]] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_type_expression(self)


@dataclass
class TryExpression(ASTNode):
    """Represents a try-otherwise error handling expression.

    Example:
        try someValue otherwise defaultValue
        try riskyFunction() otherwise null

    Evaluates the expression and returns its value. If an error occurs,
    returns the otherwise value instead.

    Attributes:
        expression: The expression to try.
        otherwise_expr: The fallback expression if an error occurs (optional).
    """

    expression: Optional[Expression] = None
    otherwise_expr: Optional[Expression] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_try_expression(self)


@dataclass
class RecordLiteral(ASTNode):
    """Represents a record literal: [field1 = value1, field2 = value2, ...].

    Example:
        [Name = "Alice", Age = 30]
        []  // empty record

    Attributes:
        fields: A dictionary mapping field names to their expressions.
    """

    fields: Dict[str, Expression] = field(default_factory=dict)

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_record_literal(self)


@dataclass
class FunctionParameter:
    """Represents a parameter in a function expression.

    Attributes:
        name: The parameter name.
        optional: Whether the parameter is optional.
        type_annotation: Optional type annotation (e.g., "number", "text").
    """

    name: str = ""
    optional: bool = False
    type_annotation: Optional[str] = None


@dataclass
class FunctionExpression(ASTNode):
    """Represents a function expression: (x, y) => x + y.

    With optional type annotations: (x as number) as number => x + 1

    Example:
        (x) => x + 1
        (a, b) => a * b
        () => 42
        (optional x) => if x = null then 0 else x
        (x as number) as number => x + 1

    Attributes:
        parameters: List of function parameters.
        body: The function body expression.
        return_type: Optional return type annotation.
    """

    parameters: List[FunctionParameter] = field(default_factory=list)
    body: Optional[Expression] = None
    return_type: Optional[str] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_function_expression(self)


@dataclass
class ItemAccess(ASTNode):
    """Represents item access: target[index] or target{index}.

    Used for record field access (A[B]) and list indexing (L{0}).

    Example:
        record[fieldName]
        list{0}
        record[field]?  // optional access

    Attributes:
        target: The expression being accessed.
        index: The index expression (field name or list index).
        optional: Whether this is optional access (returns null instead of error).
    """

    target: Optional[Expression] = None
    index: Optional[Expression] = None
    optional: bool = False

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_item_access(self)


@dataclass
class InclusiveIdentifier(ASTNode):
    """Represents an inclusive identifier reference: @name.

    Used to reference the current identifier being initialized (for recursion).

    Example:
        @Factorial  // self-reference in recursive function

    Attributes:
        name: The identifier name (without the @ prefix).
    """

    name: str = ""

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_inclusive_identifier(self)


@dataclass
class ErrorExpression(ASTNode):
    """Represents an error raising expression: error expression.

    Example:
        error "Invalid value"
        error [Reason = "Not found", Detail = "Missing key"]

    Attributes:
        expression: The error value expression.
    """

    expression: Optional[Expression] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_error_expression(self)


@dataclass
class NotImplementedExpression(ASTNode):
    """Represents a not implemented expression: ...

    Used as a placeholder for unimplemented code.

    Example:
        let
            Todo = ...
        in
            Todo
    """

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_not_implemented_expression(self)


@dataclass
class MetaExpression(ASTNode):
    """Represents a meta expression: value meta metadata

    Attaches metadata (a record) to a value. The metadata can contain
    any fields, commonly used for documentation.

    Example:
        5 meta [Documentation = "A number"]
        Table meta [Description = "Sales data"]

    Attributes:
        value: The value expression.
        metadata: The metadata record expression.
    """

    value: "Expression"
    metadata: "Expression"

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_meta_expression(self)


@dataclass
class SectionDocument(ASTNode):
    """Represents a section document: [annotation]? section Name; members...

    Used in Power Query section documents (e.g., Fabric Dataflow Gen2 mashup.pq).
    Contains shared and private member declarations.

    Example:
        [DefaultOutputDestinationSettings = [...]]
        section Section1;
        shared Query1 = let ... in ...;
        shared Query2 = let ... in ...;

    Attributes:
        name: The section name.
        members: List of section members (shared and private declarations).
        document_annotation: Optional document-level annotation record.
    """

    name: str = ""
    members: List["SectionMember"] = field(default_factory=list)
    document_annotation: Optional["RecordLiteral"] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_section_document(self)


@dataclass
class SectionMember(ASTNode):
    """Represents a section member: [attributes] shared? name = expression;

    Represents a member within a section document. May have:
    - Optional attribute annotations (e.g., [BindToDefaultDestination = true])
    - Optional 'shared' modifier for global visibility
    - A name and value expression

    Example:
        shared Query1 = let ... in ...;
        [BindToDefaultDestination = true]
        shared Query2 = let ... in ...;

    Attributes:
        name: The member name.
        value: The expression assigned to the member.
        shared: Whether the member is shared (globally visible).
        attributes: Optional record literal containing attribute annotations.
    """

    name: str = ""
    value: Optional[Expression] = None
    shared: bool = False
    attributes: Optional["RecordLiteral"] = None

    def accept(self, visitor: ASTVisitor) -> Any:
        return visitor.visit_section_member(self)
