"""Parser for Power Query M language.

This module parses a stream of tokens into an Abstract Syntax Tree (AST).
Uses recursive descent parsing for the M language grammar.
"""

import traceback
from dataclasses import dataclass, field
from typing import List, Optional

from python_m.parser.lexer import Token, TokenType
from python_m.ast.nodes import (
    ASTNode,
    LetExpression,
    VariableAssignment,
    FunctionCall,
    MemberAccess,
    Identifier,
    StringLiteral,
    ListLiteral,
    NumberLiteral,
    EachExpression,
    FieldAccess,
    BinaryExpression,
    UnaryExpression,
    TypeCheckExpression,
    IfExpression,
    NullLiteral,
    BooleanLiteral,
    TypeExpression,
    TryExpression,
    RecordLiteral,
    FunctionExpression,
    FunctionParameter,
    ItemAccess,
    InclusiveIdentifier,
    ErrorExpression,
    NotImplementedExpression,
    MetaExpression,
    SectionDocument,
    SectionMember,
)


@dataclass
class ParseError:
    """Represents a parsing error.

    Attributes:
        message: Human-readable error description.
        line: Line number where error occurred.
        column: Column number where error occurred.
        token: The token that caused the error (if available).
    """

    message: str
    line: int
    column: int
    token: Optional[Token] = None


@dataclass
class ParseResult:
    """Result of parsing M code.

    Attributes:
        success: True if parsing succeeded without errors.
        ast: The root AST node (LetExpression, SectionDocument, or other), or None if parsing failed.
        errors: List of parse errors encountered.
    """

    success: bool
    ast: Optional[ASTNode] = None
    errors: List[ParseError] = field(default_factory=list)


class Parser:
    """Recursive descent parser for Power Query M language.

    Parses a token stream into an AST. Currently supports:
    - let ... in ... expressions
    - Variable assignments
    - Function calls
    - Member access (dotted notation)
    - Identifiers
    - String literals

    Example:
        from python_m.parser.lexer import Lexer
        lexer = Lexer('let Source = Csv.Document(...) in Source')
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        result = parser.parse()
    """

    def __init__(self, tokens: List[Token]):
        """Initialize the parser with a token list.

        Args:
            tokens: List of tokens from the lexer.
        """
        self.tokens = tokens
        self.pos = 0
        self.errors: List[ParseError] = []

    def parse(self) -> ParseResult:
        """Parse the token stream into an AST.

        Returns:
            ParseResult containing success status, AST, and any errors.
        """
        self.pos = 0
        self.errors = []

        try:
            # Skip any leading comments at the document level
            self._skip_comments()

            # Check if this is a section document (with or without document-level annotation)
            if self._check(TokenType.SECTION):
                ast = self._parse_section_document()
            elif self._check(TokenType.LBRACKET):
                # Could be a document-level annotation before section, or a regular record expression
                saved_pos = self.pos
                bracket_expr = self._parse_bracket_expression()

                self._skip_comments()

                if self._check(TokenType.SECTION) and isinstance(bracket_expr, RecordLiteral):
                    # This is a document-level annotation followed by section
                    ast = self._parse_section_document(document_annotation=bracket_expr)
                else:
                    # Not a section document, restore position and parse as expression
                    self.pos = saved_pos
                    ast = self._parse_expression()
            else:
                ast = self._parse_expression()

            if ast is None:
                return ParseResult(success=False, errors=self.errors)
            # Fail if there were any parse errors, even if we recovered an AST
            if self.errors:
                return ParseResult(success=False, ast=ast, errors=self.errors)
            return ParseResult(success=True, ast=ast, errors=self.errors)
        except (IndexError, KeyError, AttributeError, ValueError) as e:
            # Expected parser errors - these can occur due to malformed input
            self._add_error(f"Parser error: {e}")
            return ParseResult(success=False, errors=self.errors)
        except Exception as e:
            # Unexpected errors - include traceback for debugging
            tb = traceback.format_exc()
            self._add_error(f"Unexpected parser error: {e}\n{tb}")
            return ParseResult(success=False, errors=self.errors)

    def _current(self) -> Token:
        """Get the current token."""
        if self.pos >= len(self.tokens):
            return self.tokens[-1]  # Return EOF
        return self.tokens[self.pos]

    def _peek(self) -> Token:
        """Peek at the current token without consuming it."""
        return self._current()

    def _is_at_end(self) -> bool:
        """Check if we've reached the end of tokens."""
        return self._current().type == TokenType.EOF

    def _advance(self) -> Token:
        """Consume and return the current token."""
        token = self._current()
        if not self._is_at_end():
            self.pos += 1
        return token

    def _check(self, token_type: TokenType) -> bool:
        """Check if the current token is of the given type."""
        return self._current().type == token_type

    def _check_at(self, offset: int, token_type: TokenType) -> bool:
        """Check if a token at the given offset is of the given type."""
        index = self.pos + offset
        if index >= len(self.tokens):
            return False
        return self.tokens[index].type == token_type

    def _match(self, *token_types: TokenType) -> bool:
        """Check if current token matches any of the given types, and advance if so."""
        for token_type in token_types:
            if self._check(token_type):
                self._advance()
                return True
        return False

    def _consume(self, token_type: TokenType, message: str) -> Optional[Token]:
        """Consume a token of the expected type, or add an error."""
        if self._check(token_type):
            return self._advance()
        self._add_error(message)
        return None

    def _add_error(self, message: str) -> None:
        """Add a parse error at the current position."""
        token = self._current()
        self.errors.append(ParseError(message, token.line, token.column, token))

    def _skip_comments(self) -> None:
        """Skip any comment tokens at the current position."""
        while self._check(TokenType.COMMENT):
            self._advance()

    def _parse_section_document(self, document_annotation: Optional[RecordLiteral] = None) -> Optional[SectionDocument]:
        """Parse a section document: [annotation]? section Name; members...

        Section documents are used in Power Query section documents like
        Fabric Dataflow Gen2 mashup.pq files.

        Args:
            document_annotation: Optional document-level annotation already parsed.
        """
        # Consume 'section' keyword
        self._advance()
        self._skip_comments()

        # Parse section name
        name_token = self._consume(TokenType.IDENTIFIER, "Expected section name after 'section'")
        if not name_token:
            return None
        section_name = name_token.value

        self._skip_comments()

        # Consume semicolon after section name
        if not self._consume(TokenType.SEMICOLON, "Expected ';' after section name"):
            return None

        self._skip_comments()

        # Parse section members
        members: List[SectionMember] = []
        while not self._is_at_end():
            self._skip_comments()
            if self._is_at_end():
                break

            member = self._parse_section_member()
            if member:
                members.append(member)
            else:
                # Try to recover by skipping to next semicolon
                while not self._is_at_end() and not self._check(TokenType.SEMICOLON):
                    self._advance()
                if self._check(TokenType.SEMICOLON):
                    self._advance()

        return SectionDocument(name=section_name, members=members, document_annotation=document_annotation)

    def _parse_section_member(self) -> Optional[SectionMember]:
        """Parse a section member: [attributes] shared? name = expression;

        Represents a member within a section document.
        """
        self._skip_comments()

        # Parse optional attribute annotations [attr = value, ...]
        attributes: Optional[RecordLiteral] = None
        if self._check(TokenType.LBRACKET):
            # Save position in case we need to restore
            saved_pos = self.pos
            bracket_result = self._parse_bracket_expression()

            if isinstance(bracket_result, RecordLiteral):
                self._skip_comments()
                # Check if followed by 'shared' or identifier - if so, it's an attribute
                if self._check(TokenType.SHARED) or self._check(TokenType.IDENTIFIER):
                    attributes = bracket_result
                else:
                    # Not attributes, restore position
                    self.pos = saved_pos
            else:
                # Not a record literal, restore position
                self.pos = saved_pos

        self._skip_comments()

        # Parse optional 'shared' keyword
        is_shared = self._match(TokenType.SHARED)

        self._skip_comments()

        # Parse member name
        name_token = self._consume(TokenType.IDENTIFIER, "Expected member name")
        if not name_token:
            return None
        member_name = name_token.value

        self._skip_comments()

        # Consume '='
        if not self._consume(TokenType.EQUALS, "Expected '=' after member name"):
            return None

        self._skip_comments()

        # Parse expression value
        value = self._parse_expression()
        if not value:
            return None

        self._skip_comments()

        # Consume terminating semicolon
        if not self._consume(TokenType.SEMICOLON, "Expected ';' after member expression"):
            return None

        return SectionMember(name=member_name, value=value, shared=is_shared, attributes=attributes)

    def _parse_expression(self) -> Optional[ASTNode]:
        """Parse any expression."""
        if self._check(TokenType.LET):
            return self._parse_let_expression()
        if self._check(TokenType.EACH):
            return self._parse_each_expression()
        if self._check(TokenType.IF):
            return self._parse_if_expression()
        if self._check(TokenType.TRY):
            return self._parse_try_expression()
        return self._parse_coalesce()

    def _parse_coalesce(self) -> Optional[ASTNode]:
        """Parse null coalesce expression: left ?? right (lowest precedence)."""
        left = self._parse_meta()

        while self._check(TokenType.QUESTION_QUESTION):
            self._advance()
            right = self._parse_meta()
            left = BinaryExpression(left=left, operator="??", right=right)

        return left

    def _parse_meta(self) -> Optional[ASTNode]:
        """Parse meta expression: value meta metadata.

        Attaches metadata (a record) to a value.
        """
        left = self._parse_logical_or()

        while self._check(TokenType.META):
            self._advance()
            metadata = self._parse_logical_or()
            left = MetaExpression(value=left, metadata=metadata)

        return left

    def _parse_logical_or(self) -> Optional[ASTNode]:
        """Parse logical OR expression: left or right (lowest precedence)."""
        left = self._parse_logical_and()

        while self._check(TokenType.OR):
            self._advance()
            right = self._parse_logical_and()
            left = BinaryExpression(left=left, operator="or", right=right)

        return left

    def _parse_logical_and(self) -> Optional[ASTNode]:
        """Parse logical AND expression: left and right."""
        left = self._parse_unary()

        while self._check(TokenType.AND):
            self._advance()
            right = self._parse_unary()
            left = BinaryExpression(left=left, operator="and", right=right)

        return left

    def _parse_unary(self) -> Optional[ASTNode]:
        """Parse unary expression: not operand.

        In M, 'not' has lower precedence than comparison operators,
        so 'not [x] = 1' means 'not ([x] = 1)'.
        """
        if self._check(TokenType.NOT):
            self._advance()
            operand = self._parse_unary()  # Allow chained not: not not x
            return UnaryExpression(operator="not", operand=operand)

        return self._parse_comparison()

    def _parse_let_expression(self) -> Optional[LetExpression]:
        """Parse a let ... in ... expression."""
        if not self._consume(TokenType.LET, "Expected 'let'"):
            return None

        variables = []
        while not self._check(TokenType.IN) and not self._is_at_end():
            # Check for IN after comments (handled by _parse_variable_assignment)
            if self._check(TokenType.IN):
                break
            var = self._parse_variable_assignment()
            if var:
                variables.append(var)
            else:
                # If variable assignment failed, we have a parse error
                # Skip to next comma or 'in' to try to recover
                while not self._check(TokenType.COMMA) and not self._check(TokenType.IN) and not self._is_at_end():
                    self._advance()

            # Skip trailing comments after assignment (these are not attached to any variable)
            self._skip_comments()
            # Handle comma between assignments (optional in M)
            self._match(TokenType.COMMA)

        if not self._consume(TokenType.IN, "Expected 'in' after variable assignments"):
            return None

        result = self._parse_expression()

        return LetExpression(variables=variables, result=result)

    def _parse_each_expression(self) -> Optional[EachExpression]:
        """Parse an each expression: each <body>."""
        self._consume(TokenType.EACH, "Expected 'each'")

        # Parse the body of the each expression - can be let, if, try, or expression (including ??)
        if self._check(TokenType.LET):
            body = self._parse_let_expression()
        elif self._check(TokenType.IF):
            body = self._parse_if_expression()
        elif self._check(TokenType.TRY):
            body = self._parse_try_expression()
        else:
            body = self._parse_coalesce()

        return EachExpression(body=body)

    def _parse_if_expression(self) -> Optional[IfExpression]:
        """Parse an if-then-else expression: if <condition> then <expr> else <expr>."""
        self._consume(TokenType.IF, "Expected 'if'")

        condition = self._parse_logical_or()

        if not self._consume(TokenType.THEN, "Expected 'then' after condition"):
            return None

        then_expr = self._parse_expression()

        if not self._consume(TokenType.ELSE, "Expected 'else'"):
            return None

        else_expr = self._parse_expression()

        return IfExpression(condition=condition, then_expr=then_expr, else_expr=else_expr)

    def _parse_try_expression(self) -> Optional[TryExpression]:
        """Parse a try-otherwise expression: try <expr> otherwise <fallback>."""
        self._consume(TokenType.TRY, "Expected 'try'")

        # Parse the expression to try
        expression = self._parse_logical_or()

        # Check for optional 'otherwise' clause
        otherwise_expr = None
        if self._check(TokenType.OTHERWISE):
            self._advance()
            otherwise_expr = self._parse_expression()

        return TryExpression(expression=expression, otherwise_expr=otherwise_expr)

    def _parse_comparison(self) -> Optional[ASTNode]:
        """Parse a comparison expression: left op right, or left is type."""
        left = self._parse_additive()

        # Check for comparison operators
        if self._check(TokenType.GT) or self._check(TokenType.LT) or \
           self._check(TokenType.GTE) or self._check(TokenType.LTE) or \
           self._check(TokenType.NEQ) or self._check(TokenType.EQUALS):
            op_token = self._advance()
            right = self._parse_additive()
            left = BinaryExpression(left=left, operator=op_token.value, right=right)

        # Check for 'is' type check (e.g., [Value] is null, [Amount] is number)
        if self._check(TokenType.IS):
            self._advance()
            # The type can be 'null', 'number', or an identifier
            if self._check(TokenType.NULL):
                self._advance()
                left = TypeCheckExpression(operand=left, type_name="null")
            elif self._check(TokenType.IDENTIFIER):
                type_token = self._advance()
                left = TypeCheckExpression(operand=left, type_name=type_token.value)
            else:
                self._add_error("Expected type name after 'is'")

        return left

    def _parse_additive(self) -> Optional[ASTNode]:
        """Parse additive expressions: +, -, & (left-associative)."""
        left = self._parse_multiplicative()

        while self._check(TokenType.PLUS) or self._check(TokenType.MINUS) or \
              self._check(TokenType.AMPERSAND):
            op_token = self._advance()
            right = self._parse_multiplicative()
            left = BinaryExpression(left=left, operator=op_token.value, right=right)

        return left

    def _parse_multiplicative(self) -> Optional[ASTNode]:
        """Parse multiplicative expressions: *, / (left-associative)."""
        left = self._parse_primary()

        while self._check(TokenType.STAR) or self._check(TokenType.SLASH):
            op_token = self._advance()
            right = self._parse_primary()
            left = BinaryExpression(left=left, operator=op_token.value, right=right)

        return left

    def _parse_variable_assignment(self) -> Optional[VariableAssignment]:
        """Parse a variable assignment: name = expression."""
        # Collect any preceding comments
        comment = None
        while self._check(TokenType.COMMENT):
            comment_token = self._advance()
            comment = comment_token.value  # Keep the last comment before the assignment

        if not self._check(TokenType.IDENTIFIER):
            self._add_error("Expected variable name")
            return None

        name_token = self._advance()
        name = name_token.value

        if not self._consume(TokenType.EQUALS, f"Expected '=' after '{name}'"):
            return None

        value = self._parse_expression()

        # Ensure we got a valid value expression
        if value is None:
            self._add_error(f"Expected expression after '=' in assignment to '{name}'")
            return None

        return VariableAssignment(name=name, value=value, comment=comment)

    def _parse_primary(self) -> Optional[ASTNode]:
        """Parse a primary expression (identifier, literal, function call, unary minus)."""
        # Handle unary minus: -expr
        if self._check(TokenType.MINUS):
            self._advance()
            operand = self._parse_primary()  # Recursive to allow --x
            return UnaryExpression(operator="-", operand=operand)

        # Handle unary plus: +expr (identity for numbers)
        if self._check(TokenType.PLUS):
            self._advance()
            operand = self._parse_primary()
            return UnaryExpression(operator="+", operand=operand)

        if self._check(TokenType.STRING):
            token = self._advance()
            return StringLiteral(value=token.value)

        if self._check(TokenType.NUMBER):
            token = self._advance()
            return NumberLiteral(value=token.value)

        if self._check(TokenType.IDENTIFIER):
            return self._parse_identifier_or_call()

        # Inclusive identifier reference: @name
        if self._check(TokenType.AT):
            self._advance()
            if not self._check(TokenType.IDENTIFIER):
                self._add_error("Expected identifier after '@'")
                return None
            token = self._advance()
            return self._parse_postfix_operations(InclusiveIdentifier(name=token.value))

        # Parenthesized expression or function expression
        if self._check(TokenType.LPAREN):
            return self._parse_parenthesized_or_function()

        if self._check(TokenType.LBRACE):
            return self._parse_list_literal()

        if self._check(TokenType.LBRACKET):
            return self._parse_bracket_expression()

        if self._check(TokenType.NULL):
            self._advance()
            return NullLiteral()

        if self._check(TokenType.TRUE):
            self._advance()
            return BooleanLiteral(value=True)

        if self._check(TokenType.FALSE):
            self._advance()
            return BooleanLiteral(value=False)

        if self._check(TokenType.TYPE):
            return self._parse_type_expression()

        if self._check(TokenType.ERROR_KW):
            return self._parse_error_expression()

        # Not implemented expression: ...
        if self._check(TokenType.ELLIPSIS):
            self._advance()
            return NotImplementedExpression()

        self._add_error(f"Unexpected token: {self._current().value}")
        return None

    def _parse_parenthesized_or_function(self) -> Optional[ASTNode]:
        """Parse parenthesized expression or function expression.

        (expr) or (params) => body or (params) as type => body
        """
        self._advance()  # consume '('

        # Empty parameter list: () => body or () as type => body
        if self._check(TokenType.RPAREN):
            self._advance()
            # Check for optional return type
            return_type = None
            if self._check(TokenType.AS):
                self._advance()
                if self._check(TokenType.IDENTIFIER):
                    return_type = self._advance().value
                else:
                    self._add_error("Expected type name after 'as'")
            if self._check(TokenType.ARROW):
                self._advance()
                body = self._parse_expression()
                if not body:
                    self._add_error("Expected function body after '=>'")
                    return None
                return FunctionExpression(parameters=[], body=body, return_type=return_type)
            # Empty parens with no arrow is an error
            self._add_error("Unexpected empty parentheses")
            return None

        # Check if this looks like a function parameter list
        # We need to look ahead to see if there's a ) followed by optional return type and =>
        start_pos = self.pos
        params = self._try_parse_function_parameters()

        # Check for optional return type: (params) as type => body
        return_type = None
        if params is not None and self._check(TokenType.AS):
            self._advance()
            if self._check(TokenType.IDENTIFIER):
                return_type = self._advance().value
            else:
                self._add_error("Expected type name after 'as'")

        if params is not None and self._check(TokenType.ARROW):
            # This is a function expression
            self._advance()  # consume '=>'
            body = self._parse_expression()
            if not body:
                self._add_error("Expected function body after '=>'")
                return None
            return FunctionExpression(parameters=params, body=body, return_type=return_type)

        # Not a function, restore position and parse as parenthesized expression
        self.pos = start_pos
        expr = self._parse_expression()
        self._consume(TokenType.RPAREN, "Expected ')' after expression")
        return expr

    def _try_parse_function_parameters(self) -> Optional[List[FunctionParameter]]:
        """Try to parse function parameters. Returns None if not valid parameters."""
        params: List[FunctionParameter] = []
        saved_errors = len(self.errors)

        while True:
            # Check for 'optional' keyword
            is_optional = False
            if self._check(TokenType.OPTIONAL):
                self._advance()
                is_optional = True

            if not self._check(TokenType.IDENTIFIER):
                # Restore errors and return None
                self.errors = self.errors[:saved_errors]
                return None

            name = self._advance().value

            # Check for type annotation: as Type
            type_annotation = None
            if self._check(TokenType.AS):
                self._advance()  # consume 'as'
                # Consume type expression
                # We expect at least one token for the type (identifier, type keyword, null, etc.)
                if self._check(TokenType.IDENTIFIER) or self._check(TokenType.NULL) or \
                   self._check(TokenType.TYPE):
                    token = self._advance()
                    type_annotation = token.value

                    # Handle 'nullable primitive' or 'type table'
                    # If we consumed 'nullable' or 'type', we might need another token
                    if (token.type == TokenType.IDENTIFIER and token.value == "nullable") or \
                       token.type == TokenType.TYPE:
                        if self._check(TokenType.IDENTIFIER) or self._check(TokenType.LBRACKET):
                            # type table [...] or nullable number
                            if self._check(TokenType.IDENTIFIER):
                                type_annotation += " " + self._advance().value
                            # Note: This is still a simplification. 'type table [...]' involves brackets.
                            # But for 198-typed-function-params, we only have simple types.

            params.append(FunctionParameter(name=name, optional=is_optional, type_annotation=type_annotation))

            if not self._check(TokenType.COMMA):
                break
            self._advance()  # consume comma

        if not self._check(TokenType.RPAREN):
            self.errors = self.errors[:saved_errors]
            return None
        self._advance()  # consume ')'

        return params

    def _parse_error_expression(self) -> Optional[ErrorExpression]:
        """Parse an error expression: error <expr>."""
        self._consume(TokenType.ERROR_KW, "Expected 'error'")
        expr = self._parse_expression()
        if not expr:
            self._add_error("Expected expression after 'error'")
            return None
        return ErrorExpression(expression=expr)

    def _parse_bracket_expression(self) -> Optional[ASTNode]:
        """Parse bracket expression - either field access [field] or record literal [field = value, ...]
        
        Field access: [FieldName]
        Record literal: [field1 = expr1, field2 = expr2, ...]
        Empty record: []
        """
        self._consume(TokenType.LBRACKET, "Expected '['")

        # Empty record: []
        if self._check(TokenType.RBRACKET):
            self._advance()
            return RecordLiteral(fields={})

        # Must have an identifier
        if not self._check(TokenType.IDENTIFIER):
            self._add_error("Expected field name after '['")
            return None

        first_field_token = self._advance()
        first_field_name = first_field_token.value

        # Check what follows the identifier:
        # - If '=' follows, this is a record literal: [field = value, ...]
        # - If ']' follows, this is a field access: [field]
        if self._check(TokenType.EQUALS):
            # Record literal
            self._advance()  # consume '='
            fields: dict = {}

            first_value = self._parse_expression()
            if first_value:
                fields[first_field_name] = first_value

            # Parse additional fields
            while self._match(TokenType.COMMA):
                if not self._check(TokenType.IDENTIFIER):
                    self._add_error("Expected field name in record literal")
                    break
                field_name = self._advance().value
                self._consume(TokenType.EQUALS, "Expected '=' after field name in record")
                field_value = self._parse_expression()
                if field_value:
                    fields[field_name] = field_value

            self._consume(TokenType.RBRACKET, "Expected ']' after record fields")
            return RecordLiteral(fields=fields)
        else:
            # Field access
            self._consume(TokenType.RBRACKET, "Expected ']' after field name")
            return FieldAccess(field_name=first_field_name)

    def _parse_type_expression(self) -> Optional[TypeExpression]:
        """Parse a type expression: type number, type text, type table [col = type, ...], etc."""
        self._consume(TokenType.TYPE, "Expected 'type'")

        # Type names can be identifiers OR certain keywords like 'null' and 'type'
        # M supports: any, binary, date, datetime, datetimezone, duration, function,
        # list, logical, none, null, number, record, table, text, time, type
        if self._check(TokenType.IDENTIFIER):
            type_name = self._advance().value
        elif self._check(TokenType.NULL):
            self._advance()
            type_name = "null"
        elif self._check(TokenType.TYPE):
            # type type - meta type
            self._advance()
            type_name = "type"
        else:
            self._add_error("Expected type name after 'type'")
            return None

        # Check for table type with column definitions: type table [col = type, ...]
        if type_name == "table" and self._check(TokenType.LBRACKET):
            self._advance()  # consume '['
            columns: dict[str, str] = {}

            if not self._check(TokenType.RBRACKET):
                # Parse first column definition
                if not self._check(TokenType.IDENTIFIER):
                    self._add_error("Expected column name in table type")
                    return None
                col_name = self._advance().value
                self._consume(TokenType.EQUALS, "Expected '=' after column name in table type")
                if not self._check(TokenType.IDENTIFIER):
                    self._add_error("Expected type name after '=' in table type")
                    return None
                col_type = self._advance().value
                columns[col_name] = col_type

                # Parse additional column definitions
                while self._match(TokenType.COMMA):
                    if not self._check(TokenType.IDENTIFIER):
                        self._add_error("Expected column name in table type")
                        break
                    col_name = self._advance().value
                    self._consume(TokenType.EQUALS, "Expected '=' after column name in table type")
                    if not self._check(TokenType.IDENTIFIER):
                        self._add_error("Expected type name after '=' in table type")
                        break
                    col_type = self._advance().value
                    columns[col_name] = col_type

            self._consume(TokenType.RBRACKET, "Expected ']' after table type columns")
            return TypeExpression(type_name=type_name, columns=columns)

        return TypeExpression(type_name=type_name)

    def _parse_list_literal(self) -> Optional[ListLiteral]:
        """Parse a list literal: {item1, item2, ...}."""
        self._consume(TokenType.LBRACE, "Expected '{'")

        items: List[ASTNode] = []

        if not self._check(TokenType.RBRACE):
            # Parse first item (may be a range expression)
            item = self._parse_list_item()
            if item:
                items.append(item)

            # Parse remaining items
            while self._match(TokenType.COMMA):
                item = self._parse_list_item()
                if item:
                    items.append(item)

        self._consume(TokenType.RBRACE, "Expected '}' after list items")
        return ListLiteral(items=items)

    def _parse_list_item(self) -> Optional[ASTNode]:
        """Parse a list item, which may be a range expression (start..end)."""
        expr = self._parse_expression()
        if not expr:
            return None

        # Check for range operator: expr..endExpr
        if self._match(TokenType.DOT_DOT):
            end_expr = self._parse_expression()
            if not end_expr:
                self._add_error("Expected expression after '..'")
                return expr
            return BinaryExpression(left=expr, operator="..", right=end_expr)

        return expr

    def _parse_identifier_or_call(self) -> Optional[ASTNode]:
        """Parse an identifier, member access, or function call."""
        token = self._advance()
        expr: ASTNode = Identifier(name=token.value)
        return self._parse_postfix_operations(expr)

    def _parse_postfix_operations(self, expr: ASTNode) -> ASTNode:
        """Parse postfix operations: member access, item access, list item access, and function calls."""
        while True:
            if self._match(TokenType.DOT):
                # Member access: expr.member
                if not self._check(TokenType.IDENTIFIER):
                    self._add_error("Expected identifier after '.'")
                    break
                member_token = self._advance()
                expr = MemberAccess(object=expr, member=member_token.value)
            elif self._check(TokenType.LBRACKET):
                # Item access: expr[field] or expr[field]?
                self._advance()  # consume '['
                if self._check(TokenType.IDENTIFIER) and not self._check_at(1, TokenType.EQUALS):
                    # Simple field access: expr[fieldName]
                    field_token = self._advance()
                    self._consume(TokenType.RBRACKET, "Expected ']' after field name")
                    optional = self._match(TokenType.QUESTION)
                    expr = ItemAccess(target=expr, index=StringLiteral(value=field_token.value), optional=optional)
                elif self._check(TokenType.RBRACKET):
                    # Empty brackets not valid for item access
                    self._add_error("Expected field name in item access")
                    self._advance()
                    break
                else:
                    # Expression index: expr[expression]
                    index_expr = self._parse_expression()
                    self._consume(TokenType.RBRACKET, "Expected ']' after index expression")
                    optional = self._match(TokenType.QUESTION)
                    if index_expr:
                        expr = ItemAccess(target=expr, index=index_expr, optional=optional)
            elif self._check(TokenType.LBRACE):
                # List item access: expr{index} or expr{index}?
                self._advance()  # consume '{'
                index_expr = self._parse_expression()
                self._consume(TokenType.RBRACE, "Expected '}' after list index")
                optional = self._match(TokenType.QUESTION)
                if index_expr:
                    expr = ItemAccess(target=expr, index=index_expr, optional=optional)
            elif self._match(TokenType.LPAREN):
                # Function call
                arguments = self._parse_arguments()
                expr = FunctionCall(function=expr, arguments=arguments)
            else:
                break

        return expr

    def _parse_arguments(self) -> List[ASTNode]:
        """Parse function call arguments."""
        arguments: List[ASTNode] = []

        if not self._check(TokenType.RPAREN):
            # Parse first argument
            arg = self._parse_expression()
            if arg:
                arguments.append(arg)

            # Parse remaining arguments
            while self._match(TokenType.COMMA):
                arg = self._parse_expression()
                if arg:
                    arguments.append(arg)

        self._consume(TokenType.RPAREN, "Expected ')' after arguments")
        return arguments
