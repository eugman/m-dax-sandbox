"""Lexer for Power Query M language.

This module tokenizes M code source text into a stream of tokens
for consumption by the parser.
"""

from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Optional

# Maximum length for comments to prevent DoS via maliciously large inputs
MAX_COMMENT_LENGTH = 1_000_000  # 1MB limit for comment text


class TokenType(Enum):
    """Token types for M language lexer."""

    # Keywords
    LET = auto()
    IN = auto()
    EACH = auto()
    NOT = auto()
    AND = auto()
    OR = auto()
    IS = auto()
    NULL = auto()
    TRUE = auto()
    FALSE = auto()
    IF = auto()
    THEN = auto()
    ELSE = auto()
    TYPE = auto()  # type keyword for type expressions
    TRY = auto()  # try keyword for error handling
    OTHERWISE = auto()  # otherwise keyword for error handling
    OPTIONAL = auto()  # optional keyword for function parameters
    ERROR_KW = auto()  # error keyword for error expressions (ERROR_KW to avoid conflict)
    SECTION = auto()  # section keyword for section documents
    SHARED = auto()  # shared keyword for shared declarations
    AS = auto()  # as keyword for type annotations
    META = auto()  # meta keyword for metadata

    # Identifiers and literals
    IDENTIFIER = auto()
    STRING = auto()
    NUMBER = auto()

    # Operators and punctuation
    EQUALS = auto()
    COMMA = auto()
    DOT = auto()
    DOT_DOT = auto()  # Range operator: 1..5
    LPAREN = auto()
    RPAREN = auto()
    LBRACE = auto()  # { for list literals
    RBRACE = auto()  # } for list literals
    LBRACKET = auto()  # [ for field access
    RBRACKET = auto()  # ] for field access

    # Comparison operators
    GT = auto()  # >
    LT = auto()  # <
    GTE = auto()  # >=
    LTE = auto()  # <=
    NEQ = auto()  # <>

    # Text operators
    AMPERSAND = auto()  # & for text concatenation

    # Arithmetic operators
    PLUS = auto()  # +
    MINUS = auto()  # -
    STAR = auto()  # *
    SLASH = auto()  # /

    # Null coalesce operator
    QUESTION_QUESTION = auto()  # ??

    # Optional access operator
    QUESTION = auto()  # ?

    # Inclusive identifier prefix
    AT = auto()  # @

    # Not implemented expression
    ELLIPSIS = auto()  # ...

    # Function arrow
    ARROW = auto()  # =>

    # Section document punctuation
    SEMICOLON = auto()  # ;
    BANG = auto()  # ! for qualified references

    # Comments
    COMMENT = auto()  # // or /* */

    # Special
    EOF = auto()
    ERROR = auto()


@dataclass
class Token:
    """Represents a single token from the lexer.

    Attributes:
        type: The type of token.
        value: The string value of the token.
        line: The line number where the token appears (1-indexed).
        column: The column number where the token starts (1-indexed).
    """

    type: TokenType
    value: str
    line: int
    column: int

    def __repr__(self) -> str:
        return f"Token({self.type.name}, {self.value!r}, {self.line}:{self.column})"


class Lexer:
    """Tokenizer for Power Query M language.

    Converts source text into a stream of tokens. Handles keywords,
    identifiers, string literals, and punctuation.

    Example:
        lexer = Lexer('let x = 1 in x')
        tokens = lexer.tokenize()
    """

    # Keywords mapping
    KEYWORDS = {
        "let": TokenType.LET,
        "in": TokenType.IN,
        "each": TokenType.EACH,
        "not": TokenType.NOT,
        "and": TokenType.AND,
        "or": TokenType.OR,
        "is": TokenType.IS,
        "null": TokenType.NULL,
        "true": TokenType.TRUE,
        "false": TokenType.FALSE,
        "if": TokenType.IF,
        "then": TokenType.THEN,
        "else": TokenType.ELSE,
        "type": TokenType.TYPE,
        "try": TokenType.TRY,
        "otherwise": TokenType.OTHERWISE,
        "error": TokenType.ERROR_KW,
        "optional": TokenType.OPTIONAL,
        "section": TokenType.SECTION,
        "shared": TokenType.SHARED,
        "as": TokenType.AS,
        "meta": TokenType.META,
    }

    def __init__(self, source: str):
        """Initialize the lexer with source code.

        Args:
            source: The M code source text to tokenize.
        """
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []

    def tokenize(self) -> List[Token]:
        """Tokenize the entire source and return a list of tokens.

        Returns:
            List of tokens, always ending with an EOF token.
        """
        self.tokens = []
        self.pos = 0
        self.line = 1
        self.column = 1

        while not self._is_at_end():
            self._scan_token()

        self.tokens.append(Token(TokenType.EOF, "", self.line, self.column))
        return self.tokens

    def _is_at_end(self) -> bool:
        """Check if we've reached the end of the source."""
        return self.pos >= len(self.source)

    def _peek(self) -> str:
        """Return the current character without consuming it."""
        if self._is_at_end():
            return "\0"
        return self.source[self.pos]

    def _peek_next(self) -> str:
        """Return the next character without consuming it."""
        if self.pos + 1 >= len(self.source):
            return "\0"
        return self.source[self.pos + 1]

    def _advance(self) -> str:
        """Consume and return the current character."""
        char = self.source[self.pos]
        self.pos += 1
        if char == "\n":
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return char

    def _scan_token(self) -> None:
        """Scan and add the next token."""
        self._skip_whitespace()

        if self._is_at_end():
            return

        start_line = self.line
        start_column = self.column
        char = self._advance()

        # Single-character tokens
        if char == "(":
            self.tokens.append(Token(TokenType.LPAREN, "(", start_line, start_column))
        elif char == ")":
            self.tokens.append(Token(TokenType.RPAREN, ")", start_line, start_column))
        elif char == "{":
            self.tokens.append(Token(TokenType.LBRACE, "{", start_line, start_column))
        elif char == "}":
            self.tokens.append(Token(TokenType.RBRACE, "}", start_line, start_column))
        elif char == "=":
            # Check for arrow =>
            if self._peek() == ">":
                self._advance()
                self.tokens.append(Token(TokenType.ARROW, "=>", start_line, start_column))
            else:
                self.tokens.append(Token(TokenType.EQUALS, "=", start_line, start_column))
        elif char == ",":
            self.tokens.append(Token(TokenType.COMMA, ",", start_line, start_column))
        elif char == ".":
            # Check for range operator (..) or ellipsis (...)
            if self._peek() == ".":
                self._advance()  # consume second .
                if self._peek() == ".":
                    self._advance()  # consume third . for ellipsis
                    self.tokens.append(Token(TokenType.ELLIPSIS, "...", start_line, start_column))
                else:
                    # Just two dots: range operator
                    self.tokens.append(Token(TokenType.DOT_DOT, "..", start_line, start_column))
            else:
                self.tokens.append(Token(TokenType.DOT, ".", start_line, start_column))
        elif char == "[":
            self.tokens.append(Token(TokenType.LBRACKET, "[", start_line, start_column))
        elif char == "]":
            self.tokens.append(Token(TokenType.RBRACKET, "]", start_line, start_column))
        elif char == "&":
            self.tokens.append(Token(TokenType.AMPERSAND, "&", start_line, start_column))
        elif char == ";":
            self.tokens.append(Token(TokenType.SEMICOLON, ";", start_line, start_column))
        elif char == "!":
            self.tokens.append(Token(TokenType.BANG, "!", start_line, start_column))
        elif char == "+":
            self.tokens.append(Token(TokenType.PLUS, "+", start_line, start_column))
        elif char == "-":
            self.tokens.append(Token(TokenType.MINUS, "-", start_line, start_column))
        elif char == "*":
            self.tokens.append(Token(TokenType.STAR, "*", start_line, start_column))
        elif char == "/":
            self.tokens.append(Token(TokenType.SLASH, "/", start_line, start_column))
        elif char == ">":
            if self._peek() == "=":
                self._advance()
                self.tokens.append(Token(TokenType.GTE, ">=", start_line, start_column))
            else:
                self.tokens.append(Token(TokenType.GT, ">", start_line, start_column))
        elif char == "<":
            if self._peek() == "=":
                self._advance()
                self.tokens.append(Token(TokenType.LTE, "<=", start_line, start_column))
            elif self._peek() == ">":
                self._advance()
                self.tokens.append(Token(TokenType.NEQ, "<>", start_line, start_column))
            else:
                self.tokens.append(Token(TokenType.LT, "<", start_line, start_column))
        elif char == "?":
            if self._peek() == "?":
                self._advance()
                self.tokens.append(Token(TokenType.QUESTION_QUESTION, "??", start_line, start_column))
            else:
                self.tokens.append(Token(TokenType.QUESTION, "?", start_line, start_column))
        elif char == "@":
            self.tokens.append(Token(TokenType.AT, "@", start_line, start_column))
        elif char == '"':
            self._scan_string(start_line, start_column)
        elif char == "#":
            if self._peek() == '"':
                # Quoted identifier: #"Name With Spaces"
                self._advance()  # consume the opening quote
                self._scan_quoted_identifier(start_line, start_column)
            elif self._is_alpha(self._peek()):
                # Intrinsic identifier: #date, #time, #datetime, etc.
                self._scan_intrinsic_identifier(start_line, start_column)
            else:
                self.tokens.append(Token(TokenType.ERROR, char, start_line, start_column))
        elif self._is_digit(char):
            self._scan_number(char, start_line, start_column)
        elif self._is_alpha(char):
            self._scan_identifier(char, start_line, start_column)
        else:
            # Unknown character - create an error token
            self.tokens.append(
                Token(TokenType.ERROR, char, start_line, start_column)
            )

    def _skip_whitespace(self) -> None:
        """Skip whitespace and capture comments as tokens."""
        while not self._is_at_end():
            char = self._peek()
            if char in " \t\r\n":
                self._advance()
            elif char == "/" and self._peek_next() == "/":
                # Line comment - capture as token
                start_line = self.line
                start_column = self.column
                self._advance()  # consume first /
                self._advance()  # consume second /
                comment_text = []
                while not self._is_at_end() and self._peek() != "\n":
                    comment_text.append(self._advance())
                self.tokens.append(
                    Token(TokenType.COMMENT, "".join(comment_text).strip(), start_line, start_column)
                )
            elif char == "/" and self._peek_next() == "*":
                # Block comment - capture as token
                start_line = self.line
                start_column = self.column
                self._advance()  # consume /
                self._advance()  # consume *
                comment_text = []
                terminated = False
                while not self._is_at_end():
                    if self._peek() == "*" and self._peek_next() == "/":
                        self._advance()  # consume *
                        self._advance()  # consume /
                        terminated = True
                        break
                    comment_text.append(self._advance())
                    # Prevent DoS via excessively large comments
                    if len(comment_text) > MAX_COMMENT_LENGTH:
                        self.tokens.append(
                            Token(TokenType.ERROR, "Block comment exceeds maximum length", start_line, start_column)
                        )
                        # Skip to end of comment or input
                        while not self._is_at_end():
                            if self._peek() == "*" and self._peek_next() == "/":
                                self._advance()
                                self._advance()
                                break
                            self._advance()
                        return
                if not terminated:
                    # Unterminated block comment - report error
                    self.tokens.append(
                        Token(TokenType.ERROR, "Unterminated block comment", start_line, start_column)
                    )
                else:
                    self.tokens.append(
                        Token(TokenType.COMMENT, "".join(comment_text).strip(), start_line, start_column)
                    )
            else:
                break

    def _scan_string(self, start_line: int, start_column: int) -> None:
        """Scan a string literal (opening quote already consumed)."""
        value = []
        while not self._is_at_end():
            char = self._peek()
            
            if char == '"':
                if self._peek_next() == '"':
                    # Escaped quote in M language
                    self._advance()  # consume first "
                    self._advance()  # consume second "
                    value.append('"')
                    continue
                else:
                    # Closing quote
                    break

            # Handle M escape sequences like #(lf), #(cr), #(tab)
            if char == "#" and self._peek_next() == "(":
                escape = self._scan_escape_sequence()
                if escape is not None:
                    value.append(escape)
                    continue
                # Not a valid escape, push the # literally (fall through)

            value.append(self._advance())

        if self._is_at_end():
            self.tokens.append(
                Token(TokenType.ERROR, "".join(value), start_line, start_column)
            )
            return

        self._advance()  # consume closing quote
        self.tokens.append(
            Token(TokenType.STRING, "".join(value), start_line, start_column)
        )

    def _scan_escape_sequence(self) -> Optional[str]:
        """Scan an M escape sequence like #(lf), #(cr), #(tab), or #(0000) for unicode.
        
        Returns the unescaped character or None if not a valid escape.
        """
        if self._peek() != "#" or self._peek_next() != "(":
            return None

        # Save position in case we need to backtrack
        start_pos = self.pos
        start_line = self.line
        start_column = self.column

        self._advance()  # consume #
        self._advance()  # consume (

        # Read the escape name
        name = []
        while not self._is_at_end() and self._peek() != ")" and self._peek() != "\n":
            name.append(self._advance())

        if self._peek() != ")":
            # Invalid escape, backtrack
            self.pos = start_pos
            self.line = start_line
            self.column = start_column
            return None

        self._advance()  # consume )

        escape_name = "".join(name).lower()
        if escape_name == "lf":
            return "\n"
        elif escape_name == "cr":
            return "\r"
        elif escape_name == "tab":
            return "\t"
        else:
            # Try to parse as hex unicode codepoint
            import re
            if re.match(r'^[0-9a-f]+$', escape_name, re.IGNORECASE):
                try:
                    codepoint = int(escape_name, 16)
                    if 0 <= codepoint <= 0x10ffff:
                        return chr(codepoint)
                except ValueError:
                    pass
            # Unknown escape, backtrack
            self.pos = start_pos
            self.line = start_line
            self.column = start_column
            return None

    def _scan_identifier(
        self, first_char: str, start_line: int, start_column: int
    ) -> None:
        """Scan an identifier or keyword."""
        value = [first_char]
        while not self._is_at_end() and self._is_alphanumeric(self._peek()):
            value.append(self._advance())

        text = "".join(value)
        token_type = self.KEYWORDS.get(text, TokenType.IDENTIFIER)
        self.tokens.append(Token(token_type, text, start_line, start_column))

    def _scan_number(
        self, first_char: str, start_line: int, start_column: int
    ) -> None:
        """Scan a numeric literal."""
        value = [first_char]
        while not self._is_at_end() and self._is_digit(self._peek()):
            value.append(self._advance())

        # Handle decimal part
        if self._peek() == "." and self._is_digit(self._peek_next()):
            value.append(self._advance())  # consume '.'
            while not self._is_at_end() and self._is_digit(self._peek()):
                value.append(self._advance())

        self.tokens.append(
            Token(TokenType.NUMBER, "".join(value), start_line, start_column)
        )

    def _is_digit(self, char: str) -> bool:
        """Check if character is a digit."""
        return char.isdigit()

    def _is_alpha(self, char: str) -> bool:
        """Check if character is a letter or underscore."""
        return char.isalpha() or char == "_"

    def _is_alphanumeric(self, char: str) -> bool:
        """Check if character is a letter, digit, or underscore."""
        return char.isalnum() or char == "_"

    def _scan_intrinsic_identifier(self, start_line: int, start_column: int) -> None:
        """Scan an intrinsic identifier (#date, #time, #datetime, etc.).

        The # has already been consumed. Scans the remaining identifier.
        """
        value = ["#"]
        while not self._is_at_end() and self._is_alphanumeric(self._peek()):
            value.append(self._advance())

        text = "".join(value)
        # Return as an identifier (builtins will handle #date, etc.)
        self.tokens.append(Token(TokenType.IDENTIFIER, text, start_line, start_column))

    def _scan_quoted_identifier(self, start_line: int, start_column: int) -> None:
        """Scan a quoted identifier (opening #" already consumed).

        M uses #"..." for identifiers with spaces or special characters.
        The content between quotes becomes the identifier name.
        """
        value = []
        while not self._is_at_end() and self._peek() != '"':
            if self._peek() == "\n":
                # Unterminated quoted identifier
                break
            # Handle escaped quotes (doubled quotes)
            if self._peek() == '"' and self._peek_next() == '"':
                self._advance()
                self._advance()
                value.append('"')
            elif self._peek() == "#" and self._peek_next() == "(":
                # Handle M escape sequences like #(lf), #(cr), #(tab)
                escape = self._scan_escape_sequence()
                if escape is not None:
                    value.append(escape)
                else:
                    # Not a valid escape, push the # literally
                    value.append(self._advance())
            else:
                value.append(self._advance())

        if self._is_at_end() or self._peek() != '"':
            self.tokens.append(
                Token(TokenType.ERROR, "".join(value), start_line, start_column)
            )
            return

        self._advance()  # consume closing quote
        self.tokens.append(
            Token(TokenType.IDENTIFIER, "".join(value), start_line, start_column)
        )
