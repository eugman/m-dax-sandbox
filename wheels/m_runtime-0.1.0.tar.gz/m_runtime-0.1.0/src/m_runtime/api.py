"""Public API for m-runtime.

This module provides the run_m() function, the main entry point for
executing M code in Fabric notebooks.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Union

import pandas as pd

from python_m.parser import parse
from python_m.runtime.environment import GlobalEnvironment
from python_m.runtime.builtins import register_builtins
from python_m.runtime.values import MValue

from m_runtime.backends import get_backend, detect_backend
from m_runtime.discovery import discover_dataframes, detect_backend_type, validate_tables
from m_runtime.fabric_evaluator import FabricEvaluator, MRuntimeTableShim, wrap_table
from m_runtime.table import MRuntimeTable


def run_m(
    code: str,
    tables: Optional[Dict[str, Any]] = None,
    *,
    namespace: Optional[Dict[str, Any]] = None,
    backend: Optional[str] = None,
    return_pandas: bool = True,
    spark_session: Optional[Any] = None,
) -> Union[pd.DataFrame, Any, MValue]:
    """Execute M code with DataFrames as inputs.

    This is the main entry point for running M code in Fabric notebooks.
    It automatically discovers DataFrames in the namespace and makes them
    available as M table variables.

    Args:
        code: M code to execute
        tables: Optional dict of name -> DataFrame to use as M variables.
                These are merged with any discovered DataFrames.
        namespace: Optional namespace to scan for DataFrames (e.g., globals()).
                   Variables that are pandas or Spark DataFrames will be
                   available as M table variables.
        backend: Optional backend name ('pandas' or 'spark'). If not provided,
                 auto-detected from the DataFrame types.
        return_pandas: If True (default), convert table results to pandas.
                       If False, return MValue or native backend type.
        spark_session: Optional SparkSession for Spark backend.

    Returns:
        - If result is a table and return_pandas=True: pandas DataFrame
        - If result is a table and return_pandas=False: native DataFrame
        - Otherwise: MValue (MNumber, MText, MList, etc.)

    Raises:
        ValueError: If tables have mixed types (pandas and Spark)
        TypeError: If a DataFrame type is not recognized

    Example:
        >>> Sales = pd.DataFrame({"Amount": [100, 200, 300]})
        >>> result = run_m('''
        ...     let
        ...         Filtered = Table.SelectRows(Sales, each [Amount] > 150)
        ...     in
        ...         Filtered
        ... ''', namespace=globals())
        >>> print(result)
           Amount
        0     200
        1     300
    """
    # Merge explicit tables with discovered tables from namespace
    all_tables: Dict[str, Any] = {}

    if namespace is not None:
        discovered = discover_dataframes(namespace)
        all_tables.update(discovered)

    if tables is not None:
        all_tables.update(tables)

    # Detect or validate backend type
    if all_tables:
        detected = detect_backend_type(all_tables)

        if backend is None:
            if detected == "mixed":
                raise ValueError(
                    "Cannot auto-detect backend with mixed DataFrame types. "
                    "Found both pandas and Spark DataFrames. "
                    "Either convert all tables to the same type, or specify "
                    "backend='pandas' or backend='spark' explicitly."
                )
            backend = detected
        else:
            # Validate that all tables match the specified backend
            validate_tables(all_tables, backend)
    else:
        # No tables provided, default to pandas
        backend = backend or "pandas"

    # Create backend instance
    backend_kwargs = {}
    if backend == "spark" and spark_session is not None:
        backend_kwargs["spark_session"] = spark_session

    backend_instance = get_backend(backend, **backend_kwargs)

    # Create evaluator with backend
    global_env = GlobalEnvironment()
    register_builtins(global_env)
    evaluator = FabricEvaluator(env=global_env, backend=backend_instance)

    # Register tables as M variables
    for name, df in all_tables.items():
        # Create MRuntimeTable and wrap in shim
        runtime_table = MRuntimeTable.from_dataframe(
            df, backend_name=backend, spark_session=spark_session
        )
        shim = wrap_table(runtime_table)
        global_env.bind(name, shim)

    # Parse and evaluate M code
    ast = parse(code)
    result = evaluator.evaluate(ast)

    # Convert result
    if isinstance(result, MRuntimeTableShim):
        if return_pandas:
            return result.to_pandas()
        else:
            return result.collect()
    elif hasattr(result, "to_pandas") and return_pandas:
        # MTable from python-m
        return result.to_pandas()
    else:
        return result


def register_table(
    name: str,
    df: Any,
    env: GlobalEnvironment,
    backend_name: Optional[str] = None,
    spark_session: Optional[Any] = None,
) -> MRuntimeTableShim:
    """Register a DataFrame as an M table variable.

    This is a lower-level function for manually registering tables
    in an environment.

    Args:
        name: Variable name for the table
        df: pandas or Spark DataFrame
        env: Environment to register in
        backend_name: Optional backend name
        spark_session: Optional SparkSession for Spark

    Returns:
        The MRuntimeTableShim that was registered
    """
    if backend_name is None:
        backend_name = detect_backend(df)

    runtime_table = MRuntimeTable.from_dataframe(
        df, backend_name=backend_name, spark_session=spark_session
    )
    shim = wrap_table(runtime_table)
    env.bind(name, shim)
    return shim
