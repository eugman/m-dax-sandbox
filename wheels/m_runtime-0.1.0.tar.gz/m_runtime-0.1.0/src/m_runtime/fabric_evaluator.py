"""FabricEvaluator - M language evaluator for Fabric notebooks.

This module extends python-m's Evaluator to work with MRuntimeTable
and its backend-agnostic table operations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from python_m.ast.nodes import ASTNode, EachExpression
from python_m.runtime.evaluator import Evaluator
from python_m.runtime.environment import Environment, GlobalEnvironment
from python_m.runtime.builtins import register_builtins
from python_m.runtime.values import (
    MValue,
    MNull,
    MText,
    MNumber,
    MLogical,
    MRecord,
    MFunction,
    MTable,
    python_to_mvalue,
)

from m_runtime.table import MRuntimeTable
from m_runtime.backends import TableBackend


@dataclass
class MRuntimeTableShim(MValue):
    """Shim that makes MRuntimeTable compatible with python-m's type system.

    This class wraps an MRuntimeTable and implements the MValue interface,
    allowing it to be used seamlessly with the python-m evaluator.

    The shim provides:
    1. MValue interface (type_name, to_python)
    2. Table operations that delegate to MRuntimeTable
    3. Row access that returns MRecord values

    Attributes:
        _table: The underlying MRuntimeTable
    """

    _table: MRuntimeTable
    _column_names_cache: Optional[List[str]] = field(default=None, repr=False)

    @property
    def type_name(self) -> str:
        return "table"

    @property
    def table(self) -> MRuntimeTable:
        """Get the underlying MRuntimeTable."""
        return self._table

    @property
    def column_names(self) -> List[str]:
        """Get column names."""
        if self._column_names_cache is None:
            self._column_names_cache = self._table.column_names
        return list(self._column_names_cache)

    def to_python(self) -> Any:
        """Convert to pandas DataFrame."""
        return self._table.to_pandas()

    def to_pandas(self) -> Any:
        """Convert to pandas DataFrame."""
        return self._table.to_pandas()

    def collect(self) -> Any:
        """Materialize and return native DataFrame."""
        return self._table.collect()

    def __len__(self) -> int:
        """Get row count."""
        return len(self._table)

    def __repr__(self) -> str:
        cols = self.column_names
        return f"Table({len(cols)} columns: {cols})"

    # Table operations (return new MRuntimeTableShim)

    def select_columns(self, columns: List[str]) -> MRuntimeTableShim:
        """Select specific columns."""
        new_table = self._table.select_columns(columns)
        return MRuntimeTableShim(new_table)

    def remove_columns(self, columns: List[str]) -> MRuntimeTableShim:
        """Remove specific columns."""
        new_table = self._table.remove_columns(columns)
        return MRuntimeTableShim(new_table)

    def rename_columns(self, mapping: Dict[str, str]) -> MRuntimeTableShim:
        """Rename columns."""
        new_table = self._table.rename_columns(mapping)
        return MRuntimeTableShim(new_table)

    def sort(
        self, columns: List[str], descending: Any = False
    ) -> MRuntimeTableShim:
        """Sort by columns."""
        new_table = self._table.sort(columns, descending)
        return MRuntimeTableShim(new_table)

    def head(self, n: int) -> MRuntimeTableShim:
        """Take first n rows."""
        new_table = self._table.head(n)
        return MRuntimeTableShim(new_table)

    def tail(self, n: int) -> MRuntimeTableShim:
        """Take last n rows."""
        new_table = self._table.tail(n)
        return MRuntimeTableShim(new_table)

    def skip(self, n: int) -> MRuntimeTableShim:
        """Skip first n rows."""
        new_table = self._table.skip(n)
        return MRuntimeTableShim(new_table)

    def distinct(self) -> MRuntimeTableShim:
        """Remove duplicate rows."""
        new_table = self._table.distinct()
        return MRuntimeTableShim(new_table)

    def fill_down(self, columns: List[str]) -> MRuntimeTableShim:
        """Fill nulls with previous non-null values."""
        new_table = self._table.fill_down(columns)
        return MRuntimeTableShim(new_table)

    def promote_headers(self) -> MRuntimeTableShim:
        """Use first row as column headers."""
        new_table = self._table.promote_headers()
        return MRuntimeTableShim(new_table)

    # Row access

    def row(self, index: int) -> MRecord:
        """Get a single row as MRecord."""
        row_dict = self._table.row(index)
        if row_dict is None:
            return MRecord({})
        return MRecord({k: python_to_mvalue(v) for k, v in row_dict.items()})


class FabricEvaluator(Evaluator):
    """Evaluator that works with MRuntimeTable and its backends.

    This evaluator extends python-m's Evaluator to handle:
    1. MRuntimeTableShim as a table type
    2. Row operations via backend's filter_rows and add_column
    3. Automatic wrapping of MRuntimeTable results

    The key difference from the base Evaluator is that row operations
    (Table.AddColumn, Table.SelectRows) create closures that capture
    the M expression and pass it to the backend for per-row evaluation.
    """

    def __init__(
        self,
        env: Optional[Environment] = None,
        backend: Optional[TableBackend] = None,
    ) -> None:
        """Create a FabricEvaluator.

        Args:
            env: Optional initial environment
            backend: Optional backend for creating new tables
        """
        super().__init__(env)
        self._backend = backend

    def with_environment(self, env: Environment) -> FabricEvaluator:
        """Create a new evaluator with a different environment."""
        new_eval = FabricEvaluator.__new__(FabricEvaluator)
        new_eval.env = env
        new_eval.global_env = self.global_env
        new_eval._backend = self._backend
        return new_eval

    def _eval_table_add_column(self, arg_nodes: List[ASTNode]) -> MValue:
        """Evaluate Table.AddColumn with MRuntimeTable support.

        Table.AddColumn(table, newColumnName, columnGenerator)
        """
        if len(arg_nodes) < 3:
            raise TypeError("Table.AddColumn requires at least 3 arguments")

        # Evaluate table and column name
        table = self.evaluate(arg_nodes[0])
        column_name = self.evaluate(arg_nodes[1])

        # Handle both MRuntimeTableShim and regular MTable
        if isinstance(table, MRuntimeTableShim):
            return self._add_column_runtime(table, column_name, arg_nodes[2])
        elif isinstance(table, MTable):
            # Fall back to parent implementation for MTable
            return super()._eval_table_add_column(arg_nodes)
        else:
            raise TypeError(f"Table.AddColumn expects table, got {table.type_name}")

    def _add_column_runtime(
        self, table: MRuntimeTableShim, column_name: MValue, generator_node: ASTNode
    ) -> MRuntimeTableShim:
        """Add column using MRuntimeTable backend."""
        if not isinstance(column_name, MText):
            raise TypeError(
                f"Table.AddColumn expects text column name, got {column_name.type_name}"
            )

        # Create a closure that evaluates the generator for each row
        def generator_fn(row_dict: Dict[str, Any]) -> Any:
            row_record = MRecord({k: python_to_mvalue(v) for k, v in row_dict.items()})

            if isinstance(generator_node, EachExpression):
                func_env = self.env.extend("each-body")
                func_env.bind("_", row_record)
                for field_name in row_record.fields:
                    func_env.bind(field_name, row_record.get(field_name))
                row_eval = self.with_environment(func_env)
                if generator_node.body is not None:
                    result = row_eval.evaluate(generator_node.body)
                else:
                    result = MNull()
            else:
                # Evaluate as a function
                func = self.evaluate(generator_node)
                if isinstance(func, MFunction) and callable(func.body):
                    result = func.body(row_record)
                else:
                    result = MNull()

            return result.to_python() if hasattr(result, "to_python") else result

        # Use the backend to add the column
        new_table = table.table.add_column(column_name.value, generator_fn)
        return MRuntimeTableShim(new_table)

    def _eval_table_select_rows(self, arg_nodes: List[ASTNode]) -> MValue:
        """Evaluate Table.SelectRows with MRuntimeTable support.

        Table.SelectRows(table, condition)
        """
        if len(arg_nodes) < 2:
            raise TypeError("Table.SelectRows requires 2 arguments")

        # Evaluate table
        table = self.evaluate(arg_nodes[0])

        # Handle both MRuntimeTableShim and regular MTable
        if isinstance(table, MRuntimeTableShim):
            return self._select_rows_runtime(table, arg_nodes[1])
        elif isinstance(table, MTable):
            # Fall back to parent implementation for MTable
            return super()._eval_table_select_rows(arg_nodes)
        else:
            raise TypeError(f"Table.SelectRows expects table, got {table.type_name}")

    def _select_rows_runtime(
        self, table: MRuntimeTableShim, condition_node: ASTNode
    ) -> MRuntimeTableShim:
        """Filter rows using MRuntimeTable backend."""
        # Create a closure that evaluates the condition for each row
        def predicate_fn(row_dict: Dict[str, Any]) -> bool:
            row_record = MRecord({k: python_to_mvalue(v) for k, v in row_dict.items()})

            if isinstance(condition_node, EachExpression):
                func_env = self.env.extend("each-body")
                func_env.bind("_", row_record)
                for field_name in row_record.fields:
                    func_env.bind(field_name, row_record.get(field_name))
                row_eval = self.with_environment(func_env)
                if condition_node.body is not None:
                    result = row_eval.evaluate(condition_node.body)
                else:
                    result = MLogical(True)
            else:
                # Evaluate as a function
                func = self.evaluate(condition_node)
                if isinstance(func, MFunction) and callable(func.body):
                    result = func.body(row_record)
                else:
                    result = MLogical(True)

            # Check if result is truthy
            if isinstance(result, MLogical):
                return result.value
            elif isinstance(result, MNumber):
                return result.value != 0
            return False

        # Use the backend to filter rows
        new_table = table.table.filter_rows(predicate_fn)
        return MRuntimeTableShim(new_table)


def wrap_table(table: MRuntimeTable) -> MRuntimeTableShim:
    """Wrap an MRuntimeTable in a shim for use with the evaluator.

    Args:
        table: MRuntimeTable to wrap

    Returns:
        MRuntimeTableShim compatible with python-m evaluator
    """
    return MRuntimeTableShim(table)
