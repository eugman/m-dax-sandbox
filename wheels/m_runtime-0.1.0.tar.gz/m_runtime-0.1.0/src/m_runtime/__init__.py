"""M language runtime for Microsoft Fabric notebooks.

This package enables running M (Power Query) code directly in Fabric notebooks
with Pandas and PySpark DataFrames as inputs/outputs.

Example usage:
    from m_runtime import run_m

    # With namespace auto-discovery
    Sales = spark.read.table("lakehouse.Sales").toPandas()
    result = run_m('''
        let
            Filtered = Table.SelectRows(Sales, each [Amount] > 100),
            WithBonus = Table.AddColumn(Filtered, "Bonus", each [Amount] * 0.1)
        in
            WithBonus
    ''', namespace=globals())

    # With explicit tables
    result = run_m(code, tables={"Sales": my_df, "Products": other_df})
"""

from m_runtime.api import run_m
from m_runtime.table import MRuntimeTable

__all__ = ["run_m", "MRuntimeTable"]
__version__ = "0.1.0"
