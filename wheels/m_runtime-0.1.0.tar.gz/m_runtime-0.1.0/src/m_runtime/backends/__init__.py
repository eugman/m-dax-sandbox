"""Backend registry for m-runtime.

Backends provide table operations for different DataFrame implementations.
Currently supported:
- pandas: Pure pandas DataFrame operations
- spark: PySpark DataFrame with collect-to-driver for row operations
"""

from typing import Dict, Type, Any, Optional

from m_runtime.backends.base import TableBackend, BackendTable

# Registry of available backends
_backends: Dict[str, Type[TableBackend]] = {}


def register_backend(name: str, backend_class: Type[TableBackend]) -> None:
    """Register a backend implementation."""
    _backends[name] = backend_class


def get_backend(name: str, **kwargs: Any) -> TableBackend:
    """Get a backend instance by name.

    Args:
        name: Backend name ('pandas' or 'spark')
        **kwargs: Additional arguments passed to backend constructor
                  (e.g., spark_session for SparkBackend)

    Returns:
        Backend instance

    Raises:
        ValueError: If backend name is not registered
    """
    if name not in _backends:
        raise ValueError(f"Unknown backend: {name}. Available: {list(_backends.keys())}")
    return _backends[name](**kwargs)


def detect_backend(df: Any) -> str:
    """Detect the appropriate backend for a DataFrame.

    Args:
        df: A DataFrame object (pandas or Spark)

    Returns:
        Backend name ('pandas' or 'spark')

    Raises:
        TypeError: If DataFrame type is not recognized
    """
    import pandas as pd

    if isinstance(df, pd.DataFrame):
        return "pandas"

    # Check for Spark DataFrame by duck typing
    if hasattr(df, 'toPandas') and hasattr(df, 'select') and hasattr(df, 'schema'):
        return "spark"

    raise TypeError(
        f"Cannot detect backend for type {type(df).__name__}. "
        "Expected pandas.DataFrame or pyspark.sql.DataFrame."
    )


# Register backends on import
def _register_builtin_backends() -> None:
    """Register the built-in backends."""
    from m_runtime.backends.pandas_backend import PandasBackend
    register_backend("pandas", PandasBackend)

    # Spark backend is optional
    try:
        from m_runtime.backends.spark_backend import SparkBackend
        register_backend("spark", SparkBackend)
    except ImportError:
        pass  # PySpark not installed


_register_builtin_backends()

__all__ = [
    "TableBackend",
    "BackendTable",
    "register_backend",
    "get_backend",
    "detect_backend",
]
