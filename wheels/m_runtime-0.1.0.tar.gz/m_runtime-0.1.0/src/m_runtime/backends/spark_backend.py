"""PySpark backend for m-runtime.

This backend uses PySpark DataFrames for operations.
Row-level operations (filter_rows, add_column) use collect-to-driver
for simplicity; see FUTURE comments for UDF-based approach.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Iterator, List, Optional, Union

import pandas as pd

from m_runtime.backends.base import BackendTable, TableBackend


class SparkBackend(TableBackend):
    """Table backend using PySpark DataFrames.

    This backend leverages Spark for scalable data processing.
    Native Spark operations are used where possible (select, sort, limit, etc.).

    Row-level operations (filter_rows, add_column) currently collect data
    to the driver for processing. This works well for moderate data sizes
    but may not scale to very large datasets.

    FUTURE: UDF-based distributed execution
        Instead of collect-to-driver, we could:
        1. Serialize the M expression/predicate
        2. Create a PySpark UDF with a mini-evaluator
        3. Apply distributed: df.filter(m_filter_udf(...))
        This would enable large-scale M processing in Spark.
    """

    def __init__(self, spark_session: Optional[Any] = None) -> None:
        """Create a SparkBackend.

        Args:
            spark_session: Optional SparkSession. If not provided,
                          will attempt to get the active session.
        """
        self._spark = spark_session

    @property
    def spark(self) -> Any:
        """Get the SparkSession, creating one if needed."""
        if self._spark is None:
            try:
                from pyspark.sql import SparkSession
                self._spark = SparkSession.builder.getOrCreate()
            except ImportError:
                raise ImportError(
                    "PySpark is required for SparkBackend. "
                    "Install with: pip install pyspark"
                )
        return self._spark

    @property
    def backend_name(self) -> str:
        return "spark"

    def from_dataframe(self, df: Any) -> BackendTable:
        """Create a BackendTable from a Spark DataFrame."""
        # Duck-type check for Spark DataFrame
        if not (hasattr(df, 'toPandas') and hasattr(df, 'select') and hasattr(df, 'schema')):
            raise TypeError(
                f"Expected pyspark.sql.DataFrame, got {type(df).__name__}"
            )
        return BackendTable(self, df)

    def column_names(self, table: BackendTable) -> List[str]:
        """Get column names."""
        return table.native.columns

    def select_columns(self, table: BackendTable, columns: List[str]) -> BackendTable:
        """Select specific columns (native Spark)."""
        new_df = table.native.select(*columns)
        return BackendTable(self, new_df)

    def remove_columns(self, table: BackendTable, columns: List[str]) -> BackendTable:
        """Remove specific columns (native Spark)."""
        new_df = table.native.drop(*columns)
        return BackendTable(self, new_df)

    def rename_columns(self, table: BackendTable, mapping: Dict[str, str]) -> BackendTable:
        """Rename columns (native Spark)."""
        df = table.native
        for old_name, new_name in mapping.items():
            df = df.withColumnRenamed(old_name, new_name)
        return BackendTable(self, df)

    def filter_rows(
        self, table: BackendTable, predicate_fn: Callable[[Dict[str, Any]], bool]
    ) -> BackendTable:
        """Filter rows using a predicate function.

        CURRENT IMPLEMENTATION: Collect-to-driver
            Collects all data to driver, applies predicate, creates new DataFrame.
            Simple but doesn't scale to very large datasets.

        FUTURE: UDF-based distributed execution
            - Serialize M expression
            - Create PySpark UDF with mini-evaluator
            - Apply distributed: df.filter(m_filter_udf(...))

        Args:
            table: Source table
            predicate_fn: Function that takes row dict, returns bool

        Returns:
            New table with only rows where predicate returned True
        """
        # Collect to driver, apply predicate, recreate DataFrame
        pdf = table.native.toPandas()
        records = pdf.to_dict("records")
        mask = [predicate_fn(row) for row in records]

        filtered_pdf = pdf[mask].reset_index(drop=True)
        new_df = self.spark.createDataFrame(filtered_pdf)
        return BackendTable(self, new_df)

    def add_column(
        self, table: BackendTable, name: str, generator_fn: Callable[[Dict[str, Any]], Any]
    ) -> BackendTable:
        """Add a computed column.

        CURRENT IMPLEMENTATION: Collect-to-driver
            Collects all data to driver, computes values, creates new DataFrame.
            Simple but doesn't scale to very large datasets.

        FUTURE: UDF-based distributed execution
            - Serialize M expression
            - Create PySpark UDF with mini-evaluator
            - Apply distributed: df.withColumn(name, m_column_udf(...))

        Args:
            table: Source table
            name: Name for the new column
            generator_fn: Function that takes row dict, returns column value

        Returns:
            New table with the additional column
        """
        # Collect to driver, compute values, recreate DataFrame
        pdf = table.native.toPandas()
        records = pdf.to_dict("records")
        new_values = [generator_fn(row) for row in records]

        pdf[name] = new_values
        new_df = self.spark.createDataFrame(pdf)
        return BackendTable(self, new_df)

    def sort(
        self,
        table: BackendTable,
        columns: List[str],
        descending: Union[bool, List[bool]] = False,
    ) -> BackendTable:
        """Sort by columns (native Spark)."""
        from pyspark.sql.functions import col, asc, desc

        if isinstance(descending, bool):
            descending = [descending] * len(columns)

        order_cols = [
            desc(col(c)) if d else asc(col(c))
            for c, d in zip(columns, descending)
        ]

        new_df = table.native.orderBy(*order_cols)
        return BackendTable(self, new_df)

    def head(self, table: BackendTable, n: int) -> BackendTable:
        """Take first n rows (native Spark)."""
        new_df = table.native.limit(n)
        return BackendTable(self, new_df)

    def tail(self, table: BackendTable, n: int) -> BackendTable:
        """Take last n rows.

        Note: Spark doesn't have native tail. We use monotonically_increasing_id
        to simulate it, which may be slow for very large DataFrames.
        """
        from pyspark.sql.functions import monotonically_increasing_id, desc

        df = table.native

        # Add row ID, sort descending, take n, sort ascending, drop ID
        df_with_id = df.withColumn("__row_id__", monotonically_increasing_id())
        tail_df = df_with_id.orderBy(desc("__row_id__")).limit(n)
        result = tail_df.orderBy("__row_id__").drop("__row_id__")

        return BackendTable(self, result)

    def skip(self, table: BackendTable, n: int) -> BackendTable:
        """Skip first n rows.

        Note: Spark doesn't have native skip/offset. We use monotonically_increasing_id
        to simulate it, which requires a collect to get row numbers.
        """
        from pyspark.sql.functions import monotonically_increasing_id

        df = table.native

        # Add row ID, filter, drop ID
        df_with_id = df.withColumn("__row_id__", monotonically_increasing_id())

        # Get the nth row ID
        row_ids = df_with_id.select("__row_id__").limit(n + 1).collect()
        if len(row_ids) <= n:
            # Skip all rows
            return BackendTable(self, self.spark.createDataFrame([], df.schema))

        threshold = row_ids[-1]["__row_id__"]
        result = df_with_id.filter(df_with_id["__row_id__"] > threshold).drop("__row_id__")

        return BackendTable(self, result)

    def distinct(self, table: BackendTable) -> BackendTable:
        """Remove duplicate rows (native Spark)."""
        new_df = table.native.distinct()
        return BackendTable(self, new_df)

    def fill_down(self, table: BackendTable, columns: List[str]) -> BackendTable:
        """Fill nulls with previous non-null values.

        Note: Spark doesn't have native forward fill. We implement it
        via a window function approach.
        """
        from pyspark.sql import Window
        from pyspark.sql.functions import col, last, monotonically_increasing_id

        df = table.native

        # Add row ID for ordering
        df_with_id = df.withColumn("__row_id__", monotonically_increasing_id())

        # Define window for forward fill (all rows up to current)
        window = Window.orderBy("__row_id__").rowsBetween(
            Window.unboundedPreceding, Window.currentRow
        )

        # Apply forward fill to specified columns
        result = df_with_id
        for column in columns:
            if column in df.columns:
                result = result.withColumn(
                    column,
                    last(col(column), ignorenulls=True).over(window)
                )

        result = result.drop("__row_id__")
        return BackendTable(self, result)

    def row_count(self, table: BackendTable) -> int:
        """Get number of rows."""
        return table.native.count()

    def iter_rows(self, table: BackendTable) -> Iterator[Dict[str, Any]]:
        """Iterate over rows as dicts.

        Note: This collects the entire DataFrame to the driver.
        """
        pdf = table.native.toPandas()
        for _, row in pdf.iterrows():
            yield row.to_dict()

    def to_pandas(self, table: BackendTable) -> pd.DataFrame:
        """Convert to pandas DataFrame."""
        return table.native.toPandas()

    def collect(self, table: BackendTable) -> Any:
        """Return the Spark DataFrame (triggers computation if lazy)."""
        # For Spark, we return the DataFrame itself
        # Actual collection happens when toPandas() or collect() is called
        return table.native
