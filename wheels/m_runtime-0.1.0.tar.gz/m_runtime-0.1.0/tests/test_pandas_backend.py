"""Tests for PandasBackend."""

import pandas as pd
import pytest

from m_runtime.backends.pandas_backend import PandasBackend


@pytest.fixture
def backend() -> PandasBackend:
    """Create a PandasBackend instance."""
    return PandasBackend()


@pytest.fixture
def sample_df() -> pd.DataFrame:
    """Create a sample DataFrame for testing."""
    return pd.DataFrame({
        "Name": ["Alice", "Bob", "Charlie"],
        "Amount": [100, 200, 300],
        "Category": ["A", "B", "A"],
    })


class TestPandasBackendBasics:
    """Test basic PandasBackend operations."""

    def test_backend_name(self, backend: PandasBackend) -> None:
        assert backend.backend_name == "pandas"

    def test_from_dataframe(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        assert bt.backend is backend
        assert isinstance(bt.native, pd.DataFrame)

    def test_from_dataframe_copies(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        """Verify that from_dataframe makes a copy."""
        bt = backend.from_dataframe(sample_df)
        # Modify original
        sample_df.loc[0, "Amount"] = 999
        # BackendTable should not be affected
        assert bt.native.loc[0, "Amount"] == 100

    def test_column_names(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        assert backend.column_names(bt) == ["Name", "Amount", "Category"]


class TestPandasBackendSelectOperations:
    """Test column selection operations."""

    def test_select_columns(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.select_columns(bt, ["Name", "Amount"])
        assert backend.column_names(result) == ["Name", "Amount"]
        assert len(result.native) == 3

    def test_remove_columns(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.remove_columns(bt, ["Category"])
        assert backend.column_names(result) == ["Name", "Amount"]

    def test_rename_columns(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.rename_columns(bt, {"Name": "FullName", "Amount": "Total"})
        assert backend.column_names(result) == ["FullName", "Total", "Category"]


class TestPandasBackendFilterAndAdd:
    """Test filter and add column operations."""

    def test_filter_rows(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.filter_rows(bt, lambda row: row["Amount"] > 150)
        assert len(result.native) == 2
        assert list(result.native["Name"]) == ["Bob", "Charlie"]

    def test_add_column(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.add_column(bt, "Bonus", lambda row: row["Amount"] * 0.1)
        assert "Bonus" in backend.column_names(result)
        assert list(result.native["Bonus"]) == [10.0, 20.0, 30.0]


class TestPandasBackendSorting:
    """Test sorting operations."""

    def test_sort_ascending(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.sort(bt, ["Amount"], descending=False)
        assert list(result.native["Amount"]) == [100, 200, 300]

    def test_sort_descending(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.sort(bt, ["Amount"], descending=True)
        assert list(result.native["Amount"]) == [300, 200, 100]


class TestPandasBackendSlicing:
    """Test head/tail/skip operations."""

    def test_head(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.head(bt, 2)
        assert len(result.native) == 2
        assert list(result.native["Name"]) == ["Alice", "Bob"]

    def test_tail(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.tail(bt, 2)
        assert len(result.native) == 2
        assert list(result.native["Name"]) == ["Bob", "Charlie"]

    def test_skip(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.skip(bt, 1)
        assert len(result.native) == 2
        assert list(result.native["Name"]) == ["Bob", "Charlie"]


class TestPandasBackendOther:
    """Test other operations."""

    def test_distinct(self, backend: PandasBackend) -> None:
        df = pd.DataFrame({
            "Name": ["Alice", "Bob", "Alice"],
            "Amount": [100, 200, 100],
        })
        bt = backend.from_dataframe(df)
        result = backend.distinct(bt)
        assert len(result.native) == 2

    def test_fill_down(self, backend: PandasBackend) -> None:
        df = pd.DataFrame({
            "Name": ["Alice", None, "Charlie"],
            "Amount": [100, None, 300],
        })
        bt = backend.from_dataframe(df)
        result = backend.fill_down(bt, ["Name", "Amount"])
        assert list(result.native["Name"]) == ["Alice", "Alice", "Charlie"]
        assert list(result.native["Amount"]) == [100.0, 100.0, 300.0]

    def test_row_count(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        assert backend.row_count(bt) == 3

    def test_iter_rows(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        rows = list(backend.iter_rows(bt))
        assert len(rows) == 3
        assert rows[0]["Name"] == "Alice"

    def test_to_pandas(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.to_pandas(bt)
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 3

    def test_collect(self, backend: PandasBackend, sample_df: pd.DataFrame) -> None:
        bt = backend.from_dataframe(sample_df)
        result = backend.collect(bt)
        assert isinstance(result, pd.DataFrame)
