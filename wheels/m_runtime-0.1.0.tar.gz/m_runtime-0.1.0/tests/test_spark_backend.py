"""Tests for SparkBackend using mock Spark.

These tests use MockSparkDataFrame to test SparkBackend without
requiring a real PySpark installation.
"""

import pandas as pd
import pytest
import sys
from pathlib import Path

# Add tests directory to path for mocks
tests_dir = Path(__file__).parent
if str(tests_dir) not in sys.path:
    sys.path.insert(0, str(tests_dir))

from mocks.spark import MockSparkDataFrame, MockSparkSession


class TestMockSpark:
    """Test that mock Spark classes work correctly."""

    def test_mock_dataframe_columns(self) -> None:
        pdf = pd.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
        mock_df = MockSparkDataFrame(pdf)
        assert mock_df.columns == ["A", "B"]

    def test_mock_dataframe_to_pandas(self) -> None:
        pdf = pd.DataFrame({"A": [1, 2, 3]})
        mock_df = MockSparkDataFrame(pdf)
        result = mock_df.toPandas()
        assert isinstance(result, pd.DataFrame)
        assert list(result["A"]) == [1, 2, 3]

    def test_mock_dataframe_select(self) -> None:
        pdf = pd.DataFrame({"A": [1, 2], "B": [3, 4], "C": [5, 6]})
        mock_df = MockSparkDataFrame(pdf)
        result = mock_df.select("A", "B")
        assert result.columns == ["A", "B"]

    def test_mock_dataframe_limit(self) -> None:
        pdf = pd.DataFrame({"A": [1, 2, 3, 4, 5]})
        mock_df = MockSparkDataFrame(pdf)
        result = mock_df.limit(3)
        assert result.count() == 3

    def test_mock_dataframe_distinct(self) -> None:
        pdf = pd.DataFrame({"A": [1, 1, 2, 2, 3]})
        mock_df = MockSparkDataFrame(pdf)
        result = mock_df.distinct()
        assert result.count() == 3

    def test_mock_session_create_dataframe(self) -> None:
        session = MockSparkSession()
        pdf = pd.DataFrame({"X": [10, 20]})
        mock_df = session.createDataFrame(pdf)
        assert mock_df.count() == 2
        assert mock_df.columns == ["X"]


class TestSparkBackendWithMock:
    """Test SparkBackend using mock Spark classes.

    These tests patch the Spark imports to use our mocks.
    """

    def test_spark_backend_detect(self) -> None:
        """Test that mock Spark DF is detected correctly."""
        from m_runtime.backends import detect_backend

        pdf = pd.DataFrame({"A": [1]})
        mock_df = MockSparkDataFrame(pdf)

        # Mock should be detected as Spark
        backend_type = detect_backend(mock_df)
        assert backend_type == "spark"

    def test_spark_backend_from_mock(self) -> None:
        """Test creating SparkBackend from mock DataFrame."""
        # Skip if pyspark is not available (SparkBackend not registered)
        pytest.importorskip("pyspark", reason="PySpark not installed")

        from m_runtime.backends import get_backend

        backend = get_backend("spark", spark_session=MockSparkSession())
        pdf = pd.DataFrame({"Name": ["Alice"], "Amount": [100]})
        mock_df = MockSparkDataFrame(pdf)

        bt = backend.from_dataframe(mock_df)
        assert backend.column_names(bt) == ["Name", "Amount"]


# Tests that require real PySpark are marked for skip in CI
@pytest.mark.skipif(
    "pyspark" not in sys.modules,
    reason="PySpark not installed"
)
class TestSparkBackendReal:
    """Tests requiring real PySpark."""

    def test_real_spark_operations(self) -> None:
        """Integration test with real PySpark if available."""
        pass  # Placeholder for future real Spark tests
