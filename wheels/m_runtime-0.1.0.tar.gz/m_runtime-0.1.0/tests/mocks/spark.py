"""Mock PySpark for CI testing.

This module provides mock implementations of SparkSession and DataFrame
that are backed by pandas. This allows testing Spark-related code paths
without requiring a real PySpark installation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterator, List, Optional, Union

import pandas as pd


@dataclass
class MockColumn:
    """Mock Spark Column for expressions."""

    name: str


@dataclass
class MockSchema:
    """Mock Spark schema."""

    names: List[str]

    @property
    def fieldNames(self) -> List[str]:
        return self.names


class MockSparkDataFrame:
    """Mock Spark DataFrame backed by pandas.

    This provides enough of the Spark DataFrame API to test SparkBackend
    without actually running Spark.
    """

    def __init__(self, pdf: pd.DataFrame) -> None:
        """Create from pandas DataFrame.

        Args:
            pdf: pandas DataFrame backing this mock
        """
        self._pdf = pdf.copy()

    @property
    def columns(self) -> List[str]:
        """Get column names."""
        return list(self._pdf.columns)

    @property
    def schema(self) -> MockSchema:
        """Get schema."""
        return MockSchema(list(self._pdf.columns))

    def toPandas(self) -> pd.DataFrame:
        """Convert to pandas DataFrame."""
        return self._pdf.copy()

    def select(self, *cols: Union[str, MockColumn]) -> MockSparkDataFrame:
        """Select columns."""
        col_names = [c.name if isinstance(c, MockColumn) else c for c in cols]
        return MockSparkDataFrame(self._pdf[col_names])

    def drop(self, *cols: str) -> MockSparkDataFrame:
        """Drop columns."""
        return MockSparkDataFrame(self._pdf.drop(columns=list(cols)))

    def withColumnRenamed(self, existing: str, new: str) -> MockSparkDataFrame:
        """Rename a column."""
        return MockSparkDataFrame(self._pdf.rename(columns={existing: new}))

    def withColumn(self, name: str, col: Any) -> MockSparkDataFrame:
        """Add or replace a column."""
        pdf = self._pdf.copy()
        if isinstance(col, pd.Series):
            pdf[name] = col.values
        elif isinstance(col, list):
            pdf[name] = col
        elif hasattr(col, "_values"):
            # Mock column expression result
            pdf[name] = col._values
        else:
            # Assume it's a scalar or callable
            pdf[name] = col
        return MockSparkDataFrame(pdf)

    def filter(self, condition: Any) -> MockSparkDataFrame:
        """Filter rows."""
        if hasattr(condition, "_mask"):
            return MockSparkDataFrame(self._pdf[condition._mask])
        return self  # No-op if condition not understood

    def orderBy(self, *cols: Any) -> MockSparkDataFrame:
        """Sort by columns."""
        col_names = []
        ascending = []
        for c in cols:
            if hasattr(c, "_name") and hasattr(c, "_ascending"):
                col_names.append(c._name)
                ascending.append(c._ascending)
            elif isinstance(c, str):
                col_names.append(c)
                ascending.append(True)

        if col_names:
            return MockSparkDataFrame(
                self._pdf.sort_values(by=col_names, ascending=ascending).reset_index(
                    drop=True
                )
            )
        return self

    def limit(self, n: int) -> MockSparkDataFrame:
        """Take first n rows."""
        return MockSparkDataFrame(self._pdf.head(n).reset_index(drop=True))

    def distinct(self) -> MockSparkDataFrame:
        """Remove duplicates."""
        return MockSparkDataFrame(self._pdf.drop_duplicates().reset_index(drop=True))

    def count(self) -> int:
        """Get row count."""
        return len(self._pdf)

    def collect(self) -> List[Any]:
        """Collect rows."""
        return [MockRow(row) for _, row in self._pdf.iterrows()]


class MockRow:
    """Mock Spark Row."""

    def __init__(self, data: pd.Series) -> None:
        self._data = data

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def asDict(self) -> Dict[str, Any]:
        return self._data.to_dict()


class MockOrderColumn:
    """Mock column with ordering for orderBy."""

    def __init__(self, name: str, ascending: bool = True) -> None:
        self._name = name
        self._ascending = ascending


def asc(col_name: str) -> MockOrderColumn:
    """Create ascending order column."""
    return MockOrderColumn(col_name, ascending=True)


def desc(col_name: str) -> MockOrderColumn:
    """Create descending order column."""
    return MockOrderColumn(col_name, ascending=False)


def col(name: str) -> MockColumn:
    """Create a column reference."""
    return MockColumn(name)


def monotonically_increasing_id() -> MockMonotonicallyIncreasingId:
    """Create monotonically increasing ID expression."""
    return MockMonotonicallyIncreasingId()


class MockMonotonicallyIncreasingId:
    """Mock monotonically_increasing_id function result."""

    pass


class MockSparkSession:
    """Mock SparkSession for testing."""

    class Builder:
        """Builder for MockSparkSession."""

        def getOrCreate(self) -> MockSparkSession:
            return MockSparkSession()

    builder = Builder()

    def createDataFrame(
        self, data: Union[pd.DataFrame, List[Dict[str, Any]]], schema: Optional[Any] = None
    ) -> MockSparkDataFrame:
        """Create a DataFrame.

        Args:
            data: pandas DataFrame or list of dicts
            schema: Optional schema (ignored in mock)

        Returns:
            MockSparkDataFrame
        """
        if isinstance(data, pd.DataFrame):
            return MockSparkDataFrame(data)
        else:
            return MockSparkDataFrame(pd.DataFrame(data))
