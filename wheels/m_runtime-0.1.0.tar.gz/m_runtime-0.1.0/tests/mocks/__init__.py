"""Mock implementations for testing without PySpark."""

from .spark import MockSparkDataFrame, MockSparkSession

__all__ = ["MockSparkDataFrame", "MockSparkSession"]
