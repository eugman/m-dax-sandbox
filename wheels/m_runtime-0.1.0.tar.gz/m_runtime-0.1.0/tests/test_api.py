"""Tests for the run_m API."""

import pandas as pd
import pytest

from m_runtime import run_m, MRuntimeTable
from m_runtime.discovery import discover_dataframes, detect_backend_type


class TestDiscovery:
    """Test DataFrame discovery."""

    def test_discover_pandas_dataframes(self) -> None:
        # Create a local namespace with DataFrames
        Sales = pd.DataFrame({"Amount": [100, 200]})
        Products = pd.DataFrame({"Name": ["A", "B"]})
        not_a_df = "hello"
        _private = pd.DataFrame({"X": [1]})

        namespace = {
            "Sales": Sales,
            "Products": Products,
            "not_a_df": not_a_df,
            "_private": _private,
        }

        discovered = discover_dataframes(namespace)

        assert "Sales" in discovered
        assert "Products" in discovered
        assert "not_a_df" not in discovered
        assert "_private" not in discovered

    def test_detect_backend_type_pandas(self) -> None:
        tables = {
            "A": pd.DataFrame({"X": [1]}),
            "B": pd.DataFrame({"Y": [2]}),
        }
        assert detect_backend_type(tables) == "pandas"

    def test_detect_backend_type_empty(self) -> None:
        with pytest.raises(ValueError, match="No tables provided"):
            detect_backend_type({})


class TestRunMBasics:
    """Test basic run_m functionality."""

    def test_run_m_simple_expression(self) -> None:
        """Test evaluating a simple M expression."""
        result = run_m("1 + 2", return_pandas=False)
        assert result.to_python() == 3

    def test_run_m_with_table(self) -> None:
        """Test run_m with an explicit table."""
        Sales = pd.DataFrame({
            "Name": ["Alice", "Bob", "Charlie"],
            "Amount": [100, 200, 300],
        })

        result = run_m(
            "Sales",
            tables={"Sales": Sales},
            return_pandas=True,
        )

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 3
        assert list(result.columns) == ["Name", "Amount"]


class TestRunMTableOperations:
    """Test table operations via run_m."""

    def test_select_rows(self) -> None:
        Sales = pd.DataFrame({
            "Name": ["Alice", "Bob", "Charlie"],
            "Amount": [100, 200, 300],
        })

        result = run_m(
            "Table.SelectRows(Sales, each [Amount] > 150)",
            tables={"Sales": Sales},
        )

        assert len(result) == 2
        assert list(result["Name"]) == ["Bob", "Charlie"]

    def test_add_column(self) -> None:
        Sales = pd.DataFrame({
            "Name": ["Alice", "Bob"],
            "Amount": [100, 200],
        })

        result = run_m(
            'Table.AddColumn(Sales, "Bonus", each [Amount] * 0.1)',
            tables={"Sales": Sales},
        )

        assert "Bonus" in result.columns
        assert list(result["Bonus"]) == [10.0, 20.0]

    def test_select_rows_with_text(self) -> None:
        """Test filtering with text comparison."""
        Sales = pd.DataFrame({
            "Name": ["Alice", "Bob", "Charlie"],
            "Amount": [100, 200, 300],
        })

        result = run_m(
            'Table.SelectRows(Sales, each [Name] = "Bob")',
            tables={"Sales": Sales},
        )

        assert len(result) == 1
        assert result.iloc[0]["Name"] == "Bob"

    def test_add_column_with_calculation(self) -> None:
        """Test adding a column with arithmetic."""
        Sales = pd.DataFrame({
            "Price": [10.0, 20.0],
            "Quantity": [5, 3],
        })

        result = run_m(
            'Table.AddColumn(Sales, "Total", each [Price] * [Quantity])',
            tables={"Sales": Sales},
        )

        assert "Total" in result.columns
        assert list(result["Total"]) == [50.0, 60.0]


class TestRunMLetExpressions:
    """Test let expressions via run_m."""

    def test_let_with_table_transformations(self) -> None:
        Sales = pd.DataFrame({
            "Name": ["Alice", "Bob", "Charlie"],
            "Amount": [100, 200, 300],
        })

        code = '''
        let
            Filtered = Table.SelectRows(Sales, each [Amount] > 150),
            WithBonus = Table.AddColumn(Filtered, "Bonus", each [Amount] * 0.1)
        in
            WithBonus
        '''

        result = run_m(code, tables={"Sales": Sales})

        assert len(result) == 2
        assert "Bonus" in result.columns
        assert list(result["Name"]) == ["Bob", "Charlie"]
        assert list(result["Bonus"]) == [20.0, 30.0]

    def test_let_with_chained_filters(self) -> None:
        """Test multiple filter operations."""
        Data = pd.DataFrame({
            "Category": ["A", "B", "A", "B", "A"],
            "Value": [10, 20, 30, 40, 50],
        })

        code = '''
        let
            CategoryA = Table.SelectRows(Data, each [Category] = "A"),
            HighValue = Table.SelectRows(CategoryA, each [Value] > 20)
        in
            HighValue
        '''

        result = run_m(code, tables={"Data": Data})

        assert len(result) == 2
        assert list(result["Value"]) == [30, 50]


class TestRunMNamespaceDiscovery:
    """Test run_m with namespace discovery."""

    def test_namespace_discovery(self) -> None:
        # Simulate what happens in a notebook cell
        Sales = pd.DataFrame({
            "Name": ["Alice", "Bob"],
            "Amount": [100, 200],
        })

        # Pass the local namespace
        local_ns = {"Sales": Sales}

        result = run_m(
            "Table.SelectRows(Sales, each [Amount] > 150)",
            namespace=local_ns,
        )

        assert len(result) == 1
        assert result.iloc[0]["Name"] == "Bob"

    def test_explicit_tables_override_namespace(self) -> None:
        # Namespace has a Sales table
        namespace_sales = pd.DataFrame({"Amount": [1, 2, 3]})

        # Explicit tables has a different Sales table
        explicit_sales = pd.DataFrame({"Amount": [100, 200, 300]})

        local_ns = {"Sales": namespace_sales}

        result = run_m(
            "Sales",
            tables={"Sales": explicit_sales},
            namespace=local_ns,
        )

        # Explicit should override namespace
        assert list(result["Amount"]) == [100, 200, 300]


class TestMRuntimeTable:
    """Test MRuntimeTable directly."""

    def test_from_pandas(self) -> None:
        df = pd.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
        table = MRuntimeTable.from_pandas(df)

        assert table.backend_name == "pandas"
        assert table.column_names == ["A", "B"]
        assert len(table) == 3

    def test_select_columns(self) -> None:
        df = pd.DataFrame({"A": [1], "B": [2], "C": [3]})
        table = MRuntimeTable.from_pandas(df)

        result = table.select_columns(["A", "C"])
        assert result.column_names == ["A", "C"]

    def test_filter_rows(self) -> None:
        df = pd.DataFrame({"Amount": [100, 200, 300]})
        table = MRuntimeTable.from_pandas(df)

        result = table.filter_rows(lambda row: row["Amount"] > 150)
        assert len(result) == 2

    def test_to_pandas(self) -> None:
        df = pd.DataFrame({"X": [1, 2, 3]})
        table = MRuntimeTable.from_pandas(df)

        result = table.to_pandas()
        assert isinstance(result, pd.DataFrame)
        assert list(result["X"]) == [1, 2, 3]


class TestMixedBackendError:
    """Test error handling for mixed backends."""

    def test_mixed_backends_raises_error(self) -> None:
        """Mixing pandas and Spark should raise an error."""
        # This test would require a mock Spark DataFrame
        # For now, just test the error message
        from m_runtime.discovery import validate_tables

        with pytest.raises(ValueError, match="Cannot use mixed"):
            validate_tables({}, "mixed")
