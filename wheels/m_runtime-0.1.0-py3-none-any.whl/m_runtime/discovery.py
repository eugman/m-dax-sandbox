"""DataFrame discovery from namespaces.

This module provides utilities for automatically discovering DataFrames
in a namespace (like globals()) and detecting their backend type.
"""

from __future__ import annotations

from typing import Any, Dict

import pandas as pd


def discover_dataframes(namespace: Dict[str, Any]) -> Dict[str, Any]:
    """Discover DataFrames in a namespace.

    Scans the namespace for pandas DataFrames and Spark DataFrames,
    returning a dict of name -> DataFrame pairs.

    Args:
        namespace: A namespace dict (e.g., globals())

    Returns:
        Dict mapping variable names to DataFrame objects

    Example:
        >>> Sales = pd.DataFrame({"Amount": [100, 200]})
        >>> Products = pd.DataFrame({"Name": ["A", "B"]})
        >>> discovered = discover_dataframes(globals())
        >>> list(discovered.keys())
        ['Sales', 'Products']
    """
    dataframes: Dict[str, Any] = {}

    for name, value in namespace.items():
        # Skip private names
        if name.startswith("_"):
            continue

        # Check for pandas DataFrame
        if isinstance(value, pd.DataFrame):
            dataframes[name] = value
            continue

        # Check for Spark DataFrame (duck typing)
        if _is_spark_dataframe(value):
            dataframes[name] = value
            continue

    return dataframes


def _is_spark_dataframe(obj: Any) -> bool:
    """Check if object is a Spark DataFrame using duck typing.

    Args:
        obj: Object to check

    Returns:
        True if object has Spark DataFrame characteristics
    """
    # Check for key Spark DataFrame attributes
    return (
        hasattr(obj, "toPandas")
        and hasattr(obj, "select")
        and hasattr(obj, "schema")
        and hasattr(obj, "columns")
        and callable(getattr(obj, "toPandas", None))
    )


def detect_backend_type(tables: Dict[str, Any]) -> str:
    """Detect the backend type for a collection of tables.

    Args:
        tables: Dict of name -> DataFrame

    Returns:
        Backend type: 'pandas', 'spark', or 'mixed'

    Raises:
        ValueError: If tables dict is empty
    """
    if not tables:
        raise ValueError("No tables provided")

    has_pandas = False
    has_spark = False

    for df in tables.values():
        if isinstance(df, pd.DataFrame):
            has_pandas = True
        elif _is_spark_dataframe(df):
            has_spark = True
        else:
            raise TypeError(
                f"Unsupported DataFrame type: {type(df).__name__}. "
                "Expected pandas.DataFrame or pyspark.sql.DataFrame."
            )

    if has_pandas and has_spark:
        return "mixed"
    elif has_spark:
        return "spark"
    else:
        return "pandas"


def validate_tables(tables: Dict[str, Any], expected_backend: str) -> None:
    """Validate that all tables match the expected backend type.

    Args:
        tables: Dict of name -> DataFrame
        expected_backend: Expected backend ('pandas' or 'spark')

    Raises:
        TypeError: If any table doesn't match the expected backend
        ValueError: If expected_backend is 'mixed' (not allowed)
    """
    if expected_backend == "mixed":
        raise ValueError(
            "Cannot use mixed pandas and Spark DataFrames. "
            "M code cannot join tables from different backends. "
            "Convert all tables to the same type before calling run_m()."
        )

    for name, df in tables.items():
        if expected_backend == "pandas":
            if not isinstance(df, pd.DataFrame):
                raise TypeError(
                    f"Table '{name}' is not a pandas DataFrame "
                    f"(got {type(df).__name__}). "
                    "All tables must be the same type."
                )
        elif expected_backend == "spark":
            if not _is_spark_dataframe(df):
                raise TypeError(
                    f"Table '{name}' is not a Spark DataFrame "
                    f"(got {type(df).__name__}). "
                    "All tables must be the same type."
                )
