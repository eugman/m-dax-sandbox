"""Pandas backend for m-runtime.

This backend uses pandas DataFrames for all operations.
It's the simplest backend and serves as the reference implementation.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Iterator, List, Union

import pandas as pd

from m_runtime.backends.base import BackendTable, TableBackend


class PandasBackend(TableBackend):
    """Table backend using pandas DataFrames.

    All operations are performed using pandas methods directly.
    This is the default backend when working with pandas DataFrames.
    """

    @property
    def backend_name(self) -> str:
        return "pandas"

    def _validate_columns(
        self, table: BackendTable, columns: List[str], operation: str
    ) -> None:
        """Validate that columns exist in the table.

        Args:
            table: The table to check
            columns: Column names to validate
            operation: Operation name for error message

        Raises:
            KeyError: If any column doesn't exist
        """
        existing = set(table.native.columns)
        missing = [c for c in columns if c not in existing]
        if missing:
            raise KeyError(
                f"{operation}: Column(s) not found: {missing}. "
                f"Available columns: {list(table.native.columns)}"
            )

    def from_dataframe(self, df: Any) -> BackendTable:
        """Create a BackendTable from a pandas DataFrame."""
        if not isinstance(df, pd.DataFrame):
            raise TypeError(f"Expected pandas.DataFrame, got {type(df).__name__}")
        return BackendTable(self, df.copy())

    def column_names(self, table: BackendTable) -> List[str]:
        """Get column names."""
        return list(table.native.columns)

    def select_columns(self, table: BackendTable, columns: List[str]) -> BackendTable:
        """Select specific columns."""
        self._validate_columns(table, columns, "Table.SelectColumns")
        new_df = table.native[columns].copy()
        return BackendTable(self, new_df)

    def remove_columns(self, table: BackendTable, columns: List[str]) -> BackendTable:
        """Remove specific columns."""
        self._validate_columns(table, columns, "Table.RemoveColumns")
        new_df = table.native.drop(columns=columns)
        return BackendTable(self, new_df)

    def rename_columns(self, table: BackendTable, mapping: Dict[str, str]) -> BackendTable:
        """Rename columns."""
        self._validate_columns(table, list(mapping.keys()), "Table.RenameColumns")
        new_df = table.native.rename(columns=mapping)
        return BackendTable(self, new_df)

    def filter_rows(
        self, table: BackendTable, predicate_fn: Callable[[Dict[str, Any]], bool]
    ) -> BackendTable:
        """Filter rows using a predicate function.

        The predicate receives each row as a dict and returns True to keep it.

        Args:
            table: Source table
            predicate_fn: Function that takes row dict, returns bool

        Returns:
            New table with only rows where predicate returned True
        """
        df = table.native

        # Handle empty DataFrame - preserve columns
        if len(df) == 0:
            return BackendTable(self, df.copy())

        # Convert to records and apply predicate
        records = df.to_dict("records")
        mask = [predicate_fn(row) for row in records]

        new_df = df[mask].reset_index(drop=True)
        return BackendTable(self, new_df)

    def add_column(
        self, table: BackendTable, name: str, generator_fn: Callable[[Dict[str, Any]], Any]
    ) -> BackendTable:
        """Add a computed column.

        The generator receives each row as a dict and returns the new value.

        Args:
            table: Source table
            name: Name for the new column
            generator_fn: Function that takes row dict, returns column value

        Returns:
            New table with the additional column
        """
        df = table.native.copy()

        # Convert to records and apply generator
        records = df.to_dict("records")
        new_values = [generator_fn(row) for row in records]

        df[name] = new_values
        return BackendTable(self, df)

    def sort(
        self,
        table: BackendTable,
        columns: List[str],
        descending: Union[bool, List[bool]] = False,
    ) -> BackendTable:
        """Sort by columns."""
        self._validate_columns(table, columns, "Table.Sort")

        # Convert descending to ascending (pandas uses ascending)
        if isinstance(descending, bool):
            ascending = not descending
        else:
            ascending = [not d for d in descending]

        new_df = table.native.sort_values(by=columns, ascending=ascending).reset_index(drop=True)
        return BackendTable(self, new_df)

    def head(self, table: BackendTable, n: int) -> BackendTable:
        """Take first n rows."""
        if n < 0:
            raise ValueError(f"Table.FirstN: count must be non-negative, got {n}")
        new_df = table.native.head(n).reset_index(drop=True)
        return BackendTable(self, new_df)

    def tail(self, table: BackendTable, n: int) -> BackendTable:
        """Take last n rows."""
        if n < 0:
            raise ValueError(f"Table.LastN: count must be non-negative, got {n}")
        new_df = table.native.tail(n).reset_index(drop=True)
        return BackendTable(self, new_df)

    def skip(self, table: BackendTable, n: int) -> BackendTable:
        """Skip first n rows."""
        if n < 0:
            raise ValueError(f"Table.Skip: count must be non-negative, got {n}")
        new_df = table.native.iloc[n:].reset_index(drop=True)
        return BackendTable(self, new_df)

    def distinct(self, table: BackendTable) -> BackendTable:
        """Remove duplicate rows."""
        new_df = table.native.drop_duplicates().reset_index(drop=True)
        return BackendTable(self, new_df)

    def fill_down(self, table: BackendTable, columns: List[str]) -> BackendTable:
        """Fill nulls with previous non-null values."""
        df = table.native.copy()
        for col in columns:
            if col in df.columns:
                df[col] = df[col].ffill()
        return BackendTable(self, df)

    def row_count(self, table: BackendTable) -> int:
        """Get number of rows."""
        return len(table.native)

    def iter_rows(self, table: BackendTable) -> Iterator[Dict[str, Any]]:
        """Iterate over rows as dicts."""
        for _, row in table.native.iterrows():
            yield row.to_dict()

    def to_pandas(self, table: BackendTable) -> pd.DataFrame:
        """Convert to pandas DataFrame."""
        return table.native.copy()

    def collect(self, table: BackendTable) -> pd.DataFrame:
        """Return the native DataFrame (no-op for pandas)."""
        return table.native
