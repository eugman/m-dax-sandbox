"""Base classes for table backends.

This module defines the abstract interface that all backends must implement.
Backends provide table operations for different DataFrame implementations
(pandas, PySpark, etc.).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, Iterator, List, Optional, Union

import pandas as pd


class BackendTable:
    """Wrapper around a native table with backend reference.

    This provides a uniform interface regardless of the underlying
    DataFrame type. All operations are delegated to the backend.

    Attributes:
        backend: The TableBackend that created this table
        native: The native DataFrame (pandas.DataFrame or pyspark.sql.DataFrame)
    """

    def __init__(self, backend: TableBackend, native: Any) -> None:
        """Create a BackendTable.

        Args:
            backend: The backend that manages this table
            native: The native DataFrame object
        """
        self.backend = backend
        self.native = native

    @property
    def column_names(self) -> List[str]:
        """Get column names."""
        return self.backend.column_names(self)

    def to_pandas(self) -> pd.DataFrame:
        """Convert to pandas DataFrame."""
        return self.backend.to_pandas(self)


class TableBackend(ABC):
    """Abstract base class for table backends.

    Each backend implements table operations for a specific DataFrame type.
    The interface is designed to support both pandas and PySpark while
    allowing efficient native operations where possible.

    Backend implementations should:
    1. Prefer native operations for efficiency
    2. Fall back to collect-to-driver for complex row operations
    3. Maintain immutability (operations return new tables)
    """

    @property
    @abstractmethod
    def backend_name(self) -> str:
        """Name of this backend (e.g., 'pandas', 'spark')."""
        pass

    @abstractmethod
    def from_dataframe(self, df: Any) -> BackendTable:
        """Create a BackendTable from a native DataFrame.

        Args:
            df: Native DataFrame (pandas or Spark)

        Returns:
            BackendTable wrapping the DataFrame
        """
        pass

    @abstractmethod
    def column_names(self, table: BackendTable) -> List[str]:
        """Get column names from the table.

        Args:
            table: The table to get column names from

        Returns:
            List of column names
        """
        pass

    @abstractmethod
    def select_columns(self, table: BackendTable, columns: List[str]) -> BackendTable:
        """Select specific columns.

        Args:
            table: Source table
            columns: Column names to select

        Returns:
            New table with only the specified columns
        """
        pass

    @abstractmethod
    def remove_columns(self, table: BackendTable, columns: List[str]) -> BackendTable:
        """Remove specific columns.

        Args:
            table: Source table
            columns: Column names to remove

        Returns:
            New table without the specified columns
        """
        pass

    @abstractmethod
    def rename_columns(self, table: BackendTable, mapping: Dict[str, str]) -> BackendTable:
        """Rename columns.

        Args:
            table: Source table
            mapping: Dict mapping old names to new names

        Returns:
            New table with renamed columns
        """
        pass

    @abstractmethod
    def filter_rows(
        self, table: BackendTable, predicate_fn: Callable[[Dict[str, Any]], bool]
    ) -> BackendTable:
        """Filter rows using a predicate function.

        The predicate receives each row as a dict and returns True to keep it.

        Note: For Spark, this collects to driver. See SparkBackend docs.
        FUTURE: UDF-based distributed execution for Spark.

        Args:
            table: Source table
            predicate_fn: Function that takes row dict, returns bool

        Returns:
            New table with only rows where predicate returned True
        """
        pass

    @abstractmethod
    def add_column(
        self, table: BackendTable, name: str, generator_fn: Callable[[Dict[str, Any]], Any]
    ) -> BackendTable:
        """Add a computed column.

        The generator receives each row as a dict and returns the new value.

        Note: For Spark, this collects to driver. See SparkBackend docs.
        FUTURE: UDF-based distributed execution for Spark.

        Args:
            table: Source table
            name: Name for the new column
            generator_fn: Function that takes row dict, returns column value

        Returns:
            New table with the additional column
        """
        pass

    @abstractmethod
    def sort(
        self,
        table: BackendTable,
        columns: List[str],
        descending: Union[bool, List[bool]] = False,
    ) -> BackendTable:
        """Sort by columns.

        Args:
            table: Source table
            columns: Column names to sort by
            descending: If True (or list of bools), sort descending

        Returns:
            New sorted table
        """
        pass

    @abstractmethod
    def head(self, table: BackendTable, n: int) -> BackendTable:
        """Take first n rows.

        Args:
            table: Source table
            n: Number of rows to take

        Returns:
            New table with first n rows
        """
        pass

    @abstractmethod
    def tail(self, table: BackendTable, n: int) -> BackendTable:
        """Take last n rows.

        Args:
            table: Source table
            n: Number of rows to take

        Returns:
            New table with last n rows
        """
        pass

    @abstractmethod
    def skip(self, table: BackendTable, n: int) -> BackendTable:
        """Skip first n rows.

        Args:
            table: Source table
            n: Number of rows to skip

        Returns:
            New table without first n rows
        """
        pass

    @abstractmethod
    def distinct(self, table: BackendTable) -> BackendTable:
        """Remove duplicate rows.

        Args:
            table: Source table

        Returns:
            New table with duplicates removed
        """
        pass

    @abstractmethod
    def fill_down(self, table: BackendTable, columns: List[str]) -> BackendTable:
        """Fill nulls with previous non-null values.

        Args:
            table: Source table
            columns: Columns to fill down

        Returns:
            New table with nulls filled
        """
        pass

    @abstractmethod
    def row_count(self, table: BackendTable) -> int:
        """Get number of rows.

        Args:
            table: The table

        Returns:
            Row count
        """
        pass

    @abstractmethod
    def iter_rows(self, table: BackendTable) -> Iterator[Dict[str, Any]]:
        """Iterate over rows as dicts.

        Args:
            table: The table

        Yields:
            Row data as dict
        """
        pass

    @abstractmethod
    def to_pandas(self, table: BackendTable) -> pd.DataFrame:
        """Convert to pandas DataFrame.

        Args:
            table: The table

        Returns:
            pandas DataFrame
        """
        pass

    @abstractmethod
    def collect(self, table: BackendTable) -> Any:
        """Materialize and return native DataFrame.

        For pandas, this is a no-op.
        For Spark, this collects the DataFrame.

        Args:
            table: The table

        Returns:
            Native DataFrame
        """
        pass

    def promote_headers(self, table: BackendTable) -> BackendTable:
        """Use first row as column headers.

        Args:
            table: Source table

        Returns:
            New table with first row as headers
        """
        # Default implementation via pandas
        pdf = self.to_pandas(table)
        if len(pdf) == 0:
            return table

        first_row = pdf.iloc[0]
        new_names = [str(v) if pd.notna(v) else f"Column{i}" for i, v in enumerate(first_row)]
        remaining = pdf.iloc[1:].copy()
        remaining.columns = new_names
        remaining = remaining.reset_index(drop=True)

        return self.from_dataframe(remaining)

    def get_row(self, table: BackendTable, index: int) -> Optional[Dict[str, Any]]:
        """Get a single row by index.

        Args:
            table: The table
            index: Row index (0-based)

        Returns:
            Row as dict, or None if index out of bounds
        """
        # Default implementation
        pdf = self.to_pandas(table)
        if index < 0 or index >= len(pdf):
            return None
        return pdf.iloc[index].to_dict()
