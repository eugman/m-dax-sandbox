"""MRuntimeTable - Multi-backend table for m-runtime.

This module provides MRuntimeTable, a table class that delegates all
operations to a backend (pandas or Spark). It's designed to work with
the FabricEvaluator and provides an interface similar to python-m's MTable.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Iterator, List, Optional, Union

import pandas as pd

from m_runtime.backends import BackendTable, TableBackend, get_backend, detect_backend


class MRuntimeTable:
    """Multi-backend table that delegates operations to a backend.

    This class wraps a BackendTable and provides a uniform interface
    for table operations regardless of the underlying DataFrame type.
    It's designed to be compatible with the python-m evaluator's
    expectations for table values.

    Attributes:
        _backend_table: The underlying BackendTable
    """

    def __init__(self, backend_table: BackendTable) -> None:
        """Create an MRuntimeTable.

        Args:
            backend_table: The BackendTable to wrap
        """
        self._backend_table = backend_table

    @property
    def backend(self) -> TableBackend:
        """Get the backend."""
        return self._backend_table.backend

    @property
    def backend_name(self) -> str:
        """Get the backend name."""
        return self._backend_table.backend.backend_name

    @property
    def native(self) -> Any:
        """Get the native DataFrame."""
        return self._backend_table.native

    @property
    def column_names(self) -> List[str]:
        """Get column names."""
        return self._backend_table.column_names

    # Factory methods

    @staticmethod
    def from_pandas(df: pd.DataFrame) -> MRuntimeTable:
        """Create from a pandas DataFrame.

        Args:
            df: pandas DataFrame

        Returns:
            MRuntimeTable using PandasBackend
        """
        backend = get_backend("pandas")
        backend_table = backend.from_dataframe(df)
        return MRuntimeTable(backend_table)

    @staticmethod
    def from_spark(df: Any, spark_session: Optional[Any] = None) -> MRuntimeTable:
        """Create from a Spark DataFrame.

        Args:
            df: Spark DataFrame
            spark_session: Optional SparkSession

        Returns:
            MRuntimeTable using SparkBackend
        """
        backend = get_backend("spark", spark_session=spark_session)
        backend_table = backend.from_dataframe(df)
        return MRuntimeTable(backend_table)

    @staticmethod
    def from_dataframe(
        df: Any,
        backend_name: Optional[str] = None,
        spark_session: Optional[Any] = None,
    ) -> MRuntimeTable:
        """Create from any DataFrame, auto-detecting backend.

        Args:
            df: pandas or Spark DataFrame
            backend_name: Optional explicit backend name
            spark_session: Optional SparkSession for Spark backend

        Returns:
            MRuntimeTable with appropriate backend
        """
        if backend_name is None:
            backend_name = detect_backend(df)

        if backend_name == "spark":
            backend = get_backend("spark", spark_session=spark_session)
        else:
            backend = get_backend(backend_name)

        backend_table = backend.from_dataframe(df)
        return MRuntimeTable(backend_table)

    # Table operations (mirror MTable interface)

    def select_columns(self, columns: List[str]) -> MRuntimeTable:
        """Select specific columns."""
        new_bt = self.backend.select_columns(self._backend_table, columns)
        return MRuntimeTable(new_bt)

    def remove_columns(self, columns: List[str]) -> MRuntimeTable:
        """Remove specific columns."""
        new_bt = self.backend.remove_columns(self._backend_table, columns)
        return MRuntimeTable(new_bt)

    def rename_columns(self, mapping: Dict[str, str]) -> MRuntimeTable:
        """Rename columns."""
        new_bt = self.backend.rename_columns(self._backend_table, mapping)
        return MRuntimeTable(new_bt)

    def filter_rows(self, predicate_fn: Callable[[Dict[str, Any]], bool]) -> MRuntimeTable:
        """Filter rows using a predicate function."""
        new_bt = self.backend.filter_rows(self._backend_table, predicate_fn)
        return MRuntimeTable(new_bt)

    def add_column(
        self, name: str, generator_fn: Callable[[Dict[str, Any]], Any]
    ) -> MRuntimeTable:
        """Add a computed column."""
        new_bt = self.backend.add_column(self._backend_table, name, generator_fn)
        return MRuntimeTable(new_bt)

    def sort(
        self, columns: List[str], descending: Union[bool, List[bool]] = False
    ) -> MRuntimeTable:
        """Sort by columns."""
        new_bt = self.backend.sort(self._backend_table, columns, descending)
        return MRuntimeTable(new_bt)

    def head(self, n: int) -> MRuntimeTable:
        """Take first n rows."""
        new_bt = self.backend.head(self._backend_table, n)
        return MRuntimeTable(new_bt)

    def tail(self, n: int) -> MRuntimeTable:
        """Take last n rows."""
        new_bt = self.backend.tail(self._backend_table, n)
        return MRuntimeTable(new_bt)

    def skip(self, n: int) -> MRuntimeTable:
        """Skip first n rows."""
        new_bt = self.backend.skip(self._backend_table, n)
        return MRuntimeTable(new_bt)

    def distinct(self) -> MRuntimeTable:
        """Remove duplicate rows."""
        new_bt = self.backend.distinct(self._backend_table)
        return MRuntimeTable(new_bt)

    def fill_down(self, columns: List[str]) -> MRuntimeTable:
        """Fill nulls with previous non-null values."""
        new_bt = self.backend.fill_down(self._backend_table, columns)
        return MRuntimeTable(new_bt)

    def promote_headers(self) -> MRuntimeTable:
        """Use first row as column headers."""
        new_bt = self.backend.promote_headers(self._backend_table)
        return MRuntimeTable(new_bt)

    # Row access

    def row(self, index: int) -> Optional[Dict[str, Any]]:
        """Get a single row by index."""
        return self.backend.get_row(self._backend_table, index)

    def __len__(self) -> int:
        """Get row count."""
        return self.backend.row_count(self._backend_table)

    def iter_rows(self) -> Iterator[Dict[str, Any]]:
        """Iterate over rows as dicts."""
        return self.backend.iter_rows(self._backend_table)

    # Conversion

    def to_pandas(self) -> pd.DataFrame:
        """Convert to pandas DataFrame."""
        return self.backend.to_pandas(self._backend_table)

    def collect(self) -> Any:
        """Materialize and return native DataFrame."""
        return self.backend.collect(self._backend_table)

    def __repr__(self) -> str:
        cols = self.column_names
        return f"MRuntimeTable[{self.backend_name}]({len(cols)} columns: {cols})"
