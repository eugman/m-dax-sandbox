"""Integration tests using fixture-based validation.

These tests validate the complete transpilation pipeline by:
1. Reading M code from fixture files
2. Transpiling to Pandas code
3. Comparing generated code to expected output
4. Executing generated code and comparing data output

SECURITY NOTE:
This test module uses exec() to execute transpiled Python code. This is safe because:
1. This code only runs during testing, not in production
2. The M code comes from controlled fixture files committed to the repository
3. The transpiler only generates safe pandas/polars operations

WARNING: Never use exec() with untrusted M code in production. The transpiler
does not sandbox the generated code. For untrusted input, use the runtime
interpreter (python_m.runtime.evaluate) which has controlled execution.
"""

import os
import tempfile
from pathlib import Path

import pandas as pd
import pytest

from python_m.transpiler import transpile

# Import from conftest - pytest discovers it automatically
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from conftest import load_fixture, discover_fixtures, Fixture


class TestFixtures:
    """Integration tests using fixture files."""

    @pytest.fixture(params=discover_fixtures() or ["001-csv-read-simple"])
    def fixture(self, request) -> Fixture:
        """Load a fixture for testing."""
        return load_fixture(request.param)

    def test_fixture_transpile_success(self, fixture: Fixture):
        """Test that M code transpiles successfully."""
        result = transpile(fixture.source_code, target="pandas")

        assert result.success, f"Transpilation failed for {fixture.name}: {result.error}"
        assert result.code is not None

    def test_fixture_code_matches_expected(self, fixture: Fixture):
        """Test that generated code matches expected output."""
        result = transpile(fixture.source_code, target="pandas")

        assert result.success, f"Transpilation failed: {result.error}"

        # Normalize whitespace for comparison
        generated = result.code.strip()
        expected = fixture.expected_code.strip()

        assert generated == expected, (
            f"Generated code does not match expected for {fixture.name}\n\n"
            f"Generated:\n{generated}\n\n"
            f"Expected:\n{expected}"
        )

    def test_fixture_generated_code_executes(self, fixture: Fixture):
        """Test that generated code executes without errors."""
        result = transpile(fixture.source_code, target="pandas")

        assert result.success, f"Transpilation failed: {result.error}"

        # Create a temporary directory with the input CSV
        with tempfile.TemporaryDirectory() as tmpdir:
            # Copy input CSV to temp directory
            input_csv_path = Path(tmpdir) / "input.csv"
            input_csv_path.write_text(fixture.input_csv, encoding="utf-8")

            # Modify generated code to use absolute path (use forward slashes for cross-platform)
            normalized_path = str(input_csv_path).replace("\\", "/")
            code = result.code.replace("'input.csv'", f"'{normalized_path}'")

            # Execute the generated code
            namespace = {}
            try:
                exec(code, namespace)
            except Exception as e:
                pytest.fail(f"Generated code failed to execute: {e}\n\nCode:\n{code}")

    def test_fixture_output_matches_expected(self, fixture: Fixture):
        """Test that executing generated code produces expected output."""
        result = transpile(fixture.source_code, target="pandas")

        assert result.success, f"Transpilation failed: {result.error}"

        # Create a temporary directory with the input CSV
        with tempfile.TemporaryDirectory() as tmpdir:
            # Copy input CSV to temp directory
            input_csv_path = Path(tmpdir) / "input.csv"
            input_csv_path.write_text(fixture.input_csv, encoding="utf-8")

            # Modify generated code to use absolute path (use forward slashes for cross-platform)
            normalized_path = str(input_csv_path).replace("\\", "/")
            code = result.code.replace("'input.csv'", f"'{normalized_path}'")

            # Execute the generated code
            namespace = {}
            exec(code, namespace)

            # Find the last DataFrame in the namespace (the result)
            # We use the last one because it's the final computation result
            df = None
            for name, value in namespace.items():
                if isinstance(value, pd.DataFrame):
                    df = value  # Keep overwriting to get the last one

            assert df is not None, "Generated code did not produce a DataFrame"

            # Load expected output
            expected_csv_path = Path(tmpdir) / "expected_output.csv"
            expected_csv_path.write_text(fixture.expected_output_csv, encoding="utf-8")
            expected_df = pd.read_csv(expected_csv_path)

            # Normalize numeric columns: convert float columns with integer values to int
            # This handles cases where CSV with missing values causes float dtype
            def normalize_numeric(df_to_norm):
                for col in df_to_norm.columns:
                    if df_to_norm[col].dtype == 'float64':
                        # Check if all non-null values are integers
                        if df_to_norm[col].dropna().apply(lambda x: x == int(x)).all():
                            df_to_norm[col] = df_to_norm[col].astype('Int64')  # nullable int
                return df_to_norm

            df_norm = normalize_numeric(df.copy())
            expected_norm = normalize_numeric(expected_df.copy())

            # Compare DataFrames by converting to CSV strings
            result_csv = df_norm.to_csv(index=False)
            expected_csv = expected_norm.to_csv(index=False)
            assert result_csv == expected_csv, (
                f"Fixture {fixture.name} output mismatch:\n"
                f"Got:\n{result_csv}\n"
                f"Expected:\n{expected_csv}"
            )


class TestTranspiler:
    """Direct tests for the transpile function."""

    def test_transpile_empty_source_fails(self):
        """Test that empty source code fails gracefully."""
        result = transpile("", target="pandas")

        assert not result.success
        assert result.error is not None
        assert "empty" in result.error.lower()

    def test_transpile_unsupported_target_fails(self):
        """Test that unsupported target fails gracefully."""
        result = transpile("let x = 1 in x", target="invalid_target")

        assert not result.success
        assert result.error is not None
        assert "unsupported" in result.error.lower()

    def test_transpile_invalid_syntax_fails(self):
        """Test that invalid M syntax fails gracefully."""
        result = transpile("let x = in x", target="pandas")

        assert not result.success
        assert result.error is not None

    def test_transpile_returns_ast(self):
        """Test that transpile result includes the AST."""
        source = 'let Source = Csv.Document(File.Contents("test.csv")) in Source'
        result = transpile(source, target="pandas")

        assert result.success
        assert result.ast is not None


class TestCsvReadSimple:
    """Specific tests for the csv-read-simple fixture."""

    @pytest.fixture
    def fixture(self) -> Fixture:
        """Load the specific fixture."""
        return load_fixture("csv-read-simple")

    def test_csv_read_simple_transpiles(self, fixture: Fixture):
        """Test that the simple CSV read example transpiles."""
        result = transpile(fixture.source_code, target="pandas")

        assert result.success
        assert "pd.read_csv" in result.code

    def test_csv_read_simple_produces_correct_output(self, fixture: Fixture):
        """Test that the simple CSV read produces correct data."""
        result = transpile(fixture.source_code, target="pandas")

        assert result.success

        with tempfile.TemporaryDirectory() as tmpdir:
            input_csv_path = Path(tmpdir) / "input.csv"
            input_csv_path.write_text(fixture.input_csv, encoding="utf-8")

            # Use forward slashes for cross-platform compatibility
            normalized_path = str(input_csv_path).replace("\\", "/")
            code = result.code.replace("'input.csv'", f"'{normalized_path}'")

            namespace = {}
            exec(code, namespace)

            df = namespace.get("Source")
            assert df is not None
            assert len(df) == 3  # Three data rows
            assert list(df.columns) == ["id", "name", "value"]


class TestQueryFolding:
    """Tests for query folding functionality."""

    @pytest.fixture
    def fixture(self) -> Fixture:
        """Load the query folding fixture."""
        return load_fixture("query-folding-nop")

    def test_folded_code_matches_expected(self, fixture: Fixture):
        """Test that folded output matches expected.py (default behavior)."""
        result = transpile(fixture.source_code, target="pandas", fold_queries=True)

        assert result.success, f"Transpilation failed: {result.error}"

        generated = result.code.strip()
        expected = fixture.expected_code.strip()

        assert generated == expected, (
            f"Folded code does not match expected\n\n"
            f"Generated:\n{generated}\n\n"
            f"Expected:\n{expected}"
        )

    def test_unfolded_code_matches_expected(self, fixture: Fixture):
        """Test that unfolded output matches expected_unfolded.py."""
        assert fixture.has_unfolded_variant, "Fixture missing expected_unfolded.py"

        result = transpile(fixture.source_code, target="pandas", fold_queries=False)

        assert result.success, f"Transpilation failed: {result.error}"

        generated = result.code.strip()
        expected = fixture.expected_unfolded_code.strip()

        assert generated == expected, (
            f"Unfolded code does not match expected\n\n"
            f"Generated:\n{generated}\n\n"
            f"Expected:\n{expected}"
        )

    def test_folded_code_executes(self, fixture: Fixture):
        """Test that folded code executes correctly."""
        result = transpile(fixture.source_code, target="pandas", fold_queries=True)

        assert result.success

        with tempfile.TemporaryDirectory() as tmpdir:
            input_csv_path = Path(tmpdir) / "input.csv"
            input_csv_path.write_text(fixture.input_csv, encoding="utf-8")

            normalized_path = str(input_csv_path).replace("\\", "/")
            code = result.code.replace("'input.csv'", f"'{normalized_path}'")

            namespace = {}
            exec(code, namespace)

            # Should have Source DataFrame
            df = namespace.get("Source")
            assert df is not None
            assert len(df) == 3

    def test_unfolded_code_executes(self, fixture: Fixture):
        """Test that unfolded code executes and produces all intermediate variables."""
        result = transpile(fixture.source_code, target="pandas", fold_queries=False)

        assert result.success

        with tempfile.TemporaryDirectory() as tmpdir:
            input_csv_path = Path(tmpdir) / "input.csv"
            input_csv_path.write_text(fixture.input_csv, encoding="utf-8")

            normalized_path = str(input_csv_path).replace("\\", "/")
            code = result.code.replace("'input.csv'", f"'{normalized_path}'")

            namespace = {}
            exec(code, namespace)

            # Should have all intermediate DataFrames
            assert "Source" in namespace
            assert "Step1" in namespace
            assert "Step2" in namespace

            # All should be the same data
            pd.testing.assert_frame_equal(namespace["Source"], namespace["Step1"])
            pd.testing.assert_frame_equal(namespace["Step1"], namespace["Step2"])

    def test_default_is_folded(self, fixture: Fixture):
        """Test that default transpile behavior uses query folding."""
        # Without explicit fold_queries parameter (should default to True)
        result = transpile(fixture.source_code, target="pandas")

        assert result.success

        # Should match the folded output (NOPs removed)
        generated = result.code.strip()
        expected = fixture.expected_code.strip()

        assert generated == expected, "Default should use query folding"
