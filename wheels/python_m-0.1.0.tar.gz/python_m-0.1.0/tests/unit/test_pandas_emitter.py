"""Unit tests for the Pandas code emitter."""

import pytest
from python_m.parser.lexer import Lexer
from python_m.parser.parser import Parser
from python_m.emitters.pandas_emitter import PandasEmitter
from python_m.ast.nodes import (
    LetExpression,
    VariableAssignment,
    FunctionCall,
    MemberAccess,
    Identifier,
    StringLiteral,
    ListLiteral,
    NumberLiteral,
    EachExpression,
    FieldAccess,
    BinaryExpression,
)


class TestPandasEmitter:
    """Tests for the PandasEmitter class."""

    def _parse(self, source: str):
        """Helper to parse source code into an AST."""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        result = parser.parse()
        return result.ast

    def test_emit_csv_document(self):
        """Test emitting pd.read_csv from Csv.Document."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success, f"Emission failed: {result.warnings}"
        assert result.code is not None
        assert "pd.read_csv" in result.code

    def test_emit_includes_pandas_import(self):
        """Test that generated code includes pandas import."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "import pandas as pd" in result.code

    def test_emit_preserves_file_path(self):
        """Test that the file path from M code is preserved."""
        source = 'let Source = Csv.Document(File.Contents("my_data.csv")) in Source'
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "my_data.csv" in result.code

    def test_emit_preserves_variable_name(self):
        """Test that variable names are preserved."""
        source = 'let MyData = Csv.Document(File.Contents("input.csv")) in MyData'
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "MyData = pd.read_csv" in result.code

    def test_emit_generates_valid_python(self):
        """Test that generated code is syntactically valid Python."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success

        # Try to compile the generated code
        try:
            compile(result.code, "<string>", "exec")
        except SyntaxError as e:
            pytest.fail(f"Generated code has syntax error: {e}\n\nCode:\n{result.code}")

    def test_emit_handles_path_with_backslashes(self):
        """Test that Windows-style paths are handled correctly."""
        source = r'let Source = Csv.Document(File.Contents("C:\data\input.csv")) in Source'
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        # The path should be escaped properly in the output
        assert "input.csv" in result.code

    def test_emit_from_ast_directly(self):
        """Test emitting from a manually constructed AST."""
        # Manually construct: let Source = Csv.Document(File.Contents("test.csv")) in Source
        ast = LetExpression(
            variables=[
                VariableAssignment(
                    name="Source",
                    value=FunctionCall(
                        function=MemberAccess(
                            object=Identifier(name="Csv"),
                            member="Document"
                        ),
                        arguments=[
                            FunctionCall(
                                function=MemberAccess(
                                    object=Identifier(name="File"),
                                    member="Contents"
                                ),
                                arguments=[StringLiteral(value="test.csv")]
                            )
                        ]
                    )
                )
            ],
            result=Identifier(name="Source")
        )

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "pd.read_csv('test.csv')" in result.code
        assert "Source = pd.read_csv" in result.code

    def test_emit_warns_on_unsupported_function(self):
        """Test that unsupported functions generate warnings."""
        # Manually construct an AST with an unsupported function
        ast = LetExpression(
            variables=[
                VariableAssignment(
                    name="Source",
                    value=FunctionCall(
                        function=MemberAccess(
                            object=Identifier(name="Unknown"),
                            member="Function"
                        ),
                        arguments=[]
                    )
                )
            ],
            result=Identifier(name="Source")
        )

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        # Should still succeed but with warnings
        assert result.success
        assert len(result.warnings) > 0
        # Check for the new detailed error message format
        assert any("is not supported" in w for w in result.warnings)

    # =========================================================================
    # Tests for Table.SelectColumns (ea15077)
    # =========================================================================

    def test_emit_table_select_columns(self):
        """Test emitting Table.SelectColumns."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Selected = Table.SelectColumns(Source, {"a", "b"})
        in Selected'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "Source[['a', 'b']]" in result.code

    def test_emit_table_select_columns_preserves_variable(self):
        """Test that Table.SelectColumns preserves variable name."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            MyColumns = Table.SelectColumns(Source, {"x"})
        in MyColumns'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "MyColumns = Source" in result.code

    # =========================================================================
    # Tests for Table.RemoveColumns (ea15077)
    # =========================================================================

    def test_emit_table_remove_columns(self):
        """Test emitting Table.RemoveColumns."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Removed = Table.RemoveColumns(Source, {"a", "b"})
        in Removed'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert ".drop(columns=['a', 'b'])" in result.code

    # =========================================================================
    # Tests for Table.RenameColumns (58231e2)
    # =========================================================================

    def test_emit_table_rename_columns(self):
        """Test emitting Table.RenameColumns."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Renamed = Table.RenameColumns(Source, {{"old", "new"}})
        in Renamed'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert ".rename(columns={'old': 'new'})" in result.code

    def test_emit_table_rename_columns_multiple(self):
        """Test emitting Table.RenameColumns with multiple renames."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Renamed = Table.RenameColumns(Source, {{"a", "x"}, {"b", "y"}})
        in Renamed'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "'a': 'x'" in result.code
        assert "'b': 'y'" in result.code

    # =========================================================================
    # Tests for Table.SelectRows (fedd02b)
    # =========================================================================

    def test_emit_table_select_rows(self):
        """Test emitting Table.SelectRows."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Filtered = Table.SelectRows(Source, each [value] > 100)
        in Filtered'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "Source[Source['value'] > 100]" in result.code

    def test_emit_table_select_rows_resets_index(self):
        """Test that Table.SelectRows includes reset_index."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Filtered = Table.SelectRows(Source, each [x] > 0)
        in Filtered'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert ".reset_index(drop=True)" in result.code

    def test_emit_table_select_rows_comparison_operators(self):
        """Test Table.SelectRows with different comparison operators."""
        test_cases = [
            (">", ">"),
            ("<", "<"),
            (">=", ">="),
            ("<=", "<="),
            ("<>", "!="),
            ("=", "=="),
        ]

        for m_op, py_op in test_cases:
            source = f'''let
                Source = Csv.Document(File.Contents("input.csv")),
                Filtered = Table.SelectRows(Source, each [x] {m_op} 10)
            in Filtered'''
            ast = self._parse(source)

            emitter = PandasEmitter()
            result = emitter.emit(ast)

            assert result.success, f"Failed for operator {m_op}"
            assert f"Source['x'] {py_op} 10" in result.code, f"Wrong output for {m_op}"

    # =========================================================================
    # Tests for comments (008-comments)
    # =========================================================================

    def test_emit_preserves_comments(self):
        """Test that comments are preserved in output."""
        source = '''let
            // Load data
            Source = Csv.Document(File.Contents("input.csv"))
        in Source'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "# Load data" in result.code

    def test_emit_multiple_comments(self):
        """Test emitting multiple comments."""
        source = '''let
            // Step 1
            Source = Csv.Document(File.Contents("input.csv")),
            // Step 2
            Filtered = Table.SelectRows(Source, each [value] > 100)
        in Filtered'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "# Step 1" in result.code
        assert "# Step 2" in result.code

    def test_emit_comment_before_assignment(self):
        """Test that comment appears before its assignment."""
        source = '''let
            // This is the source
            Source = Csv.Document(File.Contents("input.csv"))
        in Source'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        # Comment should appear before the Source assignment
        comment_pos = result.code.find("# This is the source")
        source_pos = result.code.find("Source = pd.read_csv")
        assert comment_pos < source_pos, "Comment should appear before assignment"

    # =========================================================================
    # Tests for list literal emission
    # =========================================================================

    def test_emit_list_literal(self):
        """Test that list literals are emitted as Python lists."""
        # Manually construct AST with list literal in Table.SelectColumns
        ast = LetExpression(
            variables=[
                VariableAssignment(
                    name="Source",
                    value=FunctionCall(
                        function=MemberAccess(object=Identifier(name="Csv"), member="Document"),
                        arguments=[
                            FunctionCall(
                                function=MemberAccess(object=Identifier(name="File"), member="Contents"),
                                arguments=[StringLiteral(value="test.csv")]
                            )
                        ]
                    )
                ),
                VariableAssignment(
                    name="Selected",
                    value=FunctionCall(
                        function=MemberAccess(object=Identifier(name="Table"), member="SelectColumns"),
                        arguments=[
                            Identifier(name="Source"),
                            ListLiteral(items=[StringLiteral(value="a"), StringLiteral(value="b")])
                        ]
                    )
                )
            ],
            result=Identifier(name="Selected")
        )

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "['a', 'b']" in result.code

    # =========================================================================
    # Tests for Table.AddColumn (009-add-column)
    # =========================================================================

    def test_emit_table_add_column(self):
        """Test emitting Table.AddColumn."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Added = Table.AddColumn(Source, "FullName", each [First] & " " & [Last])
        in Added'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "Added = Source.copy()" in result.code
        assert "Added['FullName']" in result.code

    def test_emit_table_add_column_concatenation(self):
        """Test that & is converted to + in the expression."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Added = Table.AddColumn(Source, "Combined", each [A] & [B])
        in Added'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        # The & should become +
        assert "Source['A'] + Source['B']" in result.code

    def test_emit_concatenation_with_string_literal(self):
        """Test concatenation with string literals."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Added = Table.AddColumn(Source, "Greeting", each "Hello " & [Name])
        in Added'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "'Hello '" in result.code
        assert "+ Source['Name']" in result.code

    # =========================================================================
    # Tests for arithmetic in Table.AddColumn (010-add-column-arithmetic)
    # =========================================================================

    def test_emit_table_add_column_arithmetic(self):
        """Test emitting Table.AddColumn with arithmetic."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Added = Table.AddColumn(Source, "Total", each [Price] * [Qty])
        in Added'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "Source['Price'] * Source['Qty']" in result.code

    def test_emit_complex_arithmetic_expression(self):
        """Test emitting complex arithmetic expression."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Added = Table.AddColumn(Source, "Result", each [A] * [B] - [C] + [D])
        in Added'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        # Should contain all the operations
        assert "Source['A']" in result.code
        assert "Source['B']" in result.code
        assert "*" in result.code
        assert "-" in result.code
        assert "+" in result.code

    # =========================================================================
    # Tests for forward references / dependency ordering (011-forward-reference)
    # =========================================================================

    def test_emit_forward_reference_reorders_statements(self):
        """Test that forward references are reordered for valid Python."""
        source = '''let
            Result = Table.SelectColumns(Source, {"A"}),
            Source = Csv.Document(File.Contents("input.csv"))
        in Result'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        # Source should appear before Result in the output
        source_pos = result.code.find("Source = pd.read_csv")
        result_pos = result.code.find("Result = Source")
        assert source_pos < result_pos, "Source should be defined before Result"

    def test_emit_complex_forward_references(self):
        """Test complex forward reference chain: C depends on B, B depends on A."""
        source = '''let
            C = Table.SelectColumns(B, {"x"}),
            B = Table.SelectRows(A, each [value] > 0),
            A = Csv.Document(File.Contents("input.csv"))
        in C'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        # Order should be: A, B, C
        a_pos = result.code.find("A = pd.read_csv")
        b_pos = result.code.find("B = A[")
        c_pos = result.code.find("C = B[")
        assert a_pos < b_pos < c_pos, "Variables should be in dependency order: A, B, C"

    def test_emit_preserves_comments_with_reordering(self):
        """Test that comments stay with their variables after reordering."""
        source = '''let
            // Output step
            Result = Table.SelectColumns(Source, {"A"}),
            // Load data
            Source = Csv.Document(File.Contents("input.csv"))
        in Result'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        # Load data comment should appear before Source assignment
        load_comment_pos = result.code.find("# Load data")
        source_pos = result.code.find("Source = pd.read_csv")
        assert load_comment_pos < source_pos, "Comment should appear before its variable"
        # Output step comment should appear before Result assignment
        output_comment_pos = result.code.find("# Output step")
        result_pos = result.code.find("Result = Source")
        assert output_comment_pos < result_pos, "Comment should appear before its variable"

    def test_emit_no_dependency_preserves_order(self):
        """Test that independent variables maintain a stable order."""
        source = '''let
            A = Csv.Document(File.Contents("a.csv")),
            B = Csv.Document(File.Contents("b.csv"))
        in A'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        # Both are independent, should maintain alphabetical order (from sort)
        a_pos = result.code.find("A = pd.read_csv")
        b_pos = result.code.find("B = pd.read_csv")
        assert a_pos < b_pos, "Independent variables should be in stable order"

    def test_emit_dependency_extraction(self):
        """Test that dependencies are correctly extracted from expressions."""
        emitter = PandasEmitter()

        # Test identifier dependency
        id_node = Identifier(name="Source")
        deps = emitter._extract_dependencies(id_node, {"Source", "Other"})
        assert deps == {"Source"}

        # Test function call dependency
        func_node = FunctionCall(
            function=MemberAccess(object=Identifier(name="Table"), member="SelectColumns"),
            arguments=[Identifier(name="Input"), ListLiteral(items=[])]
        )
        deps = emitter._extract_dependencies(func_node, {"Input", "Other"})
        assert deps == {"Input"}

    def test_emit_topological_sort(self):
        """Test topological sort produces correct order."""
        emitter = PandasEmitter()

        # A depends on nothing, B depends on A, C depends on B
        deps = {
            "A": set(),
            "B": {"A"},
            "C": {"B"},
        }
        order = emitter._topological_sort(deps)
        assert order == ["A", "B", "C"]

        # Reverse dependency order in input
        deps = {
            "C": {"B"},
            "B": {"A"},
            "A": set(),
        }
        order = emitter._topological_sort(deps)
        assert order == ["A", "B", "C"]

    # =========================================================================
    # Tests for Table.Skip (012-table-skip)
    # =========================================================================

    def test_emit_table_skip(self):
        """Test emitting Table.Skip."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Skipped = Table.Skip(Source, 2)
        in Skipped'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "Source.iloc[2:].reset_index(drop=True)" in result.code

    def test_emit_table_skip_variable_count(self):
        """Test emitting Table.Skip with a variable count."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Skipped = Table.Skip(Source, 5)
        in Skipped'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "Source.iloc[5:].reset_index(drop=True)" in result.code

    # =========================================================================
    # Tests for List.Distinct (013-list-distinct)
    # =========================================================================

    def test_emit_list_distinct(self):
        """Test emitting List.Distinct."""
        source = '''let
            Items = List.Distinct({1, 2, 2, 3, 3, 3})
        in Items'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "list(dict.fromkeys(" in result.code

    def test_emit_list_distinct_with_strings(self):
        """Test emitting List.Distinct with string values."""
        source = '''let
            Items = List.Distinct({"a", "b", "a", "c"})
        in Items'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "list(dict.fromkeys([" in result.code

    # =========================================================================
    # Tests for Table.FillDown (013-table-fill-down)
    # =========================================================================

    def test_emit_table_fill_down(self):
        """Test emitting Table.FillDown."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Filled = Table.FillDown(Source, {"Category"})
        in Filled'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "Source.assign(**{col: Source[col].ffill() for col in ['Category']})" in result.code

    def test_emit_table_fill_down_multiple_columns(self):
        """Test emitting Table.FillDown with multiple columns."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Filled = Table.FillDown(Source, {"A", "B"})
        in Filled'''
        ast = self._parse(source)

        emitter = PandasEmitter()
        result = emitter.emit(ast)

        assert result.success
        assert "ffill()" in result.code
        assert "'A'" in result.code
        assert "'B'" in result.code
