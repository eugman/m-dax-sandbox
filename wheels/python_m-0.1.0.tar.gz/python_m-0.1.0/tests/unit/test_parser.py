"""Unit tests for the M code parser."""

import pytest
from python_m.parser.lexer import Lexer
from python_m.parser.parser import Parser, ParseResult
from python_m.ast.nodes import (
    LetExpression,
    VariableAssignment,
    FunctionCall,
    MemberAccess,
    Identifier,
    StringLiteral,
    ListLiteral,
    NumberLiteral,
    EachExpression,
    FieldAccess,
    BinaryExpression,
)


class TestParser:
    """Tests for the Parser class."""

    def _parse(self, source: str) -> ParseResult:
        """Helper to tokenize and parse source code."""
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        return parser.parse()

    def test_parse_simple_let_expression(self):
        """Test parsing a simple let expression."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        result = self._parse(source)

        assert result.success, f"Parse failed: {result.errors}"
        assert result.ast is not None
        assert isinstance(result.ast, LetExpression)

    def test_parse_let_with_variable_assignment(self):
        """Test that variable assignments are parsed correctly."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        result = self._parse(source)

        assert result.success
        assert len(result.ast.variables) == 1

        var = result.ast.variables[0]
        assert isinstance(var, VariableAssignment)
        assert var.name == "Source"

    def test_parse_function_call(self):
        """Test parsing a function call."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]

        # The value should be a FunctionCall
        assert isinstance(var.value, FunctionCall)

    def test_parse_member_access(self):
        """Test parsing member access (Csv.Document)."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        result = self._parse(source)

        assert result.success
        func_call = result.ast.variables[0].value

        # The function should be a MemberAccess
        assert isinstance(func_call.function, MemberAccess)
        assert func_call.function.member == "Document"

        # The object should be an Identifier
        assert isinstance(func_call.function.object, Identifier)
        assert func_call.function.object.name == "Csv"

    def test_parse_nested_function_call(self):
        """Test parsing nested function calls (Csv.Document(File.Contents(...)))."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        result = self._parse(source)

        assert result.success
        outer_call = result.ast.variables[0].value

        # First argument should be another FunctionCall
        assert len(outer_call.arguments) == 1
        inner_call = outer_call.arguments[0]
        assert isinstance(inner_call, FunctionCall)

        # Inner function should be File.Contents
        assert isinstance(inner_call.function, MemberAccess)
        assert inner_call.function.member == "Contents"
        assert inner_call.function.object.name == "File"

    def test_parse_string_literal_argument(self):
        """Test parsing string literal as function argument."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        result = self._parse(source)

        assert result.success
        outer_call = result.ast.variables[0].value
        inner_call = outer_call.arguments[0]

        # Argument to File.Contents should be a StringLiteral
        assert len(inner_call.arguments) == 1
        assert isinstance(inner_call.arguments[0], StringLiteral)
        assert inner_call.arguments[0].value == "input.csv"

    def test_parse_result_expression(self):
        """Test that the result expression (after 'in') is parsed correctly."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        result = self._parse(source)

        assert result.success
        assert result.ast.result is not None
        assert isinstance(result.ast.result, Identifier)
        assert result.ast.result.name == "Source"

    def test_parse_multiple_variables(self):
        """Test parsing let expression with multiple variables."""
        source = '''let
            Source = Csv.Document(File.Contents("input.csv")),
            Result = Source
        in
            Result'''
        result = self._parse(source)

        assert result.success
        assert len(result.ast.variables) == 2
        assert result.ast.variables[0].name == "Source"
        assert result.ast.variables[1].name == "Result"

    def test_parse_errors_on_missing_let(self):
        """Test that parser fails gracefully with missing 'let'."""
        source = 'Source = x in Source'
        result = self._parse(source)

        # Should not successfully parse as a LetExpression
        # (might parse as something else or fail)
        if result.success and result.ast:
            # If it parsed, it shouldn't be a proper LetExpression
            pass  # This is acceptable behavior

    def test_parse_errors_on_missing_in(self):
        """Test that parser reports error on missing 'in'."""
        source = 'let Source = x Source'
        result = self._parse(source)

        # Should report an error
        assert not result.success or len(result.errors) > 0

    def test_parse_empty_source(self):
        """Test parsing empty source code."""
        result = self._parse("")

        # Should fail or have no meaningful AST
        assert not result.success or result.ast is None

    # =========================================================================
    # Tests for list literals (ea15077)
    # =========================================================================

    def test_parse_list_literal(self):
        """Test parsing a list literal."""
        source = 'let cols = {"a", "b", "c"} in cols'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, ListLiteral)
        assert len(var.value.items) == 3

    def test_parse_list_literal_with_strings(self):
        """Test parsing list literal items are StringLiterals."""
        source = 'let cols = {"col1", "col2"} in cols'
        result = self._parse(source)

        assert result.success
        list_lit = result.ast.variables[0].value
        assert all(isinstance(item, StringLiteral) for item in list_lit.items)
        assert list_lit.items[0].value == "col1"
        assert list_lit.items[1].value == "col2"

    def test_parse_nested_list_literal(self):
        """Test parsing nested list literals (for Table.RenameColumns)."""
        source = 'let renames = {{"old", "new"}} in renames'
        result = self._parse(source)

        assert result.success
        outer_list = result.ast.variables[0].value
        assert isinstance(outer_list, ListLiteral)
        assert len(outer_list.items) == 1
        inner_list = outer_list.items[0]
        assert isinstance(inner_list, ListLiteral)
        assert len(inner_list.items) == 2

    def test_parse_table_select_columns(self):
        """Test parsing Table.SelectColumns function call."""
        source = 'let Result = Table.SelectColumns(Source, {"a", "b"}) in Result'
        result = self._parse(source)

        assert result.success
        func_call = result.ast.variables[0].value
        assert isinstance(func_call, FunctionCall)
        assert len(func_call.arguments) == 2
        assert isinstance(func_call.arguments[1], ListLiteral)

    # =========================================================================
    # Tests for each/field access/comparisons (fedd02b)
    # =========================================================================

    def test_parse_number_literal(self):
        """Test parsing number literals."""
        source = 'let x = 100 in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, NumberLiteral)
        assert var.value.value == "100"

    def test_parse_decimal_number_literal(self):
        """Test parsing decimal number literals."""
        source = 'let x = 3.14 in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, NumberLiteral)
        assert var.value.value == "3.14"

    def test_parse_field_access(self):
        """Test parsing field access [FieldName]."""
        source = 'let x = [FieldName] in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, FieldAccess)
        assert var.value.field_name == "FieldName"

    def test_parse_each_expression(self):
        """Test parsing each expression."""
        source = 'let filter = each [value] > 100 in filter'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, EachExpression)
        assert var.value.body is not None

    def test_parse_binary_expression(self):
        """Test parsing binary comparison expression."""
        source = 'let cond = [value] > 100 in cond'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, BinaryExpression)
        assert var.value.operator == ">"

    def test_parse_binary_expression_parts(self):
        """Test that binary expression has correct left/right parts."""
        source = 'let cond = [value] > 100 in cond'
        result = self._parse(source)

        assert result.success
        bin_expr = result.ast.variables[0].value
        assert isinstance(bin_expr.left, FieldAccess)
        assert bin_expr.left.field_name == "value"
        assert isinstance(bin_expr.right, NumberLiteral)
        assert bin_expr.right.value == "100"

    def test_parse_each_with_comparison(self):
        """Test parsing each expression with comparison body."""
        source = 'let filter = each [amount] >= 50 in filter'
        result = self._parse(source)

        assert result.success
        each_expr = result.ast.variables[0].value
        assert isinstance(each_expr, EachExpression)
        assert isinstance(each_expr.body, BinaryExpression)
        assert each_expr.body.operator == ">="

    def test_parse_table_select_rows(self):
        """Test parsing Table.SelectRows with each expression."""
        source = 'let Filtered = Table.SelectRows(Source, each [value] > 100) in Filtered'
        result = self._parse(source)

        assert result.success
        func_call = result.ast.variables[0].value
        assert isinstance(func_call, FunctionCall)
        assert len(func_call.arguments) == 2
        assert isinstance(func_call.arguments[1], EachExpression)

    def test_parse_all_comparison_operators(self):
        """Test parsing all comparison operators."""
        operators = [">", "<", ">=", "<=", "<>", "="]

        for op in operators:
            source = f'let cond = [x] {op} 10 in cond'
            result = self._parse(source)
            assert result.success, f"Failed to parse operator: {op}"
            bin_expr = result.ast.variables[0].value
            assert bin_expr.operator == op, f"Wrong operator: expected {op}, got {bin_expr.operator}"

    # =========================================================================
    # Tests for comments (008-comments)
    # =========================================================================

    def test_parse_comment_attached_to_assignment(self):
        """Test that comments are attached to variable assignments."""
        source = '''let
            // This is a comment
            Source = Csv.Document(File.Contents("input.csv"))
        in
            Source'''
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert var.comment == "This is a comment"

    def test_parse_multiple_assignments_with_comments(self):
        """Test parsing multiple assignments each with comments."""
        source = '''let
            // Load data
            Source = Csv.Document(File.Contents("input.csv")),
            // Filter rows
            Filtered = Table.SelectRows(Source, each [value] > 100)
        in
            Filtered'''
        result = self._parse(source)

        assert result.success
        assert len(result.ast.variables) == 2
        assert result.ast.variables[0].comment == "Load data"
        assert result.ast.variables[1].comment == "Filter rows"

    def test_parse_assignment_without_comment(self):
        """Test that assignments without comments have None comment."""
        source = 'let Source = Csv.Document(File.Contents("input.csv")) in Source'
        result = self._parse(source)

        assert result.success
        assert result.ast.variables[0].comment is None

    # =========================================================================
    # Tests for text concatenation (009-add-column)
    # =========================================================================

    def test_parse_concatenation_expression(self):
        """Test parsing a text concatenation expression."""
        source = 'let x = "a" & "b" in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, BinaryExpression)
        assert var.value.operator == "&"

    def test_parse_chained_concatenation(self):
        """Test parsing chained concatenation (left-associative)."""
        source = 'let x = [A] & " " & [B] in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        # Should be left-associative: ((A & " ") & B)
        assert isinstance(var.value, BinaryExpression)
        assert var.value.operator == "&"
        # Right side should be field access B
        assert isinstance(var.value.right, FieldAccess)
        assert var.value.right.field_name == "B"
        # Left side should be another concatenation
        assert isinstance(var.value.left, BinaryExpression)
        assert var.value.left.operator == "&"

    def test_parse_each_with_concatenation(self):
        """Test parsing each expression with concatenation."""
        source = 'let fn = each [First] & " " & [Last] in fn'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, EachExpression)
        assert isinstance(var.value.body, BinaryExpression)
        assert var.value.body.operator == "&"

    # =========================================================================
    # Tests for arithmetic expressions (010-add-column-arithmetic)
    # =========================================================================

    def test_parse_multiplication(self):
        """Test parsing multiplication expression."""
        source = 'let x = [A] * [B] in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, BinaryExpression)
        assert var.value.operator == "*"

    def test_parse_division(self):
        """Test parsing division expression."""
        source = 'let x = [A] / [B] in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, BinaryExpression)
        assert var.value.operator == "/"

    def test_parse_addition(self):
        """Test parsing addition expression."""
        source = 'let x = [A] + [B] in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, BinaryExpression)
        assert var.value.operator == "+"

    def test_parse_subtraction(self):
        """Test parsing subtraction expression."""
        source = 'let x = [A] - [B] in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        assert isinstance(var.value, BinaryExpression)
        assert var.value.operator == "-"

    def test_parse_arithmetic_precedence(self):
        """Test that * has higher precedence than +."""
        source = 'let x = [A] + [B] * [C] in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        # Should parse as A + (B * C)
        assert isinstance(var.value, BinaryExpression)
        assert var.value.operator == "+"  # Top level is +
        assert isinstance(var.value.right, BinaryExpression)
        assert var.value.right.operator == "*"  # Right side is *

    def test_parse_complex_arithmetic(self):
        """Test parsing complex arithmetic: A * B - C + D."""
        source = 'let x = [A] * [B] - [C] + [D] in x'
        result = self._parse(source)

        assert result.success
        var = result.ast.variables[0]
        # Should parse as ((A * B) - C) + D
        assert isinstance(var.value, BinaryExpression)
        assert var.value.operator == "+"  # Top is +
        assert isinstance(var.value.right, FieldAccess)
        assert var.value.right.field_name == "D"
