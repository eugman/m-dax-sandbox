"""Tests for the M language runtime interpreter.

These tests verify the runtime components:
- Thunk (lazy evaluation with memoization)
- Environment (lexical scoping)
- MValue types (M language values)
- Evaluator (AST interpreter)
- Builtins (standard library functions)
"""

import pytest
import polars as pl

from python_m.runtime import (
    # Core
    Thunk,
    Environment,
    GlobalEnvironment,
    Evaluator,
    evaluate,
    evaluate_with_context,
    # Values
    MValue,
    MNull,
    MText,
    MNumber,
    MLogical,
    MList,
    MRecord,
    MTable,
    MFunction,
    MBinary,
    # Conversion
    python_to_mvalue,
    mvalue_to_python,
    # Builtins
    get_builtin,
    has_builtin,
    list_builtins,
)


class TestThunk:
    """Tests for Thunk lazy evaluation."""

    def test_thunk_delays_computation(self):
        """Computation should not run until force() is called."""
        computed = []

        def computation():
            computed.append(True)
            return 42

        thunk = Thunk(computation)

        assert not thunk.is_evaluated
        assert len(computed) == 0

    def test_thunk_forces_computation(self):
        """force() should execute and return the computation result."""
        thunk = Thunk(lambda: 42)
        result = thunk.force()

        assert result == 42
        assert thunk.is_evaluated

    def test_thunk_memoizes_result(self):
        """Second force() should return cached value without recomputing."""
        call_count = 0

        def computation():
            nonlocal call_count
            call_count += 1
            return "result"

        thunk = Thunk(computation)
        thunk.force()
        thunk.force()
        thunk.force()

        assert call_count == 1

    def test_thunk_caches_errors(self):
        """Errors should be cached and re-raised."""
        thunk = Thunk(lambda: 1 / 0)

        with pytest.raises(ZeroDivisionError):
            thunk.force()

        assert thunk.has_error

        # Should re-raise cached error
        with pytest.raises(ZeroDivisionError):
            thunk.force()

    def test_thunk_eager_is_pre_evaluated(self):
        """Thunk.eager() should create pre-evaluated thunk."""
        thunk = Thunk.eager(100)

        assert thunk.is_evaluated
        assert thunk.force() == 100

    def test_thunk_map_applies_lazily(self):
        """map() should create new thunk without forcing original."""
        thunk = Thunk(lambda: 10)
        mapped = thunk.map(lambda x: x * 2)

        assert not thunk.is_evaluated
        assert mapped.force() == 20
        assert thunk.is_evaluated


class TestEnvironment:
    """Tests for Environment scoping."""

    def test_environment_bind_and_get(self):
        """bind() should store value, get() should retrieve it."""
        env = Environment()
        env.bind("x", MNumber(42))

        result = env.get("x")
        assert isinstance(result, MNumber)
        assert result.value == 42

    def test_environment_lazy_binding(self):
        """bind_lazy() should not evaluate until accessed."""
        evaluated = []
        env = Environment()

        env.bind_lazy("x", lambda: (evaluated.append(True), MNumber(42))[1])

        assert len(evaluated) == 0
        result = env.get("x")
        assert len(evaluated) == 1
        assert result.value == 42

    def test_environment_scope_chain(self):
        """Child environment should find values in parent."""
        parent = Environment()
        parent.bind("x", MNumber(1))

        child = parent.extend("child")
        child.bind("y", MNumber(2))

        assert child.get("x").value == 1
        assert child.get("y").value == 2

    def test_environment_shadowing(self):
        """Child binding should shadow parent binding."""
        parent = Environment()
        parent.bind("x", MNumber(1))

        child = parent.extend("child")
        child.bind("x", MNumber(2))

        assert child.get("x").value == 2
        assert parent.get("x").value == 1

    def test_environment_undefined_raises(self):
        """get() should raise NameError for undefined variables."""
        env = Environment()

        with pytest.raises(NameError):
            env.get("undefined")

    def test_environment_is_bound(self):
        """is_bound() should check entire scope chain."""
        parent = Environment()
        parent.bind("x", MNumber(1))

        child = parent.extend("child")

        assert child.is_bound("x")
        assert not child.is_bound("y")


class TestMValues:
    """Tests for M value types."""

    def test_mnull(self):
        """MNull should represent null value."""
        null = MNull()
        assert null.is_null()
        assert null.to_python() is None
        assert null.type_name == "null"

    def test_mlogical(self):
        """MLogical should represent boolean values."""
        true_val = MLogical(True)
        false_val = MLogical(False)

        assert true_val.to_python() is True
        assert false_val.to_python() is False
        assert bool(true_val)
        assert not bool(false_val)

    def test_mnumber_arithmetic(self):
        """MNumber should support arithmetic operations."""
        a = MNumber(10)
        b = MNumber(3)

        assert (a + b).value == 13
        assert (a - b).value == 7
        assert (a * b).value == 30
        assert (a / b).value == pytest.approx(3.333, rel=0.01)
        assert (-a).value == -10

    def test_mnumber_comparison(self):
        """MNumber should support comparison operations."""
        a = MNumber(5)
        b = MNumber(10)

        assert (a < b).value is True
        assert (a > b).value is False
        assert (a <= MNumber(5)).value is True

    def test_mtext(self):
        """MText should represent strings."""
        text = MText("hello")
        assert text.to_python() == "hello"
        assert text.type_name == "text"
        assert len(text) == 5

    def test_mtext_concatenation(self):
        """MText concatenation with &."""
        a = MText("hello")
        b = MText(" world")

        result = a.concatenate(b)
        assert result.value == "hello world"

    def test_mlist(self):
        """MList should represent ordered sequences."""
        lst = MList([MNumber(1), MNumber(2), MNumber(3)])

        assert len(lst) == 3
        assert lst[0].value == 1
        assert lst.to_python() == [1, 2, 3]

    def test_mlist_out_of_bounds_returns_null(self):
        """MList access out of bounds should return null."""
        lst = MList([MNumber(1)])

        result = lst[10]
        assert result.is_null()

    def test_mrecord(self):
        """MRecord should represent key-value mappings."""
        rec = MRecord({"name": MText("Alice"), "age": MNumber(30)})

        assert rec["name"].value == "Alice"
        assert rec["age"].value == 30
        assert rec.to_python() == {"name": "Alice", "age": 30}

    def test_mrecord_missing_field_returns_null(self):
        """MRecord access for missing field should return null."""
        rec = MRecord({"x": MNumber(1)})

        result = rec["missing"]
        assert result.is_null()

    def test_mtable_from_polars(self):
        """MTable should wrap Polars DataFrames."""
        df = pl.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
        table = MTable.from_polars(df)

        assert table.column_names == ["A", "B"]
        assert len(table) == 3

    def test_mtable_operations_are_lazy(self):
        """MTable operations should return new lazy tables."""
        df = pl.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]})
        table = MTable.from_polars(df)

        selected = table.select_columns(["A"])

        # Operation returns new MTable
        assert isinstance(selected, MTable)
        assert selected.column_names == ["A"]


class TestPythonConversion:
    """Tests for Python <-> MValue conversion."""

    def test_python_to_mvalue_primitives(self):
        """python_to_mvalue should convert primitive types."""
        assert isinstance(python_to_mvalue(None), MNull)
        assert python_to_mvalue(True).value is True
        assert python_to_mvalue(42).value == 42
        assert python_to_mvalue(3.14).value == 3.14
        assert python_to_mvalue("hello").value == "hello"

    def test_python_to_mvalue_collections(self):
        """python_to_mvalue should convert collections."""
        lst = python_to_mvalue([1, 2, 3])
        assert isinstance(lst, MList)
        assert len(lst) == 3

        rec = python_to_mvalue({"x": 1})
        assert isinstance(rec, MRecord)
        assert rec["x"].value == 1

    def test_mvalue_to_python(self):
        """mvalue_to_python should convert back to Python."""
        assert mvalue_to_python(MNull()) is None
        assert mvalue_to_python(MNumber(42)) == 42
        assert mvalue_to_python(MText("hi")) == "hi"


class TestBuiltins:
    """Tests for built-in M functions."""

    def test_has_builtin(self):
        """has_builtin should check if function exists."""
        assert has_builtin("Csv.Document")
        assert has_builtin("File.Contents")
        assert has_builtin("Text.Length")
        assert not has_builtin("Fake.Function")

    def test_list_builtins(self):
        """list_builtins should return all function names."""
        builtins = list_builtins()

        assert "Csv.Document" in builtins
        assert "File.Contents" in builtins
        assert len(builtins) > 10

    def test_text_length(self):
        """Text.Length should return string length."""
        func = get_builtin("Text.Length")
        result = func(MText("hello"))

        assert isinstance(result, MNumber)
        assert result.value == 5

    def test_text_length_null_propagation(self):
        """Text.Length should propagate null."""
        func = get_builtin("Text.Length")
        result = func(MNull())

        assert result.is_null()

    def test_text_upper(self):
        """Text.Upper should uppercase text."""
        func = get_builtin("Text.Upper")
        result = func(MText("hello"))

        assert result.value == "HELLO"

    def test_number_round(self):
        """Number.Round should round numbers."""
        func = get_builtin("Number.Round")

        assert func(MNumber(3.7)).value == 4
        assert func(MNumber(3.14159), MNumber(2)).value == 3.14

    def test_list_sum(self):
        """List.Sum should sum numeric list."""
        func = get_builtin("List.Sum")
        result = func(MList([MNumber(1), MNumber(2), MNumber(3)]))

        assert result.value == 6

    def test_table_select_columns(self):
        """Table.SelectColumns should select specified columns."""
        func = get_builtin("Table.SelectColumns")

        df = pl.DataFrame({"A": [1, 2], "B": [3, 4], "C": [5, 6]})
        table = MTable.from_polars(df)

        result = func(table, MList([MText("A"), MText("C")]))

        assert isinstance(result, MTable)
        assert result.column_names == ["A", "C"]

    def test_table_skip(self):
        """Table.Skip should skip first N rows."""
        func = get_builtin("Table.Skip")

        df = pl.DataFrame({"A": [1, 2, 3, 4, 5]})
        table = MTable.from_polars(df)

        result = func(table, MNumber(2))

        assert isinstance(result, MTable)
        assert len(result) == 3
        assert result.to_pandas()["A"].tolist() == [3, 4, 5]

    def test_list_distinct(self):
        """List.Distinct should return unique values preserving order."""
        func = get_builtin("List.Distinct")

        result = func(MList([MNumber(1), MNumber(2), MNumber(2), MNumber(3), MNumber(1)]))

        assert isinstance(result, MList)
        assert len(result) == 3
        assert [item.value for item in result.items] == [1, 2, 3]

    def test_list_distinct_with_strings(self):
        """List.Distinct should work with string values."""
        func = get_builtin("List.Distinct")

        result = func(MList([MText("a"), MText("b"), MText("a"), MText("c")]))

        assert isinstance(result, MList)
        assert len(result) == 3
        assert [item.value for item in result.items] == ["a", "b", "c"]

    def test_table_fill_down(self):
        """Table.FillDown should fill null values forward."""
        func = get_builtin("Table.FillDown")

        df = pl.DataFrame({"Category": ["A", None, None, "B"], "Value": [1, 2, 3, 4]})
        table = MTable.from_polars(df)

        result = func(table, MList([MText("Category")]))

        assert isinstance(result, MTable)
        result_df = result.to_pandas()
        assert result_df["Category"].tolist() == ["A", "A", "A", "B"]

    def test_date_constructor(self):
        """#date should construct a date from year, month, day."""
        from datetime import date
        from python_m.runtime.values import MDate

        func = get_builtin("#date")

        result = func(MNumber(2024), MNumber(6), MNumber(15))

        assert isinstance(result, MDate)
        assert result.value == date(2024, 6, 15)

    def test_date_month(self):
        """Date.Month should extract month from date."""
        from datetime import date
        from python_m.runtime.values import MDate

        func = get_builtin("Date.Month")

        result = func(MDate(date(2024, 6, 15)))

        assert isinstance(result, MNumber)
        assert result.value == 6

    def test_date_day(self):
        """Date.Day should extract day from date."""
        from datetime import date
        from python_m.runtime.values import MDate

        func = get_builtin("Date.Day")

        result = func(MDate(date(2024, 6, 15)))

        assert isinstance(result, MNumber)
        assert result.value == 15

    def test_date_year(self):
        """Date.Year should extract year from date."""
        from datetime import date
        from python_m.runtime.values import MDate

        func = get_builtin("Date.Year")

        result = func(MDate(date(2024, 6, 15)))

        assert isinstance(result, MNumber)
        assert result.value == 2024

    def test_table_transform_column_types(self):
        """Table.TransformColumnTypes should return table (passthrough stub)."""
        func = get_builtin("Table.TransformColumnTypes")

        df = pl.DataFrame({"A": [1, 2, 3], "B": ["x", "y", "z"]})
        table = MTable.from_polars(df)
        transforms = MList([
            MList([MText("A"), MText("number")]),
            MList([MText("B"), MText("text")])
        ])

        result = func(table, transforms)

        assert isinstance(result, MTable)
        # Currently passthrough, so same data
        assert len(result) == 3

    def test_table_unpivot_other_columns(self):
        """Table.UnpivotOtherColumns should unpivot columns."""
        func = get_builtin("Table.UnpivotOtherColumns")

        df = pl.DataFrame({
            "Product": ["A", "B"],
            "Jan": [100, 80],
            "Feb": [150, 90]
        })
        table = MTable.from_polars(df)

        result = func(
            table,
            MList([MText("Product")]),
            MText("Month"),
            MText("Sales")
        )

        assert isinstance(result, MTable)
        assert len(result) == 4  # 2 products x 2 months
        assert "Month" in result.column_names
        assert "Sales" in result.column_names

    def test_table_pivot(self):
        """Table.Pivot should pivot table."""
        func = get_builtin("Table.Pivot")

        df = pl.DataFrame({
            "Product": ["A", "A", "B", "B"],
            "Region": ["East", "West", "East", "West"],
            "Sales": [100, 150, 80, 90]
        })
        table = MTable.from_polars(df)

        result = func(
            table,
            MText("Region"),
            MText("Sales"),
            MFunction("List.Sum", None, None)  # Aggregation function
        )

        assert isinstance(result, MTable)
        assert "East" in result.column_names
        assert "West" in result.column_names


class TestEvaluator:
    """Tests for the M code evaluator."""

    def test_evaluate_string_literal(self):
        """Evaluator should handle string literals."""
        # Parser requires let...in structure, so wrap the literal
        result = evaluate('let x = "hello" in x')

        assert isinstance(result, MText)
        assert result.value == "hello"

    def test_evaluate_let_expression(self):
        """Evaluator should handle let expressions."""
        result = evaluate('''
            let
                x = "hello"
            in
                x
        ''')

        assert isinstance(result, MText)
        assert result.value == "hello"

    def test_evaluate_forward_reference(self):
        """Evaluator should support forward references in let."""
        # Note: This requires number literals and addition in the parser
        # For now, test with string concatenation if available
        # or just test variable reference order
        result = evaluate('''
            let
                A = B,
                B = "value"
            in
                A
        ''')

        assert isinstance(result, MText)
        assert result.value == "value"

    def test_evaluate_with_context(self):
        """evaluate_with_context should inject variables."""
        df = pl.DataFrame({"X": [1, 2, 3]})

        result = evaluate_with_context('''
            let
                Result = Input
            in
                Result
        ''', {"Input": df})

        assert isinstance(result, MTable)
        assert "X" in result.column_names


class TestEvaluatorTableOperations:
    """Tests for evaluator Table.AddColumn and Table.SelectRows."""

    def test_evaluate_table_add_column_simple(self):
        """Evaluator should handle Table.AddColumn with simple expression."""
        df = pl.DataFrame({"A": [1, 2, 3], "B": [10, 20, 30]})

        result = evaluate_with_context('''
            let
                Result = Table.AddColumn(Input, "C", each [A] * 2)
            in
                Result
        ''', {"Input": df})

        assert isinstance(result, MTable)
        assert "C" in result.column_names
        result_df = result.to_pandas()
        assert list(result_df["C"]) == [2, 4, 6]

    def test_evaluate_table_add_column_arithmetic(self):
        """Evaluator should handle Table.AddColumn with complex arithmetic."""
        df = pl.DataFrame({"Price": [100, 200], "Qty": [2, 3]})

        result = evaluate_with_context('''
            let
                Result = Table.AddColumn(Input, "Total", each [Price] * [Qty])
            in
                Result
        ''', {"Input": df})

        assert isinstance(result, MTable)
        result_df = result.to_pandas()
        assert list(result_df["Total"]) == [200, 600]

    def test_evaluate_table_add_column_concatenation(self):
        """Evaluator should handle Table.AddColumn with text concatenation."""
        df = pl.DataFrame({"First": ["John", "Jane"], "Last": ["Doe", "Smith"]})

        result = evaluate_with_context('''
            let
                Result = Table.AddColumn(Input, "FullName", each [First] & " " & [Last])
            in
                Result
        ''', {"Input": df})

        assert isinstance(result, MTable)
        result_df = result.to_pandas()
        assert list(result_df["FullName"]) == ["John Doe", "Jane Smith"]

    def test_evaluate_table_select_rows_simple(self):
        """Evaluator should handle Table.SelectRows with comparison."""
        df = pl.DataFrame({"Value": [50, 100, 150, 200]})

        result = evaluate_with_context('''
            let
                Result = Table.SelectRows(Input, each [Value] > 100)
            in
                Result
        ''', {"Input": df})

        assert isinstance(result, MTable)
        result_df = result.to_pandas()
        assert len(result_df) == 2
        assert list(result_df["Value"]) == [150, 200]

    def test_evaluate_table_select_rows_equality(self):
        """Evaluator should handle Table.SelectRows with equality check."""
        df = pl.DataFrame({"Status": ["active", "inactive", "active"]})

        result = evaluate_with_context('''
            let
                Result = Table.SelectRows(Input, each [Status] = "active")
            in
                Result
        ''', {"Input": df})

        assert isinstance(result, MTable)
        result_df = result.to_pandas()
        assert len(result_df) == 2

    def test_evaluate_table_select_rows_empty_result(self):
        """Evaluator should handle Table.SelectRows that returns empty table."""
        df = pl.DataFrame({"Value": [1, 2, 3]})

        result = evaluate_with_context('''
            let
                Result = Table.SelectRows(Input, each [Value] > 100)
            in
                Result
        ''', {"Input": df})

        assert isinstance(result, MTable)
        result_df = result.to_pandas()
        assert len(result_df) == 0

    def test_evaluate_arithmetic_expression(self):
        """Evaluator should handle arithmetic in binary expressions."""
        result = evaluate('''
            let
                x = 10 + 5 * 2
            in
                x
        ''')

        assert isinstance(result, MNumber)
        assert result.value == 20  # 10 + (5 * 2) = 20

    def test_evaluate_text_concatenation(self):
        """Evaluator should handle text concatenation."""
        result = evaluate('''
            let
                x = "Hello" & " " & "World"
            in
                x
        ''')

        assert isinstance(result, MText)
        assert result.value == "Hello World"


class TestRuntimeVsTranspiler:
    """Tests comparing runtime and transpiler output."""

    def test_csv_read_produces_table(self):
        """Both runtime and transpiler should produce tables from CSV."""
        # Create a test CSV file
        import tempfile
        import os

        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            f.write("A,B\n1,x\n2,y\n")
            csv_path = f.name

        try:
            # Use forward slashes for M code
            m_path = csv_path.replace('\\', '/')
            m_code = f'''
                let
                    Source = Csv.Document(File.Contents("{m_path}"))
                in
                    Source
            '''

            # Runtime execution
            result = evaluate(m_code)

            assert isinstance(result, MTable)
            assert "A" in result.column_names
            assert "B" in result.column_names

            # Verify data
            df = result.to_pandas()
            assert len(df) == 2
        finally:
            os.unlink(csv_path)

class TestCoalesceAndDuration:
    """Tests for null coalesce operator and duration type."""

    def test_coalesce_null_returns_right(self):
        """Null coalesce should return right operand when left is null."""
        result = evaluate('let x = null ?? 1 in x')

        assert isinstance(result, MNumber)
        assert result.value == 1

    def test_coalesce_non_null_returns_left(self):
        """Null coalesce should return left operand when not null."""
        result = evaluate('let x = 42 ?? 1 in x')

        assert isinstance(result, MNumber)
        assert result.value == 42

    def test_coalesce_chained(self):
        """Null coalesce can be chained."""
        result = evaluate('let x = null ?? null ?? "default" in x')

        assert isinstance(result, MText)
        assert result.value == "default"

    def test_coalesce_short_circuit(self):
        """Null coalesce should short-circuit evaluation."""
        # If left is not null, right should not be evaluated
        # This tests that we don't get an error from the right side
        result = evaluate('let x = 1 ?? (1/0) in x')

        assert isinstance(result, MNumber)
        assert result.value == 1

    def test_duration_constructor(self):
        """#duration should construct a duration value."""
        from datetime import timedelta
        from python_m.runtime.values import MDuration

        func = get_builtin("#duration")
        result = func(MNumber(1), MNumber(2), MNumber(30), MNumber(0))

        assert isinstance(result, MDuration)
        assert result.value == timedelta(days=1, hours=2, minutes=30)

    def test_duration_in_expression(self):
        """Duration should work in expressions."""
        from python_m.runtime.values import MDuration

        result = evaluate('let d = #duration(1, 0, 0, 0) in d')

        assert isinstance(result, MDuration)
        assert result.value.days == 1

    def test_coalesce_with_duration(self):
        """Coalesce should work with duration values."""
        from python_m.runtime.values import MDuration

        # Duration is not null, so should return duration
        result = evaluate('let x = #duration(1, 0, 0, 0) ?? 1 in x')

        assert isinstance(result, MDuration)
        assert result.value.days == 1

    def test_empty_quoted_identifier(self):
        """Empty quoted identifier #'' should work as a variable name."""
        result = evaluate('let #"" = 42 in #""')

        assert isinstance(result, MNumber)
        assert result.value == 42

    def test_empty_quoted_identifier_with_coalesce(self):
        """The original user example: #'' with coalesce and duration."""
        from python_m.runtime.values import MNumber

        result = evaluate('''
            let
                #"" = #duration(1,0,0,0) ?? 1
            in
                #""
        ''')

        # Duration is not null, so coalesce returns the duration
        from python_m.runtime.values import MDuration
        assert isinstance(result, MDuration)
        assert result.value.days == 1
