"""Unit tests for the M code lexer."""

import pytest
from python_m.parser.lexer import Lexer, Token, TokenType


class TestLexer:
    """Tests for the Lexer class."""

    def test_tokenize_simple_let_expression(self):
        """Test tokenizing a simple let expression."""
        source = "let Source = Csv.Document(File.Contents(\"input.csv\")) in Source"
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        # Remove EOF for easier assertions
        tokens = [t for t in tokens if t.type != TokenType.EOF]

        # Verify token types in order
        expected_types = [
            TokenType.LET,        # let
            TokenType.IDENTIFIER, # Source
            TokenType.EQUALS,     # =
            TokenType.IDENTIFIER, # Csv
            TokenType.DOT,        # .
            TokenType.IDENTIFIER, # Document
            TokenType.LPAREN,     # (
            TokenType.IDENTIFIER, # File
            TokenType.DOT,        # .
            TokenType.IDENTIFIER, # Contents
            TokenType.LPAREN,     # (
            TokenType.STRING,     # "input.csv"
            TokenType.RPAREN,     # )
            TokenType.RPAREN,     # )
            TokenType.IN,         # in
            TokenType.IDENTIFIER, # Source
        ]

        assert len(tokens) == len(expected_types), f"Expected {len(expected_types)} tokens, got {len(tokens)}"

        for i, (token, expected_type) in enumerate(zip(tokens, expected_types)):
            assert token.type == expected_type, f"Token {i}: expected {expected_type}, got {token.type}"

    def test_tokenize_keywords(self):
        """Test that 'let' and 'in' are recognized as keywords."""
        lexer = Lexer("let in")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.LET
        assert tokens[0].value == "let"
        assert tokens[1].type == TokenType.IN
        assert tokens[1].value == "in"

    def test_tokenize_string_literal(self):
        """Test tokenizing a string literal."""
        lexer = Lexer('"hello world"')
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.STRING
        assert tokens[0].value == "hello world"

    def test_tokenize_identifier(self):
        """Test tokenizing identifiers."""
        lexer = Lexer("Source MyVar _private")
        tokens = lexer.tokenize()

        identifiers = [t for t in tokens if t.type == TokenType.IDENTIFIER]
        assert len(identifiers) == 3
        assert identifiers[0].value == "Source"
        assert identifiers[1].value == "MyVar"
        assert identifiers[2].value == "_private"

    def test_tokenize_punctuation(self):
        """Test tokenizing punctuation marks."""
        lexer = Lexer("().,=")
        tokens = lexer.tokenize()

        expected = [
            TokenType.LPAREN,
            TokenType.RPAREN,
            TokenType.DOT,
            TokenType.COMMA,
            TokenType.EQUALS,
            TokenType.EOF,
        ]

        for token, expected_type in zip(tokens, expected):
            assert token.type == expected_type

    def test_tokenize_with_line_numbers(self):
        """Test that line numbers are tracked correctly."""
        source = """let
    Source = x
in
    Source"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        # 'let' should be on line 1
        assert tokens[0].line == 1

        # 'Source' (first occurrence) should be on line 2
        source_token = next(t for t in tokens if t.value == "Source")
        assert source_token.line == 2

        # 'in' should be on line 3
        in_token = next(t for t in tokens if t.type == TokenType.IN)
        assert in_token.line == 3

    def test_tokenize_skips_whitespace(self):
        """Test that whitespace is properly skipped."""
        lexer = Lexer("   let   x   =   1   ")
        tokens = lexer.tokenize()

        # Should not have any whitespace tokens
        for token in tokens:
            assert token.value.strip() == token.value or token.type == TokenType.EOF

    def test_tokenize_empty_string(self):
        """Test tokenizing an empty string."""
        lexer = Lexer("")
        tokens = lexer.tokenize()

        assert len(tokens) == 1
        assert tokens[0].type == TokenType.EOF

    def test_tokenize_ends_with_eof(self):
        """Test that token list always ends with EOF."""
        lexer = Lexer("let x = 1 in x")
        tokens = lexer.tokenize()

        assert tokens[-1].type == TokenType.EOF

    # =========================================================================
    # Tests for list literals (ea15077)
    # =========================================================================

    def test_tokenize_list_literal_braces(self):
        """Test tokenizing list literal braces."""
        lexer = Lexer('{"a", "b"}')
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.LBRACE
        assert tokens[1].type == TokenType.STRING
        assert tokens[2].type == TokenType.COMMA
        assert tokens[3].type == TokenType.STRING
        assert tokens[4].type == TokenType.RBRACE

    def test_tokenize_nested_list_literals(self):
        """Test tokenizing nested list literals."""
        lexer = Lexer('{{"a", "b"}, {"c", "d"}}')
        tokens = lexer.tokenize()

        brace_tokens = [t for t in tokens if t.type in (TokenType.LBRACE, TokenType.RBRACE)]
        assert len(brace_tokens) == 6  # 3 opens + 3 closes

    # =========================================================================
    # Tests for each/field access/comparisons (fedd02b)
    # =========================================================================

    def test_tokenize_each_keyword(self):
        """Test that 'each' is recognized as a keyword."""
        lexer = Lexer("each [value] > 100")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.EACH
        assert tokens[0].value == "each"

    def test_tokenize_number_literal_integer(self):
        """Test tokenizing integer number literals."""
        lexer = Lexer("100")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.NUMBER
        assert tokens[0].value == "100"

    def test_tokenize_number_literal_decimal(self):
        """Test tokenizing decimal number literals."""
        lexer = Lexer("3.14")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.NUMBER
        assert tokens[0].value == "3.14"

    def test_tokenize_field_access_brackets(self):
        """Test tokenizing field access brackets."""
        lexer = Lexer("[FieldName]")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.LBRACKET
        assert tokens[1].type == TokenType.IDENTIFIER
        assert tokens[1].value == "FieldName"
        assert tokens[2].type == TokenType.RBRACKET

    def test_tokenize_comparison_operators(self):
        """Test tokenizing comparison operators."""
        test_cases = [
            (">", TokenType.GT),
            ("<", TokenType.LT),
            (">=", TokenType.GTE),
            ("<=", TokenType.LTE),
            ("<>", TokenType.NEQ),
        ]

        for op_str, expected_type in test_cases:
            lexer = Lexer(op_str)
            tokens = lexer.tokenize()
            assert tokens[0].type == expected_type, f"Expected {expected_type} for '{op_str}'"
            assert tokens[0].value == op_str

    def test_tokenize_each_expression_complete(self):
        """Test tokenizing a complete each expression."""
        lexer = Lexer("each [value] > 100")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        expected = [
            (TokenType.EACH, "each"),
            (TokenType.LBRACKET, "["),
            (TokenType.IDENTIFIER, "value"),
            (TokenType.RBRACKET, "]"),
            (TokenType.GT, ">"),
            (TokenType.NUMBER, "100"),
        ]

        assert len(tokens) == len(expected)
        for token, (exp_type, exp_value) in zip(tokens, expected):
            assert token.type == exp_type
            assert token.value == exp_value

    # =========================================================================
    # Tests for comments (008-comments)
    # =========================================================================

    def test_tokenize_line_comment(self):
        """Test tokenizing line comments."""
        lexer = Lexer("// This is a comment\nlet")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.COMMENT
        assert tokens[0].value == "This is a comment"
        assert tokens[1].type == TokenType.LET

    def test_tokenize_block_comment(self):
        """Test tokenizing block comments."""
        lexer = Lexer("/* Block comment */ let")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.COMMENT
        assert tokens[0].value == "Block comment"
        assert tokens[1].type == TokenType.LET

    def test_tokenize_multiple_comments(self):
        """Test tokenizing multiple comments."""
        source = """// First comment
        // Second comment
        let"""
        lexer = Lexer(source)
        tokens = lexer.tokenize()

        comment_tokens = [t for t in tokens if t.type == TokenType.COMMENT]
        assert len(comment_tokens) == 2
        assert comment_tokens[0].value == "First comment"
        assert comment_tokens[1].value == "Second comment"

    # =========================================================================
    # Tests for text concatenation (009-add-column)
    # =========================================================================

    def test_tokenize_ampersand(self):
        """Test tokenizing ampersand operator."""
        lexer = Lexer('"a" & "b"')
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.STRING
        assert tokens[1].type == TokenType.AMPERSAND
        assert tokens[1].value == "&"
        assert tokens[2].type == TokenType.STRING

    def test_tokenize_chained_ampersand(self):
        """Test tokenizing chained ampersand operators."""
        lexer = Lexer('[A] & " " & [B]')
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        expected = [
            (TokenType.LBRACKET, "["),
            (TokenType.IDENTIFIER, "A"),
            (TokenType.RBRACKET, "]"),
            (TokenType.AMPERSAND, "&"),
            (TokenType.STRING, " "),
            (TokenType.AMPERSAND, "&"),
            (TokenType.LBRACKET, "["),
            (TokenType.IDENTIFIER, "B"),
            (TokenType.RBRACKET, "]"),
        ]

        assert len(tokens) == len(expected)
        for token, (exp_type, exp_value) in zip(tokens, expected):
            assert token.type == exp_type
            assert token.value == exp_value

    # =========================================================================
    # Tests for arithmetic operators (010-add-column-arithmetic)
    # =========================================================================

    def test_tokenize_arithmetic_operators(self):
        """Test tokenizing arithmetic operators."""
        test_cases = [
            ("+", TokenType.PLUS),
            ("-", TokenType.MINUS),
            ("*", TokenType.STAR),
            ("/", TokenType.SLASH),
        ]

        for op_str, expected_type in test_cases:
            lexer = Lexer(op_str)
            tokens = lexer.tokenize()
            assert tokens[0].type == expected_type, f"Expected {expected_type} for '{op_str}'"
            assert tokens[0].value == op_str

    def test_tokenize_arithmetic_expression(self):
        """Test tokenizing a complete arithmetic expression."""
        lexer = Lexer("[Price] * [Qty] - [Discount]")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        expected_types = [
            TokenType.LBRACKET, TokenType.IDENTIFIER, TokenType.RBRACKET,  # [Price]
            TokenType.STAR,  # *
            TokenType.LBRACKET, TokenType.IDENTIFIER, TokenType.RBRACKET,  # [Qty]
            TokenType.MINUS,  # -
            TokenType.LBRACKET, TokenType.IDENTIFIER, TokenType.RBRACKET,  # [Discount]
        ]

        assert len(tokens) == len(expected_types)
        for token, exp_type in zip(tokens, expected_types):
            assert token.type == exp_type

    # =========================================================================
    # Tests for quoted identifiers (014-quoted-identifier)
    # =========================================================================

    def test_tokenize_quoted_identifier(self):
        """Test tokenizing quoted identifier #\"Name\"."""
        lexer = Lexer('#"First Name"')
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.IDENTIFIER
        assert tokens[0].value == "First Name"

    def test_tokenize_quoted_identifier_with_special_chars(self):
        """Test tokenizing quoted identifier with special characters."""
        lexer = Lexer('#"Column (New)"')
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.IDENTIFIER
        assert tokens[0].value == "Column (New)"

    def test_tokenize_multiple_quoted_identifiers(self):
        """Test tokenizing multiple quoted identifiers in a list."""
        lexer = Lexer('{#"First Name", #"Last Name"}')
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        expected = [
            (TokenType.LBRACE, "{"),
            (TokenType.IDENTIFIER, "First Name"),
            (TokenType.COMMA, ","),
            (TokenType.IDENTIFIER, "Last Name"),
            (TokenType.RBRACE, "}"),
        ]

        assert len(tokens) == len(expected)
        for token, (exp_type, exp_value) in zip(tokens, expected):
            assert token.type == exp_type
            assert token.value == exp_value

    # =========================================================================
    # Tests for logical operators (015-not-operator, 016-logical-operators)
    # =========================================================================

    def test_tokenize_not_keyword(self):
        """Test that 'not' is recognized as a keyword."""
        lexer = Lexer("not [Active]")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.NOT
        assert tokens[0].value == "not"

    def test_tokenize_and_keyword(self):
        """Test that 'and' is recognized as a keyword."""
        lexer = Lexer("[A] and [B]")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        assert tokens[3].type == TokenType.AND
        assert tokens[3].value == "and"

    def test_tokenize_or_keyword(self):
        """Test that 'or' is recognized as a keyword."""
        lexer = Lexer("[A] or [B]")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        assert tokens[3].type == TokenType.OR
        assert tokens[3].value == "or"

    def test_tokenize_logical_expression(self):
        """Test tokenizing a complete logical expression."""
        lexer = Lexer("not [A] and [B] or [C]")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        expected_types = [
            TokenType.NOT,
            TokenType.LBRACKET, TokenType.IDENTIFIER, TokenType.RBRACKET,
            TokenType.AND,
            TokenType.LBRACKET, TokenType.IDENTIFIER, TokenType.RBRACKET,
            TokenType.OR,
            TokenType.LBRACKET, TokenType.IDENTIFIER, TokenType.RBRACKET,
        ]

        assert len(tokens) == len(expected_types)
        for token, exp_type in zip(tokens, expected_types):
            assert token.type == exp_type

    # =========================================================================
    # Tests for type checks (019-is-null)
    # =========================================================================

    def test_tokenize_is_keyword(self):
        """Test that 'is' is recognized as a keyword."""
        lexer = Lexer("[Value] is null")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        assert tokens[3].type == TokenType.IS
        assert tokens[3].value == "is"

    def test_tokenize_null_keyword(self):
        """Test that 'null' is recognized as a keyword."""
        lexer = Lexer("null")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.NULL
        assert tokens[0].value == "null"

    def test_tokenize_is_null_expression(self):
        """Test tokenizing 'is null' expression."""
        lexer = Lexer("[Value] is null")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        expected = [
            (TokenType.LBRACKET, "["),
            (TokenType.IDENTIFIER, "Value"),
            (TokenType.RBRACKET, "]"),
            (TokenType.IS, "is"),
            (TokenType.NULL, "null"),
        ]

        assert len(tokens) == len(expected)
        for token, (exp_type, exp_value) in zip(tokens, expected):
            assert token.type == exp_type
            assert token.value == exp_value

    # =========================================================================
    # Tests for if-then-else (020-if-then-else)
    # =========================================================================

    def test_tokenize_if_keyword(self):
        """Test that 'if' is recognized as a keyword."""
        lexer = Lexer("if [X] > 0 then 1 else 0")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.IF
        assert tokens[0].value == "if"

    def test_tokenize_then_keyword(self):
        """Test that 'then' is recognized as a keyword."""
        lexer = Lexer("if true then 1 else 0")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        then_token = [t for t in tokens if t.type == TokenType.THEN][0]
        assert then_token.value == "then"

    def test_tokenize_else_keyword(self):
        """Test that 'else' is recognized as a keyword."""
        lexer = Lexer("if true then 1 else 0")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        else_token = [t for t in tokens if t.type == TokenType.ELSE][0]
        assert else_token.value == "else"

    def test_tokenize_true_false_keywords(self):
        """Test that 'true' and 'false' are recognized as keywords."""
        lexer = Lexer("true false")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.TRUE
        assert tokens[0].value == "true"
        assert tokens[1].type == TokenType.FALSE
        assert tokens[1].value == "false"

    def test_tokenize_if_then_else_expression(self):
        """Test tokenizing a complete if-then-else expression."""
        lexer = Lexer("if [Score] >= 70 then \"Pass\" else \"Fail\"")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        expected_types = [
            TokenType.IF,
            TokenType.LBRACKET, TokenType.IDENTIFIER, TokenType.RBRACKET,
            TokenType.GTE,
            TokenType.NUMBER,
            TokenType.THEN,
            TokenType.STRING,
            TokenType.ELSE,
            TokenType.STRING,
        ]

        assert len(tokens) == len(expected_types)
        for token, exp_type in zip(tokens, expected_types):
            assert token.type == exp_type

    # =========================================================================
    # Tests for intrinsic identifiers (021-date-constructor)
    # =========================================================================

    def test_tokenize_intrinsic_date(self):
        """Test tokenizing #date intrinsic identifier."""
        lexer = Lexer("#date(2024, 1, 15)")
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        assert tokens[0].type == TokenType.IDENTIFIER
        assert tokens[0].value == "#date"
        assert tokens[1].type == TokenType.LPAREN

    def test_tokenize_intrinsic_time(self):
        """Test tokenizing #time intrinsic identifier."""
        lexer = Lexer("#time(12, 30, 0)")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.IDENTIFIER
        assert tokens[0].value == "#time"

    def test_tokenize_intrinsic_datetime(self):
        """Test tokenizing #datetime intrinsic identifier."""
        lexer = Lexer("#datetime(2024, 1, 15, 12, 30, 0)")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.IDENTIFIER
        assert tokens[0].value == "#datetime"

    # =========================================================================
    # Tests for type keyword (023-transform-column-types)
    # =========================================================================

    def test_tokenize_type_keyword(self):
        """Test tokenizing type keyword."""
        lexer = Lexer("type number")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.TYPE
        assert tokens[0].value == "type"
        assert tokens[1].type == TokenType.IDENTIFIER
        assert tokens[1].value == "number"

    def test_tokenize_type_text(self):
        """Test tokenizing type text expression."""
        lexer = Lexer("type text")
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.TYPE
        assert tokens[1].type == TokenType.IDENTIFIER
        assert tokens[1].value == "text"

    def test_tokenize_type_in_list(self):
        """Test tokenizing type expression within a list."""
        lexer = Lexer('{"Column", type number}')
        tokens = [t for t in lexer.tokenize() if t.type != TokenType.EOF]

        expected = [
            (TokenType.LBRACE, "{"),
            (TokenType.STRING, "Column"),
            (TokenType.COMMA, ","),
            (TokenType.TYPE, "type"),
            (TokenType.IDENTIFIER, "number"),
            (TokenType.RBRACE, "}"),
        ]

        assert len(tokens) == len(expected)
        for token, (exp_type, exp_value) in zip(tokens, expected):
            assert token.type == exp_type
            assert token.value == exp_value

    def test_tokenize_empty_quoted_identifier(self):
        """Test tokenizing empty quoted identifier #''."""
        lexer = Lexer('#""')
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.IDENTIFIER
        assert tokens[0].value == ""

    def test_tokenize_quoted_identifier_with_keyword(self):
        """Test tokenizing quoted identifier containing a keyword."""
        lexer = Lexer('#"let"')
        tokens = lexer.tokenize()

        assert tokens[0].type == TokenType.IDENTIFIER
        assert tokens[0].value == "let"
