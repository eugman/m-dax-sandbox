"""Pytest configuration and shared fixtures for dataflow transpiler tests."""

import os
from pathlib import Path
from dataclasses import dataclass
from typing import Optional

import pytest


@dataclass
class Fixture:
    """Represents a single test fixture with all required files."""

    name: str
    source_path: Path
    expected_path: Path
    input_csv_path: Path
    expected_output_path: Path
    expected_unfolded_path: Optional[Path] = None

    @property
    def source_code(self) -> str:
        """Read and return the M code source."""
        return self.source_path.read_text(encoding="utf-8")

    @property
    def expected_code(self) -> str:
        """Read and return the expected Python output (with query folding)."""
        return self.expected_path.read_text(encoding="utf-8")

    @property
    def expected_unfolded_code(self) -> Optional[str]:
        """Read and return the expected Python output without query folding."""
        if self.expected_unfolded_path and self.expected_unfolded_path.exists():
            return self.expected_unfolded_path.read_text(encoding="utf-8")
        return None

    @property
    def has_unfolded_variant(self) -> bool:
        """Check if this fixture has an unfolded variant."""
        return self.expected_unfolded_path is not None and self.expected_unfolded_path.exists()

    @property
    def input_csv(self) -> str:
        """Read and return the input CSV content."""
        return self.input_csv_path.read_text(encoding="utf-8")

    @property
    def expected_output_csv(self) -> str:
        """Read and return the expected output CSV content."""
        return self.expected_output_path.read_text(encoding="utf-8")


@dataclass
class FixtureResult:
    """Result of running a fixture test."""

    fixture: Fixture
    transpile_success: bool
    code_matches: bool
    execution_success: bool
    output_matches: bool
    error: Optional[str] = None
    generated_code: Optional[str] = None


def get_fixtures_dir() -> Path:
    """Get the path to the fixtures directory."""
    # Navigate from packages/python-m/tests/ to repo root, then to fixtures/m/
    tests_dir = Path(__file__).parent
    package_dir = tests_dir.parent
    packages_dir = package_dir.parent
    repo_root = packages_dir.parent
    return repo_root / "fixtures" / "m"


def find_fixture_by_slug(slug: str) -> str:
    """Find a fixture directory by its slug (name without numeric prefix).
    
    This allows tests to reference fixtures by slug (e.g., 'csv-read-simple')
    instead of full name (e.g., '081-csv-read-simple'), making tests robust
    to fixture renumbering.
    
    Args:
        slug: The fixture slug (e.g., 'csv-read-simple' or '081-csv-read-simple')
        
    Returns:
        The full fixture directory name
        
    Raises:
        FileNotFoundError: If no fixture matches the slug
    """
    fixtures_dir = get_fixtures_dir()
    
    # First try exact match
    if (fixtures_dir / slug).exists():
        return slug
    
    # Search for fixture ending with the slug
    for item in fixtures_dir.iterdir():
        if item.is_dir():
            # Match pattern: NNN-slug where NNN is digits
            parts = item.name.split('-', 1)
            if len(parts) == 2 and parts[0].isdigit() and parts[1] == slug:
                return item.name
    
    raise FileNotFoundError(f"No fixture found matching slug: {slug}")


def load_fixture(fixture_name: str) -> Fixture:
    """Load a fixture by name or slug from the fixtures directory.
    
    Args:
        fixture_name: Full fixture name (e.g., '081-csv-read-simple') or
                      slug (e.g., 'csv-read-simple')
    """
    fixtures_dir = get_fixtures_dir()
    
    # Support both full names and slugs
    full_name = find_fixture_by_slug(fixture_name)
    fixture_dir = fixtures_dir / full_name

    if not fixture_dir.exists():
        raise FileNotFoundError(f"Fixture directory not found: {fixture_dir}")

    source_path = fixture_dir / "source.pq"
    expected_path = fixture_dir / "expected.py"
    input_csv_path = fixture_dir / "input.csv"
    expected_output_path = fixture_dir / "expected_output.csv"
    expected_unfolded_path = fixture_dir / "expected_unfolded.py"

    # Validate all required files exist
    missing = []
    for path, name in [
        (source_path, "source.pq"),
        (expected_path, "expected.py"),
        (input_csv_path, "input.csv"),
        (expected_output_path, "expected_output.csv"),
    ]:
        if not path.exists():
            missing.append(name)

    if missing:
        raise FileNotFoundError(
            f"Fixture '{full_name}' is missing required files: {', '.join(missing)}"
        )

    return Fixture(
        name=full_name,
        source_path=source_path,
        expected_path=expected_path,
        input_csv_path=input_csv_path,
        expected_output_path=expected_output_path,
        expected_unfolded_path=expected_unfolded_path if expected_unfolded_path.exists() else None,
    )


def discover_fixtures() -> list[str]:
    """Discover all fixture names in the fixtures directory.
    
    Skips:
    - Fixtures starting with 'WIP-' (work in progress)
    - Runtime-only fixtures that lack required transpiler test files
      (expected.py, input.csv, expected_output.csv)
    """
    fixtures_dir = get_fixtures_dir()
    if not fixtures_dir.exists():
        return []

    fixtures = []
    for item in fixtures_dir.iterdir():
        if item.is_dir() and not item.name.startswith(".") and not item.name.startswith("WIP-"):
            # Check for required transpiler test files
            required_files = ["expected.py", "input.csv", "expected_output.csv"]
            has_all_files = all((item / f).exists() for f in required_files)
            if has_all_files:
                fixtures.append(item.name)

    return sorted(fixtures)


@pytest.fixture
def fixtures_dir() -> Path:
    """Provide the path to the fixtures directory."""
    return get_fixtures_dir()


@pytest.fixture(params=discover_fixtures() or ["001-csv-read-simple"])
def fixture_name(request) -> str:
    """Parametrize tests with all discovered fixture names."""
    return request.param


@pytest.fixture
def fixture(fixture_name: str) -> Fixture:
    """Load and provide a test fixture."""
    return load_fixture(fixture_name)
