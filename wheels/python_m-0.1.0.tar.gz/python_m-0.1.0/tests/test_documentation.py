"""Tests to ensure documentation coverage for M functions.

These tests scan fixture files to identify M functions in use,
then verify that each function has corresponding documentation.
"""

import re
from pathlib import Path

import pytest


def get_project_root() -> Path:
    """Get the project root directory (monorepo root)."""
    # Navigate from packages/python-m/tests/ to repo root
    tests_dir = Path(__file__).parent
    package_dir = tests_dir.parent
    packages_dir = package_dir.parent
    return packages_dir.parent


def get_fixtures_dir() -> Path:
    """Get the fixtures directory."""
    return get_project_root() / "fixtures" / "m"


def get_docs_dir() -> Path:
    """Get the M function documentation directory."""
    return get_project_root() / "docs" / "m-functions"


def extract_m_functions_from_source(source: str) -> set[str]:
    """Extract M function names from source code.

    Identifies patterns like:
    - Csv.Document(...)
    - File.Contents(...)
    - Table.SelectColumns(...)

    Args:
        source: M code source text

    Returns:
        Set of function names (e.g., {"Csv.Document", "File.Contents"})
    """
    # Pattern matches: Identifier.Identifier followed by (
    # This catches M's standard library functions which use dot notation
    pattern = r'\b([A-Z][a-zA-Z]*\.[A-Z][a-zA-Z]*)\s*\('

    matches = re.findall(pattern, source)
    return set(matches)


def get_all_fixture_functions() -> set[str]:
    """Scan all transpiler fixtures and extract unique M functions used.

    Only scans fixtures that have expected.py (transpiler fixtures),
    skipping runtime-only fixtures used by TypeScript tests.

    Returns:
        Set of all M function names found in transpiler fixture files
    """
    fixtures_dir = get_fixtures_dir()
    all_functions: set[str] = set()

    if not fixtures_dir.exists():
        return all_functions

    # Scan all .pq files in fixture directories that have expected.py
    for pq_file in fixtures_dir.glob("**/source.pq"):
        fixture_dir = pq_file.parent
        # Only include transpiler fixtures (those with expected.py)
        if not (fixture_dir / "expected.py").exists():
            continue
        source = pq_file.read_text(encoding="utf-8")
        functions = extract_m_functions_from_source(source)
        all_functions.update(functions)

    return all_functions


def get_documented_functions() -> set[str]:
    """Get list of functions that have documentation files.

    Returns:
        Set of function names that have .md files in docs/m-functions/
    """
    docs_dir = get_docs_dir()
    documented: set[str] = set()

    if not docs_dir.exists():
        return documented

    for md_file in docs_dir.glob("*.md"):
        # Skip README and other non-function files
        if md_file.stem.lower() in ("readme", "index", "_template"):
            continue
        # Function files are named like "Csv.Document.md"
        documented.add(md_file.stem)

    return documented


class TestDocumentationCoverage:
    """Tests for documentation coverage of M functions."""

    def test_docs_directory_exists(self):
        """Verify the documentation directory exists."""
        docs_dir = get_docs_dir()
        assert docs_dir.exists(), f"Documentation directory missing: {docs_dir}"

    def test_all_fixture_functions_documented(self):
        """Verify every M function used in fixtures has documentation."""
        fixture_functions = get_all_fixture_functions()
        documented_functions = get_documented_functions()

        missing_docs = fixture_functions - documented_functions

        assert not missing_docs, (
            f"The following M functions are used in fixtures but lack documentation:\n"
            f"{', '.join(sorted(missing_docs))}\n\n"
            f"Please create documentation files in docs/m-functions/ for each:\n"
            + "\n".join(f"  - docs/m-functions/{func}.md" for func in sorted(missing_docs))
        )

    def test_documented_functions_list(self):
        """Display all documented functions (informational)."""
        documented = get_documented_functions()

        # This test always passes - it's for visibility
        print(f"\nDocumented M functions ({len(documented)}):")
        for func in sorted(documented):
            print(f"  - {func}")

    def test_fixture_functions_list(self):
        """Display all functions used in fixtures (informational)."""
        functions = get_all_fixture_functions()

        # This test always passes - it's for visibility
        print(f"\nM functions used in fixtures ({len(functions)}):")
        for func in sorted(functions):
            print(f"  - {func}")


class TestDocumentationQuality:
    """Tests for documentation quality standards."""

    def test_each_doc_has_required_sections(self):
        """Verify each documentation file has required sections."""
        docs_dir = get_docs_dir()
        required_sections = [
            "## M Signature",
            "## Description",
            "## Pandas Equivalent",
            "## Implementation Notes",
        ]

        errors = []

        for md_file in docs_dir.glob("*.md"):
            if md_file.stem.lower() in ("readme", "index", "_template"):
                continue

            content = md_file.read_text(encoding="utf-8")

            missing = []
            for section in required_sections:
                if section not in content:
                    missing.append(section)

            if missing:
                errors.append(f"{md_file.name}: missing sections {missing}")

        assert not errors, (
            "Documentation files missing required sections:\n" +
            "\n".join(f"  - {e}" for e in errors)
        )

    def test_no_empty_doc_files(self):
        """Verify no documentation files are empty or stubs."""
        docs_dir = get_docs_dir()

        empty_files = []

        for md_file in docs_dir.glob("*.md"):
            if md_file.stem.lower() in ("readme", "index", "_template"):
                continue

            content = md_file.read_text(encoding="utf-8").strip()

            # Check for empty or minimal stub files
            if len(content) < 100:
                empty_files.append(md_file.name)

        assert not empty_files, (
            f"Documentation files appear to be stubs or empty:\n" +
            "\n".join(f"  - {f}" for f in empty_files)
        )

    def test_each_doc_has_ms_learn_reference(self):
        """Verify each doc file has a link to official Microsoft documentation."""
        docs_dir = get_docs_dir()

        missing_refs = []

        for md_file in docs_dir.glob("*.md"):
            if md_file.stem.lower() in ("readme", "index", "_template"):
                continue

            content = md_file.read_text(encoding="utf-8")

            # Check for References section with MS Learn link
            has_references = "## References" in content
            has_ms_link = "learn.microsoft.com/en-us/powerquery-m" in content

            if not has_references or not has_ms_link:
                missing_refs.append(md_file.name)

        assert not missing_refs, (
            "Documentation files missing MS Learn reference link:\n" +
            "\n".join(f"  - {f}" for f in missing_refs) +
            "\n\nEach doc should have:\n"
            "## References\n"
            "- [Microsoft Docs: FunctionName](https://learn.microsoft.com/en-us/powerquery-m/function-name)"
        )
