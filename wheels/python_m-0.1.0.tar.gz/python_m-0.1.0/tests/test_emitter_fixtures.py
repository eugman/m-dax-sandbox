"""
Pandas Emitter Fixture Tests

Tests that the Python pandas emitter generates code matching expected.py files.
This mirrors the TypeScript pandas-emitter.test.ts fixture testing approach.

Each fixture with an expected.py file is tested to ensure:
1. The transpiler successfully generates pandas code
2. The generated code matches the expected output exactly

This ensures parity between Python and TypeScript emitters.
"""

import os
from pathlib import Path
import pytest
from python_m.transpiler import transpile


# Find all fixtures with expected.py files
FIXTURES_DIR = Path(__file__).parent.parent.parent.parent / "fixtures" / "m"

# Fixtures with manually-written expected.py that transpiler can't yet generate
# These are marked as xfail to document what needs to be implemented
KNOWN_UNSUPPORTED_FIXTURES = {
    # Parser doesn't support "" escape syntax
    "001-double-quote-escape": "Parser doesn't support double-quote escape syntax",
    # Parser doesn't support escape sequences like \n, \t
    "002-character-escape-sequences": "Parser doesn't support character escape sequences",
    # Time/datetime/duration constructors need emitter implementation
    "004-time-constructor": "#time constructor not implemented in emitter",
    "005-datetime-constructor": "#datetime constructor not implemented in emitter",
    "006-datetimezone-constructor": "#datetimezone constructor not implemented in emitter",
    "175-duration-constructor": "#duration constructor not implemented in emitter",
    # Function expression syntax needs emitter implementation
    "051-function-expression": "Function expression syntax not implemented in emitter",
    "052-each-vs-function": "Each vs function syntax not implemented in emitter",
    "053-optional-params": "Optional parameters not implemented in emitter",
    "061-closure-capture": "Closure capture not implemented in emitter",
    "062-nested-closures": "Nested closures not implemented in emitter",
    "063-curried-functions": "Curried functions not implemented in emitter",
    "064-recursive-factorial": "Recursive functions not implemented in emitter",
    "065-mutually-recursive": "Mutually recursive functions not implemented in emitter",
    # Try expression needs emitter implementation
    "125-try-transform-filter": "Try expression not implemented in emitter",
    # Number.Abs/Sign in table context needs emitter implementation
    "152-number-abs-sign": "Number.Abs/Sign in table context not implemented",
    # Parser doesn't support typed function params
    "198-typed-function-params": "Parser doesn't support 'as type' syntax",
    # Complex Lakehouse navigation needs emitter implementation
    "201-section-lakehouse": "Complex Lakehouse section navigation not implemented",
}


def get_fixtures_with_expected():
    """Find all M fixtures that have expected.py files."""
    fixtures = []

    for fixture_dir in sorted(FIXTURES_DIR.iterdir()):
        if not fixture_dir.is_dir():
            continue

        expected_path = fixture_dir / "expected.py"
        source_path = fixture_dir / "source.pq"

        if expected_path.exists() and source_path.exists():
            fixtures.append((fixture_dir.name, source_path, expected_path))

    return fixtures


FIXTURES_WITH_EXPECTED = get_fixtures_with_expected()


class TestPandasEmitterFixtures:
    """Test pandas emitter against all fixtures with expected.py files."""

    @pytest.mark.parametrize("fixture_name,source_path,expected_path", FIXTURES_WITH_EXPECTED)
    def test_emits_correct_python(self, fixture_name, source_path, expected_path):
        """Test that emitter generates code matching expected.py."""
        # Mark known unsupported fixtures as expected failures
        if fixture_name in KNOWN_UNSUPPORTED_FIXTURES:
            pytest.xfail(KNOWN_UNSUPPORTED_FIXTURES[fixture_name])

        # Read source M code
        with open(source_path, 'r', encoding='utf-8') as f:
            source_code = f.read()

        # Read expected Python output
        with open(expected_path, 'r', encoding='utf-8') as f:
            expected_code = f.read().strip()

        # Transpile to pandas
        result = transpile(source_code, target="pandas")

        # Check transpilation succeeded
        assert result.success, f"Transpilation failed for {fixture_name}: {result.error}"

        # Normalize line endings for cross-platform compatibility
        actual_code = result.code.strip().replace('\r\n', '\n')
        expected_code = expected_code.replace('\r\n', '\n')

        # Compare generated code with expected
        assert actual_code == expected_code, (
            f"Emitter output doesn't match expected.py for {fixture_name}\n\n"
            f"Expected:\n{expected_code}\n\n"
            f"Actual:\n{actual_code}"
        )


def test_fixture_count():
    """Verify we're testing all fixtures with expected.py files."""
    # This test documents how many fixtures we're testing
    # Update this number as we add more expected.py files
    assert len(FIXTURES_WITH_EXPECTED) >= 110, (
        f"Expected at least 110 fixtures with expected.py, found {len(FIXTURES_WITH_EXPECTED)}"
    )
    supported_count = len(FIXTURES_WITH_EXPECTED) - len(KNOWN_UNSUPPORTED_FIXTURES)
    print(f"\nTesting {len(FIXTURES_WITH_EXPECTED)} fixtures with expected.py files")
    print(f"  - {supported_count} fully supported")
    print(f"  - {len(KNOWN_UNSUPPORTED_FIXTURES)} marked as xfail (pending implementation)")
