"""Thunk implementation for lazy evaluation with memoization.

A thunk is a delayed computation that packages:
1. An unevaluated expression (as a callable)
2. The environment needed to evaluate it (captured via closure)

M language uses call-by-need semantics for let expressions:
- Computation is deferred until the value is accessed
- Once computed, the result is cached (memoized)
- Subsequent accesses return the cached value

Example:
    # Create a thunk that defers computation
    thunk = Thunk(lambda: expensive_computation())

    # Nothing computed yet
    assert not thunk.is_evaluated

    # First access forces evaluation
    value = thunk.force()  # Computes and caches

    # Subsequent access returns cached value
    same_value = thunk.force()  # No recomputation

This enables M's forward reference capability:
    let
        A = B + 1,  // A references B before B is defined
        B = 1
    in
        A  // Works because B is evaluated when A is forced

References:
    - SICP 4.2.2: An Interpreter with Lazy Evaluation
    - M Language Spec: Evaluation Model
"""

from __future__ import annotations

from typing import Callable, Generic, Optional, TypeVar, TYPE_CHECKING

if TYPE_CHECKING:
    from python_m.runtime.values import MValue

T = TypeVar('T')
U = TypeVar('U')


class Thunk(Generic[T]):
    """A delayed computation with memoization (call-by-need).

    Thunks are the mechanism for implementing lazy evaluation in the M runtime.
    They wrap a zero-argument callable that produces a value when invoked.

    The callable typically captures its environment via Python's closure
    mechanism, which provides the "expression + environment" packaging
    that thunks require.

    Attributes:
        is_evaluated: Whether the thunk has been forced.

    Thread Safety:
        This implementation is NOT thread-safe. For concurrent access,
        external synchronization would be required.
    """

    __slots__ = ('_computation', '_value', '_evaluated', '_error')

    def __init__(self, computation: Callable[[], T]) -> None:
        """Create a thunk wrapping a deferred computation.

        Args:
            computation: A zero-argument callable that produces the value.
                The callable should be pure (no side effects) for correct
                memoization behavior. It captures its environment via closure.

        Example:
            # Capture 'x' from enclosing scope
            x = 10
            thunk = Thunk(lambda: x + 1)  # Closure captures x
        """
        self._computation: Optional[Callable[[], T]] = computation
        self._value: Optional[T] = None
        self._evaluated: bool = False
        self._error: Optional[Exception] = None

    def force(self) -> T:
        """Force evaluation of the thunk, returning the (possibly cached) value.

        On first call:
            1. Executes the stored computation
            2. Caches the result
            3. Releases the computation closure (memory optimization)
            4. Returns the result

        On subsequent calls:
            1. Returns the cached result immediately
            2. No recomputation occurs

        Returns:
            The computed value (type T).

        Raises:
            Exception: If the computation raises, the error is cached and
                re-raised on subsequent force() calls.

        Example:
            thunk = Thunk(lambda: 2 + 2)
            result = thunk.force()  # Returns 4, caches it
            again = thunk.force()   # Returns cached 4, no recomputation
        """
        if self._error is not None:
            # Re-raise cached error
            raise self._error

        if not self._evaluated:
            try:
                # Evaluate and cache
                self._value = self._computation()
                self._evaluated = True
            except Exception as e:
                # Cache the error for consistent behavior
                self._error = e
                self._evaluated = True
                raise
            finally:
                # Release the closure to free memory
                # This is important for long-lived thunks
                self._computation = None

        return self._value

    @property
    def is_evaluated(self) -> bool:
        """Check if this thunk has been forced.

        Returns:
            True if force() has been called (successfully or with error).
        """
        return self._evaluated

    @property
    def has_error(self) -> bool:
        """Check if this thunk's computation raised an error.

        Returns:
            True if force() was called and the computation raised.
        """
        return self._error is not None

    @staticmethod
    def eager(value: T) -> Thunk[T]:
        """Create a pre-evaluated thunk containing a known value.

        This is useful when you need a Thunk interface but already
        have the computed value (e.g., for literal values).

        Args:
            value: The value to wrap.

        Returns:
            A thunk that is already evaluated and will return the value.

        Example:
            # For a literal like "hello"
            thunk = Thunk.eager(MText("hello"))
            thunk.force()  # Returns MText("hello"), no computation
        """
        thunk: Thunk[T] = Thunk(lambda: value)  # Dummy computation
        thunk._value = value
        thunk._evaluated = True
        thunk._computation = None
        return thunk

    @staticmethod
    def from_value(value: T) -> Thunk[T]:
        """Alias for eager() - create thunk from existing value."""
        return Thunk.eager(value)

    def map(self, func: Callable[[T], 'U']) -> 'Thunk[U]':
        """Create a new thunk that applies a function to this thunk's value.

        The function is applied lazily - only when the new thunk is forced.

        Args:
            func: Function to apply to the value.

        Returns:
            A new thunk that will compute func(self.force()).

        Example:
            thunk = Thunk(lambda: 10)
            doubled = thunk.map(lambda x: x * 2)
            doubled.force()  # Returns 20
        """
        return Thunk(lambda: func(self.force()))

    def flat_map(self, func: Callable[[T], 'Thunk[U]']) -> 'Thunk[U]':
        """Create a thunk that applies a thunk-returning function.

        Useful for chaining thunk computations.

        Args:
            func: Function that takes T and returns Thunk[U].

        Returns:
            A thunk that will compute func(self.force()).force().
        """
        return Thunk(lambda: func(self.force()).force())

    def __repr__(self) -> str:
        """String representation showing evaluation state."""
        if self._error is not None:
            return f"Thunk(<error: {type(self._error).__name__}>)"
        if self._evaluated:
            return f"Thunk(<evaluated: {self._value!r}>)"
        return "Thunk(<unevaluated>)"


# Type alias for thunks containing M values
MThunk = Thunk['MValue']
