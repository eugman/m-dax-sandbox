"""M Language Runtime - Direct interpreter for Power Query M code.

This module provides a tree-walking interpreter that executes M code directly,
complementing the transpiler which generates Python code.

Key components:
- Thunk: Lazy evaluation with memoization (call-by-need)
- Environment: Lexical scoping for variable bindings
- MValue: M language value types (MTable, MText, MNumber, etc.)
- Evaluator: AST visitor that executes M code
- Builtins: Implementation of M standard library functions

Example:
    from python_m.runtime import evaluate

    result = evaluate('''
        let
            Source = Csv.Document(File.Contents("data.csv"))
        in
            Source
    ''')

    df = result.to_pandas()  # Get as pandas DataFrame
"""

from python_m.runtime.thunk import Thunk, MThunk
from python_m.runtime.environment import Environment, GlobalEnvironment
from python_m.runtime.values import (
    MValue,
    MNull,
    MText,
    MNumber,
    MLogical,
    MList,
    MRecord,
    MTable,
    MFunction,
    MBinary,
    MType,
    python_to_mvalue,
    mvalue_to_python,
)
from python_m.runtime.evaluator import Evaluator, evaluate, evaluate_with_context
from python_m.runtime.builtins import (
    get_builtin,
    has_builtin,
    list_builtins,
    register_builtins,
)

__all__ = [
    # Core
    "Thunk",
    "MThunk",
    "Environment",
    "GlobalEnvironment",
    "Evaluator",
    "evaluate",
    "evaluate_with_context",
    # Values
    "MValue",
    "MNull",
    "MText",
    "MNumber",
    "MLogical",
    "MList",
    "MRecord",
    "MTable",
    "MFunction",
    "MBinary",
    "MType",
    # Conversion
    "python_to_mvalue",
    "mvalue_to_python",
    # Builtins
    "get_builtin",
    "has_builtin",
    "list_builtins",
    "register_builtins",
]
