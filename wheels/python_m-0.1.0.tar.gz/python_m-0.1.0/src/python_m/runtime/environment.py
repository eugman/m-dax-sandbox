"""Environment implementation for lexical scoping.

The environment manages variable bindings during M code evaluation.
It implements lexical (static) scoping through a parent-pointer chain.

Key Features:
1. Lexical Scoping - Each environment has an optional parent
2. Lazy Bindings - Values are stored as Thunks for call-by-need
3. Forward References - M's let allows forward references within the same scope
4. Immutable Bindings - Once bound, variables cannot be reassigned

M's Scoping Rules:
- let expressions create new scopes
- Variables in a let can reference each other (forward references)
- Inner scopes shadow outer scopes
- Function bodies capture their defining environment (closures)

Example:
    # M code:
    let
        A = B + 1,  // Forward reference to B
        B = 10
    in
        A  // Returns 11

    # Environment structure:
    env = Environment()
    env.bind_lazy("A", lambda: env.get("B") + 1)
    env.bind_lazy("B", lambda: 10)
    env.get("A").force()  # Forces B first, then A

References:
    - SICP 3.2: The Environment Model of Evaluation
    - M Language Spec: Scoping and Evaluation
"""

from __future__ import annotations

from typing import Callable, Dict, Iterator, Optional, Set, TYPE_CHECKING

from python_m.runtime.thunk import Thunk

if TYPE_CHECKING:
    from python_m.runtime.values import MValue


class Environment:
    """Lexical environment for variable bindings.

    An environment is a mapping from names to thunks (lazy values).
    Each environment optionally links to a parent environment,
    forming a scope chain for lexical scoping.

    Thread Safety:
        This implementation is NOT thread-safe. For concurrent evaluation,
        external synchronization would be required.

    Attributes:
        parent: Optional parent environment for scope chain
    """

    __slots__ = ('_bindings', '_parent', '_name')

    def __init__(
        self,
        parent: Optional[Environment] = None,
        name: Optional[str] = None
    ) -> None:
        """Create a new environment.

        Args:
            parent: Optional parent environment for lexical scoping.
            name: Optional name for debugging (e.g., "let-scope", "function-body").
        """
        self._bindings: Dict[str, Thunk[MValue]] = {}
        self._parent: Optional[Environment] = parent
        self._name: Optional[str] = name

    @property
    def parent(self) -> Optional[Environment]:
        """Get the parent environment, if any."""
        return self._parent

    def bind(self, name: str, value: 'MValue') -> None:
        """Bind a name to an already-evaluated value.

        Creates an eager thunk wrapping the value.

        Args:
            name: Variable name to bind.
            value: The M value to bind.

        Raises:
            ValueError: If name is already bound in this scope.

        Example:
            env.bind("x", MNumber(42))
        """
        if name in self._bindings:
            raise ValueError(f"Variable '{name}' is already bound in this scope")
        self._bindings[name] = Thunk.eager(value)

    def bind_lazy(self, name: str, computation: Callable[[], 'MValue']) -> None:
        """Bind a name to a lazy computation (thunk).

        The computation is not executed until the value is accessed.
        This enables forward references within let expressions.

        Args:
            name: Variable name to bind.
            computation: Zero-argument callable that produces the value.

        Raises:
            ValueError: If name is already bound in this scope.

        Example:
            # Forward reference: A depends on B
            env.bind_lazy("A", lambda: env.get("B").force() + MNumber(1))
            env.bind_lazy("B", lambda: MNumber(10))
        """
        if name in self._bindings:
            raise ValueError(f"Variable '{name}' is already bound in this scope")
        self._bindings[name] = Thunk(computation)

    def bind_thunk(self, name: str, thunk: Thunk['MValue']) -> None:
        """Bind a name to an existing thunk.

        Args:
            name: Variable name to bind.
            thunk: The thunk to bind.

        Raises:
            ValueError: If name is already bound in this scope.
        """
        if name in self._bindings:
            raise ValueError(f"Variable '{name}' is already bound in this scope")
        self._bindings[name] = thunk

    def lookup(self, name: str) -> Optional[Thunk['MValue']]:
        """Look up a name in the scope chain, returning the thunk.

        Searches this environment, then parent environments.

        Args:
            name: Variable name to look up.

        Returns:
            The thunk bound to the name, or None if not found.

        Example:
            thunk = env.lookup("x")
            if thunk:
                value = thunk.force()
        """
        if name in self._bindings:
            return self._bindings[name]
        if self._parent is not None:
            return self._parent.lookup(name)
        return None

    def get(self, name: str) -> 'MValue':
        """Look up a name and force its thunk, returning the value.

        This is the primary method for accessing variable values.

        Args:
            name: Variable name to look up.

        Returns:
            The evaluated M value.

        Raises:
            NameError: If the name is not bound in any enclosing scope.

        Example:
            value = env.get("x")  # Returns MNumber(42)
        """
        thunk = self.lookup(name)
        if thunk is None:
            raise NameError(f"Undefined variable: '{name}'")
        return thunk.force()

    def is_bound(self, name: str) -> bool:
        """Check if a name is bound anywhere in the scope chain.

        Args:
            name: Variable name to check.

        Returns:
            True if bound in this or any parent environment.
        """
        return self.lookup(name) is not None

    def is_bound_locally(self, name: str) -> bool:
        """Check if a name is bound in this specific scope.

        Does not check parent scopes.

        Args:
            name: Variable name to check.

        Returns:
            True if bound in this environment (not parent).
        """
        return name in self._bindings

    def local_names(self) -> Set[str]:
        """Get all names bound in this scope (not parents).

        Returns:
            Set of variable names bound locally.
        """
        return set(self._bindings.keys())

    def all_names(self) -> Set[str]:
        """Get all names bound in the entire scope chain.

        Returns:
            Set of all accessible variable names.
        """
        names = set(self._bindings.keys())
        if self._parent is not None:
            names.update(self._parent.all_names())
        return names

    def extend(self, name: Optional[str] = None) -> Environment:
        """Create a new child environment with this as parent.

        Used when entering a new scope (let expression, function body, etc.)

        Args:
            name: Optional name for the new scope (debugging).

        Returns:
            New environment with this as parent.

        Example:
            inner_env = outer_env.extend("let-scope")
            inner_env.bind("x", MNumber(1))  # Shadows outer x
        """
        return Environment(parent=self, name=name)

    def __contains__(self, name: str) -> bool:
        """Support 'in' operator for checking binding."""
        return self.is_bound(name)

    def __iter__(self) -> Iterator[str]:
        """Iterate over locally bound names."""
        return iter(self._bindings.keys())

    def __repr__(self) -> str:
        """String representation showing bindings and scope chain."""
        local_names = list(self._bindings.keys())
        parent_info = f" -> {self._parent!r}" if self._parent else ""
        scope_name = f"'{self._name}'" if self._name else "anonymous"
        return f"Env({scope_name}: {local_names}{parent_info})"

    def debug_dump(self, indent: int = 0) -> str:
        """Generate a detailed debug representation of the scope chain.

        Args:
            indent: Indentation level for nested output.

        Returns:
            Multi-line string showing all bindings and their states.
        """
        prefix = "  " * indent
        lines = [f"{prefix}Environment({self._name or 'anonymous'}):"]

        for name, thunk in self._bindings.items():
            state = "evaluated" if thunk.is_evaluated else "unevaluated"
            if thunk.is_evaluated and not thunk.has_error:
                value = thunk.force()
                lines.append(f"{prefix}  {name} = {value!r} ({state})")
            elif thunk.has_error:
                lines.append(f"{prefix}  {name} = <error> ({state})")
            else:
                lines.append(f"{prefix}  {name} = <thunk> ({state})")

        if self._parent:
            lines.append(f"{prefix}  parent:")
            lines.append(self._parent.debug_dump(indent + 2))

        return "\n".join(lines)


class GlobalEnvironment(Environment):
    """The global/root environment containing built-in bindings.

    This environment has no parent and contains:
    - Built-in functions (Table.SelectColumns, etc.)
    - Standard library functions
    - Type constructors

    Typically created once and used as the root of all scope chains.

    Example:
        global_env = GlobalEnvironment()
        global_env.bind_builtin("Number.Round", round_function)

        # User code gets a child environment
        user_env = global_env.extend("user-program")
    """

    def __init__(self) -> None:
        """Create the global environment."""
        super().__init__(parent=None, name="global")
        self._builtin_functions: Dict[str, Callable] = {}

    def bind_builtin(self, name: str, func: Callable) -> None:
        """Register a built-in function.

        Built-in functions are stored both as thunks (for normal lookup)
        and in a separate registry (for introspection).

        Args:
            name: Function name (e.g., "Table.SelectColumns").
            func: The Python callable implementing the function.
        """
        from python_m.runtime.values import MFunction

        # Create MFunction wrapper
        # Note: Built-in functions don't capture closure - they're self-contained
        mfunc = MFunction(
            parameters=[],  # Will be determined at call time
            body=func,
            closure=None,
            name=name
        )
        self._builtin_functions[name] = func
        self.bind(name, mfunc)

    def get_builtin(self, name: str) -> Optional[Callable]:
        """Get a built-in function's raw Python callable.

        Args:
            name: Function name.

        Returns:
            The Python callable, or None if not found.
        """
        return self._builtin_functions.get(name)

    def list_builtins(self) -> Set[str]:
        """Get all registered built-in function names.

        Returns:
            Set of built-in function names.
        """
        return set(self._builtin_functions.keys())
