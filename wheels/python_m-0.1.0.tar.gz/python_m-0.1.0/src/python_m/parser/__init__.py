"""M code parser module - lexer and parser for Power Query M language."""

from typing import Optional

from python_m.parser.lexer import Lexer, Token, TokenType
from python_m.parser.parser import Parser, ParseResult
from python_m.ast.nodes import ASTNode


def parse(source: str) -> Optional[ASTNode]:
    """Parse M source code into an AST.

    Convenience function that combines lexing and parsing.

    Args:
        source: M source code string.

    Returns:
        The root AST node if parsing succeeds, None otherwise.

    Example:
        ast = parse("let x = 1 in x")
    """
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    result = parser.parse()

    if result.success and result.ast is not None:
        return result.ast
    return None


__all__ = ["Lexer", "Token", "TokenType", "Parser", "ParseResult", "parse"]
