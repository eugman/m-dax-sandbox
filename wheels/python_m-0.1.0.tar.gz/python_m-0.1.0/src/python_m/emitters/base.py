"""Base emitter interface for code generation.

This module defines the abstract base class for all code emitters
and the common result type.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

from python_m.ast.nodes import LetExpression


@dataclass
class LakehouseReference:
    """Reference to a Fabric lakehouse extracted from M code.

    Attributes:
        lakehouse_id: Lakehouse ID (GUID).
        workspace_id: Workspace ID (GUID).
        query_name: Name of the query that references this lakehouse.
        is_default_destination: True if this is the default destination lakehouse.
    """

    lakehouse_id: str
    workspace_id: str
    query_name: Optional[str] = None
    is_default_destination: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            'lakehouseId': self.lakehouse_id,
            'workspaceId': self.workspace_id,
            'queryName': self.query_name,
            'isDefaultDestination': self.is_default_destination,
        }


@dataclass
class EmitResult:
    """Result of code emission.

    Attributes:
        success: True if code generation succeeded.
        code: The generated code, or None if generation failed.
        warnings: List of non-fatal warnings encountered during emission.
        lakehouses: List of lakehouse references extracted from the M code.
    """

    success: bool
    code: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    lakehouses: List[LakehouseReference] = field(default_factory=list)


def python_only(reason: str):
    """Decorator to mark emitter methods as intentionally Python-only.

    This decorator is used to annotate emitter methods that should only exist
    in the Python implementation, not TypeScript. The parity checker will
    recognize and filter these out from the "missing" differences.

    Args:
        reason: Explanation of why this method is Python-only.

    Example:
        @python_only("Internal helper for compiling lambda expressions")
        def _emit_lambda_body(self, node: FunctionCall) -> str:
            ...
    """
    def decorator(func):
        func._python_only = True
        func._python_only_reason = reason
        return func
    return decorator


def typescript_only(reason: str):
    """Decorator to mark emitter methods as intentionally TypeScript-only.

    Note: This decorator is for documentation symmetry with @python_only.
    In TypeScript, use JSDoc comments instead:
        /**
         * @typescript_only Optimization for CSV query folding
         */

    Args:
        reason: Explanation of why this method is TypeScript-only.
    """
    def decorator(func):
        func._typescript_only = True
        func._typescript_only_reason = reason
        return func
    return decorator


class BaseEmitter(ABC):
    """Abstract base class for code emitters.

    Emitters transform an AST into code for a specific target platform
    (e.g., Pandas, PySpark, Fabric pipelines).

    Subclasses must implement the emit() method to generate code
    for their target platform.
    """

    @abstractmethod
    def emit(self, ast: LetExpression) -> EmitResult:
        """Generate code from an AST.

        Args:
            ast: The root LetExpression node of the AST.

        Returns:
            EmitResult containing success status, generated code, and warnings.
        """
        pass
