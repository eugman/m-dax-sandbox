"""Main transpiler module - orchestrates parsing and code emission.

This module provides the main entry point for transpiling M code
to various target formats.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

from python_m.parser.lexer import Lexer
from python_m.parser.parser import Parser, ParseResult
from python_m.ast.nodes import LetExpression
from python_m.emitters.base import EmitResult, LakehouseReference
from python_m.emitters.pandas_emitter import PandasEmitter


@dataclass
class TranspileResult:
    """Result of transpiling M code.

    Attributes:
        success: True if transpilation succeeded.
        code: The generated code, or None if transpilation failed.
        error: Error message if transpilation failed.
        warnings: List of non-fatal warnings.
        lakehouses: List of lakehouse references extracted from the M code.
        ast: The parsed AST (for debugging), or None if parsing failed.
    """

    success: bool
    code: Optional[str] = None
    error: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    lakehouses: List[LakehouseReference] = field(default_factory=list)
    ast: Optional[LetExpression] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            'success': self.success,
            'code': self.code,
            'error': self.error,
            'warnings': self.warnings,
            'lakehouses': [lh.to_dict() for lh in self.lakehouses] if self.lakehouses else [],
        }


def transpile(
    source: str,
    target: str = "pandas",
    fold_queries: bool = True,
    explicit_steps: bool = False,
    lakehouse_mode: str = "fabric",
) -> TranspileResult:
    """Transpile M code to the specified target format.

    This is the main entry point for the transpiler. It parses the
    M code source and generates equivalent code for the target platform.

    Args:
        source: The M code source text to transpile.
        target: The output target format. Currently supported:
            - "pandas" (default): Generate Pandas Python code
        fold_queries: If True (default), optimize away intermediate NOP steps
            (e.g., Step1 = Source becomes folded out). If False, emit all
            intermediate variable assignments.
        explicit_steps: If True, disable ALL optimizations and query folding.
            Each M step will map to one pandas DataFrame operation for debugging.
            This overrides fold_queries to False and disables step combining.
            Useful for understanding what each M transformation does.
        lakehouse_mode: How to handle Lakehouse.Contents patterns:
            - "fabric" (default): Generate Fabric notebook paths (/lakehouse/default/Files/...)
            - "spark": Generate Spark DataFrame reads with .toPandas()
            - "fixture": Generate fixture paths for testing (fixtures/...)

    Returns:
        TranspileResult containing success status, generated code,
        error messages, warnings, and the parsed AST.

    Example:
        result = transpile('''
            let
                Source = Csv.Document(File.Contents("data.csv"))
            in
                Source
        ''')
        if result.success:
            print(result.code)
        else:
            print(f"Error: {result.error}")
    """
    # Validate target
    supported_targets = {"pandas"}
    if target not in supported_targets:
        return TranspileResult(
            success=False,
            error=f"Unsupported target '{target}'. Supported targets: {', '.join(sorted(supported_targets))}",
        )

    # Validate input
    if not source or not source.strip():
        return TranspileResult(
            success=False,
            error="Empty source code provided",
        )

    # Tokenize
    try:
        lexer = Lexer(source)
        tokens = lexer.tokenize()
    except Exception as e:
        return TranspileResult(
            success=False,
            error=f"Lexer error: {e}",
        )

    # Parse
    try:
        parser = Parser(tokens)
        parse_result: ParseResult = parser.parse()
    except Exception as e:
        return TranspileResult(
            success=False,
            error=f"Parser error: {e}",
        )

    if not parse_result.success or parse_result.ast is None:
        error_messages = [
            f"Line {e.line}:{e.column}: {e.message}"
            for e in parse_result.errors
        ]
        return TranspileResult(
            success=False,
            error="Parse errors:\n" + "\n".join(error_messages) if error_messages else "Failed to parse M code",
        )

    # Emit code
    # Note: target is already validated above, so we can assume it's valid here
    try:
        # explicit_steps overrides fold_queries
        if explicit_steps:
            fold_queries = False

        if target == "pandas":
            emitter = PandasEmitter(
                fold_queries=fold_queries,
                explicit_steps=explicit_steps,
                lakehouse_mode=lakehouse_mode
            )
        # Add more targets here as they are implemented
        # elif target == "pyspark":
        #     emitter = PySparkEmitter(fold_queries=fold_queries, lakehouse_mode=lakehouse_mode)

        emit_result: EmitResult = emitter.emit(parse_result.ast)
    except Exception as e:
        return TranspileResult(
            success=False,
            error=f"Emitter error: {e}",
            ast=parse_result.ast,
        )

    if not emit_result.success:
        return TranspileResult(
            success=False,
            error="Code generation failed",
            warnings=emit_result.warnings,
            ast=parse_result.ast,
        )

    return TranspileResult(
        success=True,
        code=emit_result.code,
        warnings=emit_result.warnings,
        lakehouses=emit_result.lakehouses,
        ast=parse_result.ast,
    )
