#!/usr/bin/env python3
"""Generate function registry from actual implemented functions.

This script scans the pandas emitter to find all implemented functions
and generates an accurate registry. It can also fetch the full list
of M functions from the Power Query documentation.

Usage:
    python generate_function_registry.py --scan      # Scan emitter for implemented
    python generate_function_registry.py --verify    # Verify registry accuracy
    python generate_function_registry.py --stats     # Show implementation stats
    python generate_function_registry.py --fetch     # Fetch function list from docs
    python generate_function_registry.py --coverage  # Show coverage by category
"""

import argparse
import re
import sys
from pathlib import Path
from typing import Set, Dict, List, Optional

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Known M function categories from Microsoft docs
# https://learn.microsoft.com/en-us/powerquery-m/power-query-m-function-reference
M_FUNCTION_CATEGORIES = {
    "Accessing data": "accessing-data-functions",
    "Binary": "binary-functions",
    "Combiner": "combiner-functions",
    "Comparer": "comparer-functions",
    "Date": "date-functions",
    "DateTime": "datetime-functions",
    "DateTimeZone": "datetimezone-functions",
    "Duration": "duration-functions",
    "Error": "error-handling",
    "Expression": "expression-functions",
    "Function": "function-values",
    "List": "list-functions",
    "Lines": "lines-functions",
    "Logical": "logical-functions",
    "Number": "number-functions",
    "Record": "record-functions",
    "Replacer": "replacer-functions",
    "Splitter": "splitter-functions",
    "Table": "table-functions",
    "Text": "text-functions",
    "Time": "time-functions",
    "Type": "type-functions",
    "Uri": "uri-functions",
    "Value": "value-functions",
}

# Comprehensive list of M functions from Microsoft docs (manually curated)
# This serves as the source of truth for what functions exist
ALL_M_FUNCTIONS: Dict[str, List[str]] = {
    "Table": [
        # Construction
        "Table.FromColumns", "Table.FromList", "Table.FromRecords", "Table.FromRows",
        "Table.FromValue", "Table.View", "Table.ViewError", "Table.ViewFunction",
        # Conversions
        "Table.ToColumns", "Table.ToList", "Table.ToRecords", "Table.ToRows",
        # Information
        "Table.ApproximateRowCount", "Table.ColumnCount", "Table.IsEmpty",
        "Table.PartitionValues", "Table.Profile", "Table.RowCount", "Table.Schema",
        # Row Operations
        "Table.AlternateRows", "Table.Combine", "Table.FindText", "Table.First",
        "Table.FirstN", "Table.FirstValue", "Table.FromPartitions", "Table.InsertRows",
        "Table.Last", "Table.LastN", "Table.MatchesAllRows", "Table.MatchesAnyRows",
        "Table.Partition", "Table.Range", "Table.RemoveFirstN", "Table.RemoveLastN",
        "Table.RemoveRows", "Table.RemoveRowsWithErrors", "Table.Repeat",
        "Table.ReplaceRows", "Table.ReverseRows", "Table.SelectRows",
        "Table.SelectRowsWithErrors", "Table.SingleRow", "Table.Skip", "Table.SplitAt",
        # Column Operations
        "Table.Column", "Table.ColumnNames", "Table.ColumnsOfType", "Table.DemoteHeaders",
        "Table.DuplicateColumn", "Table.HasColumns", "Table.Pivot", "Table.PrefixColumns",
        "Table.PromoteHeaders", "Table.RemoveColumns", "Table.ReorderColumns",
        "Table.RenameColumns", "Table.SelectColumns", "Table.TransformColumnNames",
        "Table.Unpivot", "Table.UnpivotOtherColumns",
        # Transformation
        "Table.AddColumn", "Table.AddFuzzyClusterColumn", "Table.AddIndexColumn",
        "Table.AddJoinColumn", "Table.AddKey", "Table.AggregateTableColumn",
        "Table.CombineColumns", "Table.CombineColumnsToRecord", "Table.ExpandListColumn",
        "Table.ExpandRecordColumn", "Table.ExpandTableColumn", "Table.FillDown",
        "Table.FillUp", "Table.FuzzyGroup", "Table.FuzzyJoin", "Table.FuzzyNestedJoin",
        "Table.Group", "Table.Join", "Table.Keys", "Table.NestedJoin",
        "Table.ReplaceErrorValues", "Table.ReplaceKeys", "Table.ReplaceValue",
        "Table.Split", "Table.SplitColumn", "Table.TransformColumns",
        "Table.TransformColumnTypes", "Table.TransformRows", "Table.Transpose",
        # Membership
        "Table.Contains", "Table.ContainsAll", "Table.ContainsAny", "Table.Distinct",
        "Table.IsDistinct", "Table.PositionOf", "Table.PositionOfAny",
        "Table.RemoveMatchingRows", "Table.ReplaceMatchingRows",
        # Ordering
        "Table.AddRankColumn", "Table.Max", "Table.MaxN", "Table.Min", "Table.MinN",
        "Table.Sort",
        # Other
        "Table.Buffer", "Table.StopFolding",
    ],
    "Text": [
        "Text.At", "Text.AfterDelimiter", "Text.BeforeDelimiter", "Text.BetweenDelimiters",
        "Text.Clean", "Text.Combine", "Text.Contains", "Text.End", "Text.EndsWith",
        "Text.From", "Text.FromBinary", "Text.InferNumberType", "Text.Insert",
        "Text.Length", "Text.Lower", "Text.Middle", "Text.NewGuid", "Text.PadEnd",
        "Text.PadStart", "Text.PositionOf", "Text.PositionOfAny", "Text.Proper",
        "Text.Range", "Text.Remove", "Text.RemoveRange", "Text.Repeat", "Text.Replace",
        "Text.ReplaceRange", "Text.Reverse", "Text.Select", "Text.Split", "Text.SplitAny",
        "Text.Start", "Text.StartsWith", "Text.ToBinary", "Text.ToList", "Text.Trim",
        "Text.TrimEnd", "Text.TrimStart", "Text.Upper",
    ],
    "List": [
        "List.Accumulate", "List.AllTrue", "List.Alternate", "List.AnyTrue",
        "List.Average", "List.Buffer", "List.Combine", "List.Contains",
        "List.ContainsAll", "List.ContainsAny", "List.Count", "List.Covariance",
        "List.Dates", "List.DateTimes", "List.DateTimeZones", "List.Difference",
        "List.Distinct", "List.Durations", "List.FindText", "List.First",
        "List.FirstN", "List.Generate", "List.InsertRange", "List.Intersect",
        "List.IsDistinct", "List.IsEmpty", "List.Last", "List.LastN",
        "List.MatchesAll", "List.MatchesAny", "List.Max", "List.MaxN",
        "List.Median", "List.Min", "List.MinN", "List.Mode", "List.Modes",
        "List.NonNullCount", "List.Numbers", "List.Percentile", "List.PositionOf",
        "List.PositionOfAny", "List.Positions", "List.Product", "List.Random",
        "List.Range", "List.RemoveFirstN", "List.RemoveItems", "List.RemoveLastN",
        "List.RemoveMatchingItems", "List.RemoveNulls", "List.RemoveRange",
        "List.Repeat", "List.ReplaceMatchingItems", "List.ReplaceRange",
        "List.ReplaceValue", "List.Reverse", "List.Select", "List.Single",
        "List.SingleOrDefault", "List.Skip", "List.Sort", "List.Split",
        "List.StandardDeviation", "List.Sum", "List.Times", "List.Transform",
        "List.TransformMany", "List.Union", "List.Zip",
    ],
    "Number": [
        "Number.Abs", "Number.Acos", "Number.Asin", "Number.Atan", "Number.Atan2",
        "Number.BitwiseAnd", "Number.BitwiseNot", "Number.BitwiseOr",
        "Number.BitwiseShiftLeft", "Number.BitwiseShiftRight", "Number.BitwiseXor",
        "Number.Combinations", "Number.Cos", "Number.Cosh", "Number.E", "Number.Exp",
        "Number.Factorial", "Number.From", "Number.FromText", "Number.IsEven",
        "Number.IsNaN", "Number.IsOdd", "Number.Ln", "Number.Log", "Number.Log10",
        "Number.Mod", "Number.Permutations", "Number.PI", "Number.Power",
        "Number.Random", "Number.RandomBetween", "Number.Round", "Number.RoundAwayFromZero",
        "Number.RoundDown", "Number.RoundTowardZero", "Number.RoundUp", "Number.Sign",
        "Number.Sin", "Number.Sinh", "Number.Sqrt", "Number.Tan", "Number.Tanh",
        "Number.ToText",
    ],
    "Date": [
        "Date.AddDays", "Date.AddMonths", "Date.AddQuarters", "Date.AddWeeks",
        "Date.AddYears", "Date.Day", "Date.DayOfWeek", "Date.DayOfWeekName",
        "Date.DayOfYear", "Date.DaysInMonth", "Date.EndOfDay", "Date.EndOfMonth",
        "Date.EndOfQuarter", "Date.EndOfWeek", "Date.EndOfYear", "Date.From",
        "Date.FromText", "Date.IsInCurrentDay", "Date.IsInCurrentMonth",
        "Date.IsInCurrentQuarter", "Date.IsInCurrentWeek", "Date.IsInCurrentYear",
        "Date.IsInNextDay", "Date.IsInNextMonth", "Date.IsInNextNDays",
        "Date.IsInNextNMonths", "Date.IsInNextNQuarters", "Date.IsInNextNWeeks",
        "Date.IsInNextNYears", "Date.IsInNextQuarter", "Date.IsInNextWeek",
        "Date.IsInNextYear", "Date.IsInPreviousDay", "Date.IsInPreviousMonth",
        "Date.IsInPreviousNDays", "Date.IsInPreviousNMonths", "Date.IsInPreviousNQuarters",
        "Date.IsInPreviousNWeeks", "Date.IsInPreviousNYears", "Date.IsInPreviousQuarter",
        "Date.IsInPreviousWeek", "Date.IsInPreviousYear", "Date.IsInYearToDate",
        "Date.IsLeapYear", "Date.Month", "Date.MonthName", "Date.QuarterOfYear",
        "Date.StartOfDay", "Date.StartOfMonth", "Date.StartOfQuarter",
        "Date.StartOfWeek", "Date.StartOfYear", "Date.ToRecord", "Date.ToText",
        "Date.WeekOfMonth", "Date.WeekOfYear", "Date.Year",
    ],
    "Record": [
        "Record.AddField", "Record.Combine", "Record.Field", "Record.FieldCount",
        "Record.FieldNames", "Record.FieldOrDefault", "Record.FieldValues",
        "Record.FromList", "Record.FromTable", "Record.HasFields", "Record.RemoveFields",
        "Record.RenameFields", "Record.ReorderFields", "Record.SelectFields",
        "Record.ToList", "Record.ToTable", "Record.TransformFields",
    ],
    "File": [
        "Csv.Document", "File.Contents", "Lines.FromBinary", "Lines.FromText",
        "Lines.ToBinary", "Lines.ToText",
    ],
    "Web": [
        "Json.Document", "Json.FromValue", "Web.Contents", "Web.Page",
        "Xml.Document", "Xml.Tables",
    ],
    "Fabric": [
        "Lakehouse.Contents",
    ],
}


def scan_emitter_for_functions() -> Set[str]:
    """Scan pandas_emitter.py to find all implemented function names."""
    emitter_path = Path(__file__).parent.parent / "src" / "python_m" / "emitters" / "pandas_emitter.py"

    if not emitter_path.exists():
        print(f"Error: {emitter_path} not found")
        return set()

    content = emitter_path.read_text(encoding='utf-8')

    # Find all func_name == "X.Y" patterns
    pattern = r'func_name\s*==\s*["\']([A-Za-z]+\.[A-Za-z]+)["\']'
    matches = re.findall(pattern, content)

    return set(matches)


def scan_registry_for_functions() -> Dict[str, str]:
    """Scan function_registry.py to get registered functions and their status."""
    registry_path = Path(__file__).parent.parent / "src" / "python_m" / "emitters" / "function_registry.py"

    if not registry_path.exists():
        print(f"Error: {registry_path} not found")
        return {}

    content = registry_path.read_text(encoding='utf-8')

    # Find all _register("X.Y", FunctionStatus.STATUS, ...) patterns
    pattern = r'_register\s*\(\s*["\']([A-Za-z]+\.[A-Za-z]+)["\'],\s*FunctionStatus\.(\w+)'
    matches = re.findall(pattern, content)

    return {name: status for name, status in matches}


def verify_registry():
    """Verify that the registry matches actual implementation."""
    implemented = scan_emitter_for_functions()
    registry = scan_registry_for_functions()

    print("=== Registry Verification ===\n")

    # Check for functions marked as implemented but not in emitter
    registry_implemented = {name for name, status in registry.items() if status == "IMPLEMENTED"}

    false_positives = registry_implemented - implemented
    if false_positives:
        print("ERROR: Marked as IMPLEMENTED but not found in emitter:")
        for f in sorted(false_positives):
            print(f"  - {f}")
        print()

    # Check for functions in emitter but not marked as implemented
    missing_from_registry = implemented - registry_implemented
    if missing_from_registry:
        print("WARNING: Implemented but not marked as IMPLEMENTED in registry:")
        for f in sorted(missing_from_registry):
            status = registry.get(f, "NOT IN REGISTRY")
            print(f"  - {f} (registry status: {status})")
        print()

    # Check for functions in emitter but not in registry at all
    not_in_registry = implemented - set(registry.keys())
    if not_in_registry:
        print("WARNING: Implemented but not in registry at all:")
        for f in sorted(not_in_registry):
            print(f"  - {f}")
        print()

    if not false_positives and not missing_from_registry:
        print("[OK] Registry is accurate!")

    return len(false_positives) == 0


def show_stats():
    """Show implementation statistics."""
    implemented = scan_emitter_for_functions()
    registry = scan_registry_for_functions()

    print("=== Implementation Statistics ===\n")
    print(f"Functions in emitter: {len(implemented)}")
    print(f"Functions in registry: {len(registry)}")
    print()

    # Group by status
    by_status: Dict[str, List[str]] = {}
    for name, status in registry.items():
        by_status.setdefault(status, []).append(name)

    print("Registry breakdown:")
    for status in ["IMPLEMENTED", "PARTIAL", "PLANNED", "NOT_PLANNED", "UNKNOWN"]:
        count = len(by_status.get(status, []))
        print(f"  {status:15} {count:3}")

    print()
    print("Actually implemented functions:")

    # Group by namespace
    by_namespace: Dict[str, List[str]] = {}
    for func in implemented:
        ns = func.split('.')[0]
        by_namespace.setdefault(ns, []).append(func)

    for ns in sorted(by_namespace.keys()):
        funcs = sorted(by_namespace[ns])
        print(f"\n  {ns}: ({len(funcs)} functions)")
        for f in funcs:
            print(f"    - {f}")


def generate_registry_entries():
    """Generate _register() calls for implemented functions."""
    implemented = scan_emitter_for_functions()

    print("# Auto-generated registry entries for implemented functions")
    print("# Add descriptions and notes manually\n")

    # Group by namespace
    by_namespace: Dict[str, List[str]] = {}
    for func in implemented:
        ns = func.split('.')[0]
        by_namespace.setdefault(ns, []).append(func)

    for ns in sorted(by_namespace.keys()):
        print(f"\n# {ns} Functions")
        for func in sorted(by_namespace[ns]):
            print(f'_register("{func}", FunctionStatus.IMPLEMENTED, "{ns}",')
            print(f'          description="")')


def show_coverage():
    """Show implementation coverage by category."""
    implemented = scan_emitter_for_functions()

    print("=== Implementation Coverage by Category ===\n")
    print(f"{'Category':<12} {'Implemented':>12} {'Total':>8} {'Coverage':>10}")
    print("-" * 44)

    total_implemented = 0
    total_functions = 0

    for category, functions in sorted(ALL_M_FUNCTIONS.items()):
        category_implemented = [f for f in functions if f in implemented]
        count = len(category_implemented)
        total = len(functions)
        pct = (count / total * 100) if total > 0 else 0

        total_implemented += count
        total_functions += total

        bar = "#" * int(pct / 10) + "." * (10 - int(pct / 10))
        print(f"{category:<12} {count:>12} {total:>8} {pct:>7.1f}% [{bar}]")

    print("-" * 44)
    overall_pct = (total_implemented / total_functions * 100) if total_functions > 0 else 0
    print(f"{'TOTAL':<12} {total_implemented:>12} {total_functions:>8} {overall_pct:>7.1f}%")

    print("\n\n=== Not Yet Implemented (by category) ===\n")
    for category, functions in sorted(ALL_M_FUNCTIONS.items()):
        not_implemented = [f for f in functions if f not in implemented]
        if not_implemented:
            print(f"\n{category} ({len(not_implemented)} remaining):")
            for f in sorted(not_implemented)[:10]:  # Show first 10
                print(f"  - {f}")
            if len(not_implemented) > 10:
                print(f"  ... and {len(not_implemented) - 10} more")


def main():
    parser = argparse.ArgumentParser(description="Function registry utilities")
    parser.add_argument("--scan", action="store_true", help="List implemented functions")
    parser.add_argument("--verify", action="store_true", help="Verify registry accuracy")
    parser.add_argument("--stats", action="store_true", help="Show statistics")
    parser.add_argument("--generate", action="store_true", help="Generate registry entries")
    parser.add_argument("--coverage", action="store_true", help="Show coverage by category")
    args = parser.parse_args()

    if args.scan:
        funcs = scan_emitter_for_functions()
        print(f"Found {len(funcs)} implemented functions:\n")
        for f in sorted(funcs):
            print(f"  {f}")
    elif args.verify:
        success = verify_registry()
        sys.exit(0 if success else 1)
    elif args.stats:
        show_stats()
    elif args.generate:
        generate_registry_entries()
    elif args.coverage:
        show_coverage()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
